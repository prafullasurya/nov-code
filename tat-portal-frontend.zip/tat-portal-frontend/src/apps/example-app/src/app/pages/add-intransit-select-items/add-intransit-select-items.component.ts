import { Component, OnInit } from '@angular/core';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'tat-portal-frontend-add-intransit-select-items',
  templateUrl: './add-intransit-select-items.component.html',
  styleUrls: ['./add-intransit-select-items.component.scss']
})

export class AddIntransitSelectItemsComponent  implements OnInit{
      
  items: MenuItem[];

  scrollableItems: MenuItem[];

  activeItem: MenuItem;

  activeItem2: MenuItem;

  ngOnInit() {
      this.items = [
          {label: 'Add Items', icon: 'pi pi-fw pi-plus-circle'},
          {label: 'Selected Items', icon: 'pi pi-fw pi-check-circle'},
          {label: 'Edit', icon: 'pi pi-fw pi-pencil'},
          {label: 'Documentation', icon: 'pi pi-fw pi-file'},
          {label: 'Settings', icon: 'pi pi-fw pi-cog'}
      ];

      this.scrollableItems = Array.from({ length: 50 }, (_, i) => ({label: `Tab ${i + 1}`}));

      this.activeItem = this.items[0];

      this.activeItem2 = this.scrollableItems[0];
  }
}
