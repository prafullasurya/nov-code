﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.API.Helper;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetPaginationErpAddressCodesHandler
           : IQueryHandler<GetPaginationErpAddressCodesQuery, PagedResult<ErpAddressCodeDto>>
    {
        private readonly IMapper mapper;
        private readonly IErpAddressCodeService erpAddressCodeService;
        private readonly IHttpContextAccessor httpContextAccessor;

        public GetPaginationErpAddressCodesHandler(
            IMapper mapper
            ,IErpAddressCodeService erpAddressCodeService
            , IHttpContextAccessor httpContextAccessor)
        {
            this.mapper = mapper;
            this.erpAddressCodeService = erpAddressCodeService;
            this.httpContextAccessor = httpContextAccessor;
        }

        public Task<PagedResult<ErpAddressCodeDto>> Handle(GetPaginationErpAddressCodesQuery request,
          CancellationToken cancellationToken)
        {
            var erpAddressCodes = erpAddressCodeService.GetErpAddressCodes(request.PagingParameters);
            var result = mapper.Map<PagedResult<ErpAddressCode>, PagedResult<ErpAddressCodeDto>>(erpAddressCodes);
            PagingHelper.AddPagingMetadata<ErpAddressCodeDto>(result, httpContextAccessor);
            return Task.FromResult(result);
        }
    }
}