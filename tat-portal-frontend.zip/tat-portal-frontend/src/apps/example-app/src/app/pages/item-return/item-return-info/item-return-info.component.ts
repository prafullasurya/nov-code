import { Component, OnInit } from '@angular/core';
import { Product } from '../../../models/product';
import { ProductService } from '../../../models/productservice';

@Component({
  selector: 'item-return-info',
  templateUrl: './item-return-info.component.html',
  styleUrls: ['./item-return-info.component.scss']
})
export class ItemReturnInfoComponent implements OnInit {
  displayAddEditTruckingCompany: boolean;
  displayDialogJobSearch: boolean;
  displayCompleteReturnSlip: boolean;
  
  showAddEditTruckingCompany() {
    this.displayAddEditTruckingCompany = true;
  }
  searNovJob() {
    this.displayDialogJobSearch = true;
  }
  showCompleteReturnSlip() {
    this.displayCompleteReturnSlip = true;
  }
  products: Product[];
    constructor(private productService: ProductService) { }
    ngOnInit() {
        this.productService.getProductsWithOrdersSmall().then(data => this.products = data);
        console.log(this.products);
    }
}

