﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.DomainService;
using NOV.ES.TAT.Admin.API.Helper;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetPaginationDefinedInputGroupsHandler : IQueryHandler<GetPaginationDefinedInputGroupsQuery, PagedResult<DefinedInputGroupDto>>
    {
        private readonly IMapper mapper;
        private readonly IDefinedInputGroupService definedInputGroupService;
        private readonly IHttpContextAccessor httpContextAccessor;

        public GetPaginationDefinedInputGroupsHandler(
            IMapper mapper,
            IDefinedInputGroupService definedInputGroupService,
            IHttpContextAccessor httpContextAccessor)
        {
            this.mapper = mapper;
            this.definedInputGroupService = definedInputGroupService;
            this.httpContextAccessor = httpContextAccessor;
        }
        public Task<PagedResult<DefinedInputGroupDto>> Handle(GetPaginationDefinedInputGroupsQuery request,
            CancellationToken cancellationToken)
        {
            var definedInputGroups = definedInputGroupService.GetDefinedInputGroups(request.PagingParameters);
            var result = mapper.Map<PagedResult<DefinedInputGroup>, PagedResult<DefinedInputGroupDto>>(definedInputGroups);
            PagingHelper.AddPagingMetadata<DefinedInputGroupDto>(result,httpContextAccessor);
            return Task.FromResult(result);
        }
    }
}
