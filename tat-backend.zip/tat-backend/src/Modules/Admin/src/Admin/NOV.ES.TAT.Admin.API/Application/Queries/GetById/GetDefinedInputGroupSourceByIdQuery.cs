﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;


namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetDefinedInputGroupSourceByIdQuery : IQuery<DefinedInputGroupSourceDto>
    {
        public int DefinedInputGroupSourceId { get; private set; }
        public GetDefinedInputGroupSourceByIdQuery(int definedInputGroupSourceId)
        {
            this.DefinedInputGroupSourceId = definedInputGroupSourceId;
        }
    }
}
