﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetErpAddressCodeByIdHandler : IQueryHandler<GetErpAddressCodeByIdQuery, ErpAddressCodeDto>
    {
        private readonly IMapper mapper;
        private readonly IErpAddressCodeService ErpAddressCodeService;

        public GetErpAddressCodeByIdHandler(
            IMapper mapper,
            IErpAddressCodeService ErpAddressCodeService)
        {
            this.mapper = mapper;
            this.ErpAddressCodeService = ErpAddressCodeService;
        }

        public Task<ErpAddressCodeDto> Handle(GetErpAddressCodeByIdQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var ErpAddressCode = ErpAddressCodeService.GetErpAddressCodeById(request.Id);
            var result = mapper.Map<ErpAddressCode, ErpAddressCodeDto>(ErpAddressCode);
            return Task.FromResult(result);
        }
        private static bool IsValidRequest(GetErpAddressCodeByIdQuery request)
        {
            return (request != null && request.Id != 0);
        }
    }
}