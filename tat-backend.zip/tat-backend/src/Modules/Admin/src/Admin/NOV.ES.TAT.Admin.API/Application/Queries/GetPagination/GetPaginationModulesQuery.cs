﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Admin.API.DTOs;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetPaginationModulesQuery : IQuery<PagedResult<ModuleDto>>
    {
        public Paging PagingParameters { get; private set; }

        public GetPaginationModulesQuery(Paging pagingParameters)
        {
            this.PagingParameters = pagingParameters;
        }
    }
}
