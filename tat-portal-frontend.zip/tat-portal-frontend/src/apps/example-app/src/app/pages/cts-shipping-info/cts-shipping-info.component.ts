import { Component, OnInit } from '@angular/core';
import { ThemeService } from '../../services/theme.service';

interface City {
  name: string,
  code: string
}

@Component({
  selector: 'tat-portal-frontend-cts-shipping-info',
  templateUrl: './cts-shipping-info.component.html',
  styleUrls: ['./cts-shipping-info.component.scss']
})
export class CtsShippingInfoComponent implements OnInit {
  cities: City[];
  selectedCity: City;
  date3: Date;
  ChangeSequenceDisplay: boolean;
  completeCustomerTransferSlipDisplay: boolean;
  city: string;
  search: string;

  constructor(private themeService : ThemeService) { 
    
    this.cities = [
      {name: 'New York', code: 'NY'},
      {name: 'Rome', code: 'RM'},
      {name: 'London', code: 'LDN'},
      {name: 'Istanbul', code: 'IST'},
      {name: 'Paris', code: 'PRS'}
    ];

    this.selectedCity=this.cities[1];
  }
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }
  

}
