﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.DomainService;
using NOV.ES.TAT.Admin.API.Helper;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetPaginationUserPreferencesHandler : IQueryHandler<GetPaginationUserPreferencesQuery, PagedResult<UserPreferenceDto>>
    {
        private readonly IMapper mapper;
        private readonly IUserPreferenceService userPreferenceService;
        private readonly IHttpContextAccessor httpContextAccessor;

        public GetPaginationUserPreferencesHandler(
            IMapper mapper,
            IUserPreferenceService userPreferenceService,
            IHttpContextAccessor httpContextAccessor)
        {            
            this.mapper = mapper;
            this.userPreferenceService = userPreferenceService;
            this.httpContextAccessor = httpContextAccessor;
        }
        public Task<PagedResult<UserPreferenceDto>> Handle(GetPaginationUserPreferencesQuery request,
            CancellationToken cancellationToken)
        {
            var userPreference = userPreferenceService.GetUserPreferences(request.PagingParameters);
            var result = mapper.Map<PagedResult<UserPreference>, PagedResult<UserPreferenceDto>>(userPreference);
            PagingHelper.AddPagingMetadata<UserPreferenceDto>(result, httpContextAccessor);
            return Task.FromResult(result);
        }
    }
}
