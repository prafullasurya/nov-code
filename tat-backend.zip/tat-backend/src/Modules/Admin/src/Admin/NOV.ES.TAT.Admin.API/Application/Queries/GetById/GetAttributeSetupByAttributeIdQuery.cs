﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetAttributeSetupByAttributeIdQuery : IQuery<AttributeSetupDto>
    {
        public int AttributeId { get; private set; }
        public GetAttributeSetupByAttributeIdQuery(int attributeId)
        {
            this.AttributeId = attributeId;
        }
    }
}
