﻿namespace NOV.ES.TAT.BoomiWrapper.DomainService.RequestModel
{
    public class InventoryTransferRequest: BaseRequestModel
    {
        public string TransactionType { get; set; }
        public DateTime CreatedDate { get; set; }
        public string Version { get; set; }
        public string TransferSlipOrderType { get; set; }
        public string TransferSlipNumber { get; set; }
        public string TargetInterface { get; set; }
        public string erpUserId { get; set; }
        public string FromBranchPlant { get; set; }
        public string ToBranchPlant { get; set; }
        public List<Domain.WriteModels.InventoryTransferDetails> Details { get; set; }

    }
}
