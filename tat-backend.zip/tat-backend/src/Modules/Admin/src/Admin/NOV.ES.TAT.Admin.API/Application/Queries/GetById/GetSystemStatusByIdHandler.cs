﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetSystemStatusByIdHandler : IQueryHandler<GetSystemStatusByIdQuery, SystemStatusDto>
    {
        private readonly IMapper mapper;
        private readonly ISystemStatusService systemStatusService;

        public GetSystemStatusByIdHandler(
            IMapper mapper,
            ISystemStatusService systemStatusService)
        {
            this.mapper = mapper;
            this.systemStatusService = systemStatusService;
        }

        public Task<SystemStatusDto> Handle(GetSystemStatusByIdQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var systemStatus = systemStatusService.GetSystemStatusById(request.Id);
            var result = mapper.Map<SystemStatus, SystemStatusDto>(systemStatus);
            return Task.FromResult(result);
        }
        private static bool IsValidRequest(GetSystemStatusByIdQuery request)
        {
            return (request != null && request.Id != 0);
        }
    }
}