import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerReturLineItemDetailsComponent } from './customer-return-line-item-details.component';

describe('CustomerReturnSlipComponent', () => {
  let component: CustomerReturLineItemDetailsComponent;
  let fixture: ComponentFixture<CustomerReturLineItemDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerReturLineItemDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerReturLineItemDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
