namespace NOV.ES.TAT.BoomiWrapper.DomainService.ResponseModel
{
    public class ValidateInventoryResponseData
    {
        public string BaseAndRAPartNumber { get; set; }
        public string PartNumber { get; set; }
        public string IsItemExistInRCC { get; set; }
    }
}
