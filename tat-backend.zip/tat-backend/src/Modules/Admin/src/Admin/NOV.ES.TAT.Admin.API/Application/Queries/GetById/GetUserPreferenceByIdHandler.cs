﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetUserPreferenceByIdQueryHandler : IQueryHandler<GetUserPreferenceByIdQuery, UserPreferenceDto>
    {
        private readonly IMapper mapper;
        private readonly IUserPreferenceService userPreferenceService;

        public GetUserPreferenceByIdQueryHandler(
            IMapper mapper,
            IUserPreferenceService userPreferenceService)
        {
            this.mapper = mapper;
            this.userPreferenceService = userPreferenceService;
        }

        public Task<UserPreferenceDto> Handle(GetUserPreferenceByIdQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var userPreference = userPreferenceService.GetUserPreferenceById(request.UserPreferenceId);
            return Task.FromResult(mapper.Map<UserPreference, UserPreferenceDto>(userPreference));
        }

        private static bool IsValidRequest(GetUserPreferenceByIdQuery request)
        {
            return (request != null && request.UserPreferenceId != 0);
        }
    }
}
