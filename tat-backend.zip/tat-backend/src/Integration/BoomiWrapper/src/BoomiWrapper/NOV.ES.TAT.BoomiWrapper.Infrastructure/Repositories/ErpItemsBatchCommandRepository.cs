﻿using NOV.ES.Framework.Core.Data.Repositories;
using NOV.ES.TAT.BoomiWrapper.Domain;

namespace NOV.ES.TAT.BoomiWrapper.Infrastructure
{
    public class ErpItemsBatchCommandRepository
        : GenericWriteRepository<ErpItemsBatch>
        , IErpItemsBatchCommandRepository
    {
        public readonly InterfaceDBContext interfaceDBContext;

        public ErpItemsBatchCommandRepository(InterfaceDBContext interfaceDBContext)
            : base(interfaceDBContext)
        {
            this.interfaceDBContext = interfaceDBContext;
        }

        InterfaceDBContext IErpItemsBatchCommandRepository.interfaceDBContext => interfaceDBContext;

        public ErpItemsBatch GetById(long id)
        {
            return interfaceDBContext.ErpItemsBatches.Where(b => b.Id == id).FirstOrDefault();
        }

        public int SaveChanges()
        {
            return interfaceDBContext.SaveChanges();
        }

        public Task<int> SaveChangesAsync(CancellationToken cancellationToken)
        {
            return interfaceDBContext.SaveChangesAsync(cancellationToken);
        }
    }
}
