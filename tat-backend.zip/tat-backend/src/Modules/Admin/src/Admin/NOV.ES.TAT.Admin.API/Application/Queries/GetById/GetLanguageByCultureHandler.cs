﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetLanguageByCultureHandler : IQueryHandler<GetLanguageByCultureQuery, LanguageDto>
    {
        private readonly IMapper mapper;
        private readonly ILanguageService languageService;

        public GetLanguageByCultureHandler(
            IMapper mapper,
            ILanguageService languageService)
        {
            this.mapper = mapper;
            this.languageService = languageService;
        }

        public Task<LanguageDto> Handle(GetLanguageByCultureQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var language = languageService.GetLanguageByCulture(request.Culture);
            var result = mapper.Map<Language, LanguageDto>(language);
            return Task.FromResult(result);
        }
        private static bool IsValidRequest(GetLanguageByCultureQuery request)
        {
            return (request != null && request.Culture != string.Empty);
        }
    }
}