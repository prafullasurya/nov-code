﻿using IdentityModel.Client;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace NOV.ES.TAT.Common.ServiceBase
{
    public class IdentityServerClient : IIdentityServerClient
    {
        private readonly HttpClient httpClient;
        private readonly ILogger<IdentityServerClient> logger;
        private readonly IConfiguration configuration;

        public IdentityServerClient(ILogger<IdentityServerClient> logger,
            IConfiguration configuration,
            HttpClient httpClient)
        {
            this.logger = logger;
            this.configuration = configuration;
            this.httpClient = httpClient;
        }

        public async Task<string> GetIdentityToken()
        {
            string accessToken = null;
            
            var disco = await httpClient.GetDiscoveryDocumentAsync(
                    new DiscoveryDocumentRequest
                    {
                        Address = configuration["InternalIdentity"],
                        Policy =
                        {
                            RequireHttps = false
                        }
                    });

            if (disco.IsError)
            {
                logger.LogError(disco.Error);
                return accessToken;
            }

            var tokenResponse = await httpClient.RequestClientCredentialsTokenAsync(new ClientCredentialsTokenRequest
            {
                Address = disco.TokenEndpoint,
                ClientId = configuration["IdentityClientId"],
                ClientSecret = configuration["IdentityClientSecret"],
                Scope = "mdmapi.read lookupapi.read"
            });

            if (tokenResponse.IsError)
            {
                logger.LogError(tokenResponse.Error);
            }
            else
            {
                accessToken = tokenResponse.AccessToken;
            }

            return accessToken;
        }
    }
}
