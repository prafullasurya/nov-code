﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetErpAddressCodeByErpAbCodeQuery : IQuery<IEnumerable<ErpAddressCodeDto>>
    {
        public string  ErpAbCode { get; private set; }

        public GetErpAddressCodeByErpAbCodeQuery(string erpAbCode)
        {
            this.ErpAbCode = erpAbCode;
        }
    }
}