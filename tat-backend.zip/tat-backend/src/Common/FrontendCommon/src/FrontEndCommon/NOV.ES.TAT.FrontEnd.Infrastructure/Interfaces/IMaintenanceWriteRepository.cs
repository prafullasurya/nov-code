﻿using NOV.ES.Framework.Core.Data.Repositories;
using NOV.ES.Framework.Core.Data.Repository;
using NOV.ES.TAT.FrontEnd.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NOV.ES.TAT.FrontEnd.Infrastructure
{
    public interface IMaintenanceWriteRepository
        : IWriteRepository<MaintenanceModel>
    {
        void SetUserProvider(string actionBy);
        int SaveChanges();
        Task<int> SaveChangesAsync(CancellationToken cancellationToken);

        Task<MaintenanceModel?> GetById(int id);

        void AddSystemDownMessage(MaintenanceModel maintenanceModel);
    }
}
