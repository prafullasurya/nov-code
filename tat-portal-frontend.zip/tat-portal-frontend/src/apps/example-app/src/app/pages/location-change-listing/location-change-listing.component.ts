import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'tat-portal-frontend-location-change-listing',
  templateUrl: './location-change-listing.component.html',
  styleUrls: ['./location-change-listing.component.scss']
})
export class LocationChangeListingComponent implements OnInit {
  displayBasic: boolean;

  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }
  showBasicDialog() {
    this.displayBasic = true;
  } 
}
