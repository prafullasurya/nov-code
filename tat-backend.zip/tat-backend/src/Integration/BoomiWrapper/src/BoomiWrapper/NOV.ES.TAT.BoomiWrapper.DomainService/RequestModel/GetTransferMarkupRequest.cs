﻿namespace NOV.ES.TAT.BoomiWrapper.DomainService.RequestModel
{
    public class GetTransferMarkupRequest: BaseRequestModel
    {
        public int addressNumber { get; set; }
        public int businessUnit { get; set; }
		public string ItemNumber { get; set; }
		public string SalesReportingCode2 { get; set; }
    }
}
