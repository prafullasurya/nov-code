using Microsoft.AspNetCore.Mvc;
using NOV.ES.Framework.Core.CQRS.Commands;
using NOV.ES.TAT.FrontEnd.API.Application;
using System.Net;

namespace NOV.ES.TAT.FrontEnd.API
{
    [ApiController]
    [Route("[controller]")]
    public class ErrorLoggingController : ControllerBase
    {

        private readonly ILogger<ErrorLoggingController> logger;
        private readonly ICommandBus commandBus;
        public ErrorLoggingController(ILogger<ErrorLoggingController> logger, ICommandBus commandBus)
        {
            this.logger = logger;
            this.commandBus = commandBus;
        }

        /// <summary>
        /// This method returns service name.
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("ServiceName")]
        public IActionResult ServiceName()
        {
            logger.LogInformation("TAT FrontEnd Error logging Service -Service Name Api call initiated");
            return Ok("TAT FrontEnd Error Logging Service.");
        }


        /// <summary>
        /// This method creates RecordLog based on requested data.
        /// </summary>
        /// <param name="RecordLog">RecordLogCommand</param>
        /// <returns>OK Result</returns>
        [HttpPost]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        public async Task<IActionResult> RecordLogAsync([FromBody] RecordLogCommand recordLogCommand)
        {
            logger.LogInformation($"Request for record log received.");

            var result = await commandBus.Send<RecordLogCommand, bool>(recordLogCommand);
            if (!result)
                return BadRequest();

            logger.LogInformation($"Frontend Error Log recorded successfully.");
            return Ok();
        }
    }
}