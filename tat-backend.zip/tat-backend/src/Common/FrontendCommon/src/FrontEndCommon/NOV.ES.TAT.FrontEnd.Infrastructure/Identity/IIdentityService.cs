﻿namespace NOV.ES.TAT.FrontEnd.Infrastructure;

public interface IIdentityService
{
    string GetUserIdentity();

    string GetUserName();
}

