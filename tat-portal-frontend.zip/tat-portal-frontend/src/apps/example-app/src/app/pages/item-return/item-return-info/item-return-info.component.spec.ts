import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ItemReturnInfoComponent } from './item-return-info.component';

describe('ItemReturnInfoComponent', () => {
  let component: ItemReturnInfoComponent;
  let fixture: ComponentFixture<ItemReturnInfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ItemReturnInfoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ItemReturnInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
