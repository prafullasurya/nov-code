﻿using FluentValidation;
using global::NOV.ES.Framework.Core.Caching;
using global::NOV.ES.Framework.Core.CQRS.Commands;
using global::NOV.ES.Infrastructure.Caching.Redis;
using global::NOV.ES.TAT.Common.Appnotification.Service;
using global::NOV.ES.TAT.Common.FeatureToggle.Service;
using global::NOV.ES.TAT.Common.UserPermissions.Service;
using IdentityModel.AspNetCore.OAuth2Introspection;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;
using NOV.ES.Framework.Core.CQRS.Behaviors;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Data;
using NOV.ES.Framework.Core.Data.Repository;
using NOV.ES.TAT.FrontEnd.API;
using NOV.ES.TAT.FrontEnd.Domain;
using NOV.ES.TAT.FrontEnd.DomainService;
using NOV.ES.TAT.FrontEnd.DomainService.Clients;
using NOV.ES.TAT.FrontEnd.Infrastructure;
using System.IdentityModel.Tokens.Jwt;
using System.Reflection;

namespace NOV.ES.TAT.FrontEnd.API
{
    public static class DependencyRegistrar
    {
        public static IServiceCollection AddCustomMvc(this IServiceCollection services)
        {
            services.AddControllers(
               options =>
               {
                   options.Filters.Add(typeof(HttpGlobalExceptionFilter));
               }
           ).
           AddNewtonsoftJson(
               joptions =>
               {
                   joptions.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();
                   joptions.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
                   joptions.SerializerSettings.Converters.Add(new StringEnumConverter());
               }
           );
            services.AddCors(options =>
            {
                options.AddPolicy("CorsPolicy",
                    builder => builder
                    .SetIsOriginAllowed((host) => true)
                    .AllowAnyMethod()
                    .AllowAnyHeader()
                    .AllowCredentials());
            });
            return services;
        }
        public static IServiceCollection AddHealthChecks(this IServiceCollection services, IConfiguration configuration)
        {
            var hcBuilder = services.AddHealthChecks();
            hcBuilder.AddCheck("self", () => HealthCheckResult.Healthy());
            return services;
        }
        public static IServiceCollection AddCustomDbContext(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddDbContext<MaintenanceDBContext>(options =>
            {
                options.UseSqlServer(configuration["TrackAToolDbConnString"],
                    sqlServerOptionsAction: sqlOptions =>
                    {
                        sqlOptions.MigrationsAssembly(typeof(Startup).GetTypeInfo().Assembly.GetName().Name);
                        sqlOptions.EnableRetryOnFailure(maxRetryCount: 3, maxRetryDelay: TimeSpan.FromSeconds(30), errorNumbersToAdd: null);
                    });
            },
            ServiceLifetime.Scoped
            );

            //services.AddDbContext<FinancialTransferSlipReadDbContext>(options =>
            //{
            //    options.UseSqlServer(configuration["FinancialTransferDBConnString"],
            //        sqlServerOptionsAction: sqlOptions =>
            //        {
            //            sqlOptions.MigrationsAssembly(typeof(Startup).GetTypeInfo().Assembly.GetName().Name);
            //            sqlOptions.EnableRetryOnFailure(maxRetryCount: 3, maxRetryDelay: TimeSpan.FromSeconds(30), errorNumbersToAdd: null);
            //        });
            //},
            //ServiceLifetime.Scoped
            //);
            return services;
        }
        public static IServiceCollection AddCustomSwagger(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v1", new OpenApiInfo
                {
                    Title = "TAT Financial Transfer Write REST API",
                    Version = "v1",
                    Description = "The Financial Transfer Service Write REST API"
                });
                options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme()
                {
                    Name = "Authorization",
                    Type = SecuritySchemeType.ApiKey,
                    Scheme = "Bearer",
                    BearerFormat = "JWT",
                    In = ParameterLocation.Header,
                    Description = "JWT Authorization header using the Bearer scheme. \r\n\r\n Enter 'Bearer' [space] and then your token in the text input below.\r\n\r\nExample: \"Bearer 12345abcdef\"",
                });
                options.AddSecurityRequirement(new OpenApiSecurityRequirement()
            {
                    {
                          new OpenApiSecurityScheme()
                            {
                                Reference = new OpenApiReference
                                {
                                    Type = ReferenceType.SecurityScheme,
                                    Id = "Bearer"
                                }
                            },
                            new string[] {}
                    }
            });
            });
            return services;
        }
        public static IServiceCollection AddDomainCoreDependecy(this IServiceCollection services)
        {
            services.AddTransient<IQueryBus, QueryBus>();
            services.AddTransient<ICommandBus, CommandBus>();
            services.AddScoped<BaseContext, MaintenanceDBContext>();
            services.AddTransient<IUserProfileService, UserProfileService>();
            services.AddTransient<IFeatureToggleService, FeatureToggleService>();
            services.AddScoped<IReadRepository<MaintenanceModel>, GenericReadRepository<MaintenanceModel>>();
            services.AddScoped<IMaintenanceService, MaintenanceService>();
            services.AddScoped<IMaintenanceQueryRepository, MaintenanceQueryRepository>();
            services.AddScoped<IMaintenanceQueryRepository, MaintenanceQueryRepository>();

            services.AddScoped<IMaintenanceWriteRepository, MaintenanceWriteRepository>();
            services.AddHttpClient<IFrontendCommonAppNotificationClient, FrontendCommonAppNotificationClient>();
            
            //services.AddTransient<IBroadCastNotificationService, BroadCastNotificationService>();
            //services.AddTransient<IBroadCastNotificationRepository, BroadCastNotificationRepository>();

            //  services.AddTransient<IFinancialTransferSlipWriteRepository, FinancialTransferSlipWriteRepository>();
            return services;
        }
        public static IServiceCollection RegistorMediatR(this IServiceCollection services)
        {
            services.AddMediatR(typeof(Startup).GetTypeInfo().Assembly);
            services.AddValidatorsFromAssembly(typeof(Startup).Assembly);
            services.AddTransient(typeof(IPipelineBehavior<,>), typeof(LoggingBehavior<,>));
            //services.AddTransient(typeof(IPipelineBehavior<,>), typeof(TransactionBehaviour<,>));
            return services;
        }
        public static IServiceCollection AddAutoMapper(this IServiceCollection services)
        {
            services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());
            return services;
        }
        public static IServiceCollection AddCustomAuthentication(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddAuthentication(OAuth2IntrospectionDefaults.AuthenticationScheme)
            .AddOAuth2Introspection(options =>
            {
                options.Authority = configuration["Authority"];
                options.ClientId = configuration["ClientId"];

                options.Events = new OAuth2IntrospectionEvents()
                {
                    OnTokenValidated = context =>
                    {
                        var jwtSecurityToken = new JwtSecurityTokenHandler().ReadToken(context.SecurityToken);
                        context.HttpContext.Items["user_email_id"] = ((JwtSecurityToken)jwtSecurityToken)
                        .Claims.FirstOrDefault(c => c.Type == "sub").Value;
                        context.HttpContext.Items["access_token"] = (JwtSecurityToken)jwtSecurityToken;
                        return Task.CompletedTask;
                    }
                };
            });
            return services;
        }


        //public static IServiceCollection AddIntegrationEventLog(this IServiceCollection services, IConfiguration configuration)
        //{
        //    services.AddDbContext<MaintenanceDBContext>(options =>
        //    {
        //        options.UseSqlServer(configuration["TrackAToolDbConnString"],
        //            sqlServerOptionsAction: sqlOptions =>
        //            {
        //                sqlOptions.MigrationsAssembly(typeof(Startup).GetTypeInfo().Assembly.GetName().Name);
        //                sqlOptions.EnableRetryOnFailure(maxRetryCount: 3, maxRetryDelay: TimeSpan.FromSeconds(30), errorNumbersToAdd: null);
        //            });
        //    },
        //        ServiceLifetime.Scoped  //Showing explicitly that the DbContext is shared across the HTTP request scope (graph of objects started in the HTTP request)
        //    );

        //    //services.AddTransient<Func<DbConnection, IIntegrationEventLogService>>(
        //    //    sp => (DbConnection c) => new IntegrationEventLogService(c));

        //    return services;
        //}

        //public static IServiceCollection AddIntegrationEventBus(this IServiceCollection services)
        //{
        //    services.AddSingleton<IIntegrationEventBus, EventBusRabbitMq>();
        //    return services;
        //}
        //public static IServiceCollection AddRabbitMq(this IServiceCollection services, IConfiguration configuration)
        //{
        //    services.AddRabbitMqEventBus(configuration, "IntegrationEventBusConfig", "TATInternalIntegrationBus");

        //    // Override RabitMq connection string per environment read from Kubernetes Secret
        //    var rabbitConfig = configuration.GetSection("TATInternalIntegrationBusRQCON");
        //    var rabbitMqConfigObj = Newtonsoft.Json.JsonConvert.DeserializeObject<RabbitMqConfig>(rabbitConfig.Value);
        //    services.PostConfigure<RabbitMqConfig>(o =>
        //    {
        //        o.RabbitMqConnection.HostName = rabbitMqConfigObj.RabbitMqConnection.HostName;
        //        if (!string.IsNullOrEmpty(rabbitMqConfigObj.RabbitMqConnection.Username))
        //        {
        //            o.RabbitMqConnection.Username = rabbitMqConfigObj.RabbitMqConnection.Username;
        //            o.RabbitMqConnection.Password = rabbitMqConfigObj.RabbitMqConnection.Password;
        //        }

        //        o.RabbitMqConnection.IsSSLEnabled = rabbitMqConfigObj.RabbitMqConnection.IsSSLEnabled;
        //        o.RabbitMqConnection.AutomaticRecoveryEnabled = rabbitMqConfigObj.RabbitMqConnection.AutomaticRecoveryEnabled; ;
        //        o.RabbitMqConnection.RequestedHeartbeat = rabbitMqConfigObj.RabbitMqConnection.RequestedHeartbeat;

        //    });

        //    // Override RabitMq Integration Bus Config per environment read from Kubernetes Secret
        //    var busConfigSec = configuration.GetSection("CTESMQBusConfig");
        //    var busConfigObj = Newtonsoft.Json.JsonConvert.DeserializeObject<IntegrationEventBusConfig>(busConfigSec.Value);
        //    if (busConfigObj != null)
        //    {
        //        services.PostConfigure<IntegrationEventBusConfig>(o =>
        //        {
        //            o.BrokerName = busConfigObj.BrokerName;
        //            o.ExchangeType = busConfigObj.ExchangeType;
        //            o.QueueName = busConfigObj.QueueName;
        //            o.Topic = busConfigObj.Topic;
        //        });
        //    }
        //    return services;
        //}

        public static IServiceCollection AddRedisConfig(this IServiceCollection services, IConfiguration configuration)
        {
            var redisSettings = configuration.GetSection("RedisSettings");

            services.Configure<RedisSettings>(redisSettings);

            services.AddSingleton<ICache, RedisCache>();

            services.AddTransient<IAppNotificationClient, AppNotificationClient>();


            return services;

        }

        //public static IServiceCollection AddPolly(this IServiceCollection services, IConfiguration configuration)
        //{
        //    #region PollyImplementation
        //    //Note: Need to install Microsoft.Extensions.Http.Polly
        //    services.AddHttpClient<IBoomiWrapperService, BoomiWrapperService>(client =>
        //    {
        //        client.BaseAddress = new Uri(configuration["Boomi_Base_url"]);
        //    })
        //    .SetHandlerLifetime(TimeSpan.FromMinutes(Convert.ToInt32(configuration["HandlerLifetimeInMinutes"])))
        //    .AddPolicyHandler(GetWaitRetryPolicy(configuration))
        //    .AddPolicyHandler(GetCircuitBreakerPolicy(configuration));
        //    #endregion
        //    return services;
        //}
    }
}

