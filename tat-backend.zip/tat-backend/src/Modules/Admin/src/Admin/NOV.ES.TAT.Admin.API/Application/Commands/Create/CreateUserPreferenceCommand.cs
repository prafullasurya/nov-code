﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using NOV.ES.Framework.Core.CQRS.Commands;
using NOV.ES.TAT.Admin.API.DTOs;

namespace NOV.ES.TAT.Admin.API.Application.Commands
{
    public class CreateUserPreferenceCommand : ICommand<ContentResult>
    {
        public UserPreferenceDto UserPreferenceDto { get; private set; }

        [JsonConstructor]
        public CreateUserPreferenceCommand(UserPreferenceDto userPreferenceDto)
        {
            this.UserPreferenceDto = userPreferenceDto;
        }
    }
}