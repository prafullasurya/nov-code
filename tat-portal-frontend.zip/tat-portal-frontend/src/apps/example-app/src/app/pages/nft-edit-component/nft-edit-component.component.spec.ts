import { ComponentFixture, TestBed } from '@angular/core/testing';

import { nftEditAComponentComponent } from './nft-edit-component.component';

describe('nftEditAComponentComponent', () => {
  let component: nftEditAComponentComponent;
  let fixture: ComponentFixture<nftEditAComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ nftEditAComponentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(nftEditAComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
