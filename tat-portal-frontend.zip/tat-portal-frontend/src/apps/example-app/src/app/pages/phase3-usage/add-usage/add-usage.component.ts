import { Component, OnInit } from '@angular/core';
import { ConfirmationService, MessageService } from 'primeng/api';

interface City {
  name: string,
  code: string
}
@Component({
  selector: 'add-usage',
  templateUrl: './add-usage.component.html',
  styleUrls: ['./add-usage.component.scss']
})
export class AddUsageComponent {
  
  displayAddUsage: boolean;
  
  showAddUsage() {
    this.displayAddUsage = true;
  }
}
