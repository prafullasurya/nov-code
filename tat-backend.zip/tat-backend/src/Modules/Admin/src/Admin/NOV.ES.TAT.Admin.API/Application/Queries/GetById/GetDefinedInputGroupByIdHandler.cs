﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetDefinedInputGroupByIdHandler : IQueryHandler<GetDefinedInputGroupByIdQuery, DefinedInputGroupDto>
    {
        private readonly IMapper mapper;
        private readonly IDefinedInputGroupService definedInputGroupService;

        public GetDefinedInputGroupByIdHandler(
            IMapper mapper,
            IDefinedInputGroupService definedInputGroupService)
        {
            this.mapper = mapper;
            this.definedInputGroupService = definedInputGroupService;
        }

        public Task<DefinedInputGroupDto> Handle(GetDefinedInputGroupByIdQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var definedInputGroup = definedInputGroupService.GetDefinedInputGroupById(request.DefinedInputGroupId);
            return Task.FromResult(mapper.Map<DefinedInputGroup, DefinedInputGroupDto>(definedInputGroup));
        }

        private static bool IsValidRequest(GetDefinedInputGroupByIdQuery request)
        {
            return (request != null && request.DefinedInputGroupId != 0);
        }
    }
}
