﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NOV.ES.TAT.Common.Appnotification.Models
{
    public class EventSubTask
    {
        public string EventKey { get; set; }
        public string KeyId { get; set; }
        public int SubTaskId { get; set; }
        public string SubTask { get; set; }        
        public TaskStatus TaskStatus { get; set; }
        public string ErrorMessage { get; set; }
        public string Action { get; set; }
        public long StartedAt { get; set; }
        public long CompletedAt { get; set; }

        public EventSubTask(string eventKey, string keyId, int subTaskId, string subTask)
        {
            EventKey = eventKey;
            KeyId = keyId;
            SubTaskId = subTaskId;
            SubTask = subTask;
            TaskStatus = TaskStatus.NotStarted;
        }
    }
}
