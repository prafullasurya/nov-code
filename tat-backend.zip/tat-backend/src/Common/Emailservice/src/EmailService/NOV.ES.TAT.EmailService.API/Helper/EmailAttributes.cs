﻿namespace NOV.ES.TAT.EmailService.Helper
{
    public class EmailAttributes
    {
        public string AttributeName { get; set; }
        public string AttributeValue { get; set; }
        //public List<EmailAttributes>? NotificationAttributeThis { get; set; }       
        public EmailAttributes(string attributeName, string attributeValue)
        {
            AttributeName = attributeName;
            AttributeValue = attributeValue;
        }
        
    }
}
