﻿using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using NOV.ES.Framework.Core.Data;
using NOV.ES.TAT.FrontEnd.Domain;

namespace NOV.ES.TAT.FrontEnd.Infrastructure
{
    public class MaintenanceDBContext : BaseContext
    {
        public MaintenanceDBContext(DbContextOptions<MaintenanceDBContext> dbContextOptions
           , IHttpContextAccessor httpContextAccessor)
           : base(dbContextOptions)
        {
            if (httpContextAccessor != null && httpContextAccessor.HttpContext != null)
            {
                IIdentityService identityService = new IdentityService(httpContextAccessor);
                UserProvider = identityService.GetUserName();
            }
        }
        public virtual DbSet<MaintenanceModel> MaintenanceModels { get; set; }

        //public virtual DbSet<NotificationView> GetNotificationView { get; set; }


        //public virtual DbSet<BroadCastNotificationView> GetBroadCastNotificationView { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<MaintenanceModel>().Property(x => x.Id).ValueGeneratedOnAdd();
            modelBuilder.Entity<MaintenanceModel>().Property(x => x.IsActive).HasDefaultValueSql("1");
            modelBuilder.Entity<MaintenanceModel>().Property(x => x.DateCreated).HasDefaultValueSql("GETUTCDATE()");
            modelBuilder.Entity<MaintenanceModel>().Property(x => x.DateModified).HasDefaultValueSql("GETUTCDATE()");

            //modelBuilder.Entity("NOV.ES.TAT.FrontEnd.Domain.MaintenanceModel", b =>
            //{
            //    b.Property<int>("Id").ValueGeneratedOnAdd().HasColumnType("int");
            //    SqlServerPropertyBuilderExtensions.UseIdentityColumn(b.Property<int>("Id"), 1L, 1);
            //    b.Property<string>("DownTimeReason").HasMaxLength(500).HasColumnType("nvarchar(500)");
            //    b.Property<DateTime?>("ExpectedResumeBy").HasColumnType("datetime2").HasDefaultValueSql("GETUTCDATE()");
            //    b.Property<bool>("IsActive").ValueGeneratedOnAdd().HasColumnType("bit").HasDefaultValueSql("1");
            //    b.Property<DateTime?>("DateCreated").HasColumnType("datetime2").HasDefaultValueSql("GETUTCDATE()");
            //    b.Property<string?>("CreatedSource").HasMaxLength(100).HasColumnType("nvarchar(50)");
            //    b.Property<string?>("ModifiedSource").HasMaxLength(50).HasDefaultValueSql("datetime2");
            //    b.Property<DateTime?>("DateModified").HasColumnType("datetime2").HasDefaultValueSql("GETUTCDATE()");
            //    b.HasKey("Id");
            //    b.ToTable("SystemDownMessage", "admin");
            //});
            //modelBuilder.Entity<NotificationModel>().ToView("changewithviewname", "notification");
            //modelBuilder.Entity<MaintenanceModel>().ToView("SystemDownMessageView", "MaintenanceModel");
            //  modelBuilder.Entity<NotificationView>().ToView("NotificationView");
            //modelBuilder.Entity<BroadCastNotificationView>().ToView("BroadCastNotificationView");
        }

    }
}
