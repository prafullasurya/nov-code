import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ActiveUsageDetachComponent } from './active-usage-detach.component';

describe('ActiveUsageDetachComponent', () => {
  let component: ActiveUsageDetachComponent;
  let fixture: ComponentFixture<ActiveUsageDetachComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ActiveUsageDetachComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ActiveUsageDetachComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
function beforeEach(arg0: () => void) {
  throw new Error('Function not implemented.');
}

