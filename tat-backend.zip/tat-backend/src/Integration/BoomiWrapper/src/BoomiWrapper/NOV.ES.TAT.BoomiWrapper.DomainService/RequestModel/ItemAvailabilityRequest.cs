﻿namespace NOV.ES.TAT.BoomiWrapper.DomainService.RequestModel
{
    public class ItemAvailabilityRequest: BaseRequestModel
    {
        public string PartNumber { get; set; }
        public int BusinessUnit { get; set; }
        public string Location { get; set; }
        public string Mode { get; set; }
        public string SerialNumber { get; set; }
    }
}
