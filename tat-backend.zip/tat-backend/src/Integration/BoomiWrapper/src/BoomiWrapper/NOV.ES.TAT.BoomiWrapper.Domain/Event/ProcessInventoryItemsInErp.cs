﻿using NOV.ES.TAT.BoomiWrapper.Domain.ReadModel;

namespace NOV.ES.TAT.BoomiWrapper.Domain.Event
{
    public class ProcessInventoryItemsInErp
    {
        public CustomerTransferSlip CustomerTransferSlip { get; set; }
        public List<CustomerTransferSlipErpItem> ErpItems { get; set; }
        public string ErpType { get; set; }
        public ErpOperations ErpOperation { get; set; }
        public EventInfoModel EventInfo { get; set; }
    }

    public enum ErpOperations
    {
        ADD,
        UPDATE,
        DELETE,
        RESUBMIT,
        COMPLETE
    }

    public class EventInfoModel
    {
        public long Id { get; }
        public string CurrentDataJson { get; }
        public string PreviousDataJson { get; }
        public string ChangeDataJson { get; }
        public DateTime EventDate { get; }
        public string ActionBy { get; }
        public long? ParentEventInfoId { get; set; }
        public bool IsParentEvent { get; set; }
        public string Key { get; }
        public string Description { get; }
        public string Value { get; }
    }
}
