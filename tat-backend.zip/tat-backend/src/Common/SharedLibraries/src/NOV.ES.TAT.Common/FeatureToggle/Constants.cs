﻿
namespace NOV.ES.TAT.Common.FeatureToggle
{
    public static class Constants
    {
        public const string Features_Toggle_Unauthorized_Error = "Features flag of Feature:{0} is OFF for User";
    }
}
