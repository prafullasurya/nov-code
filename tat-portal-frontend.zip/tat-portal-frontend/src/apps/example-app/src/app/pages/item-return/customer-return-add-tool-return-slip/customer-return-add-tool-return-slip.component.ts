import { Component, OnInit } from '@angular/core';
import { Product } from '../../../models/product';
import { ProductService } from '../../../models/productservice';

@Component({
  selector: 'customer-return-add-tool-return-slip',
  templateUrl: './customer-return-add-tool-return-slip.component.html',
  styleUrls: ['./customer-return-add-tool-return-slip.component.scss']
})
export class CustomerReturnAddToolReturnSlipComponent implements OnInit {
  displayAddEditTruckingCompany: boolean;
  
  showAddEditTruckingCompany() {
    this.displayAddEditTruckingCompany = true;
  }
  products: Product[];
    constructor(private productService: ProductService) { }
    ngOnInit() {
        this.productService.getProductsWithOrdersSmall().then(data => this.products = data);
        console.log(this.products);
    }
}

