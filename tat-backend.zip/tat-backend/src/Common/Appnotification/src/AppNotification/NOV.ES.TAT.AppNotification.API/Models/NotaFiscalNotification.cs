﻿namespace NOV.ES.TAT.AppNotification.API.Models
{
   
    public class BroadcastNotaFiscalNotification
    {
        public string SlipId { get; set; }
        public string SlipNumber { get; set; }
        public string ErrorMessage { get; set; }
        public string NotaFiscalNumber { get; set; }

        public BroadcastNotaFiscalNotification(string id, string slipNumber, string notaFiscalNumber,
            string errorMessage = null)
        {
            SlipId = id;
            SlipNumber = slipNumber;
            this.NotaFiscalNumber = notaFiscalNumber;
            this.ErrorMessage = errorMessage;
        }
    }
}
