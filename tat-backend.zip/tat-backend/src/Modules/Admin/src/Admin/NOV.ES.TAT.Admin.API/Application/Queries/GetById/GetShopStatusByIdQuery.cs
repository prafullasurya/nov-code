﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetShopStatusByIdQuery: IQuery<ShopStatusDto>
    {
        public int ShopStatusId { get; private set; }
        public GetShopStatusByIdQuery(int shopStatusId)
        {
            this.ShopStatusId = shopStatusId;
        }
    }
}
