﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.API.Helper;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetLocationByTatReferenceIdHandler : IQueryHandler<GetLocationByTatReferenceIdQuery, LocationDto>
    {
        private readonly IMapper mapper;
        private readonly ILocationService locationService;
        private readonly IHttpContextAccessor httpContextAccessor;

        public GetLocationByTatReferenceIdHandler(ILogger<GetLocationByTatReferenceIdHandler> logger,
            IMapper mapper,
            ILocationService locationService,
            IHttpContextAccessor httpContextAccessor
            )
        {            
            this.mapper = mapper;
            this.locationService = locationService;
            this.httpContextAccessor = httpContextAccessor;
        }

        public Task<LocationDto> Handle(GetLocationByTatReferenceIdQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);
            var location = locationService.GetLocationByTatReferenceId(request.TATReferenceId);
            return Task.FromResult(mapper.Map<Location, LocationDto>(location));
        }
        private static bool IsValidRequest(GetLocationByTatReferenceIdQuery request)
        {
            return (request != null);
        }
    }
}
