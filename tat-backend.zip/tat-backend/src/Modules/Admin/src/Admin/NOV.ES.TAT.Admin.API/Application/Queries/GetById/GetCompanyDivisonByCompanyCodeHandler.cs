﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries.GetById
{
    public class GetCompanyDivisonByCompanyCodeHandler : IQueryHandler<GetCompanyDivisonByBUQuery, BUCompanyDetailsDivisionView>
    {
        private readonly IMapper mapper;
        private readonly ICompanyDivisionService companyDivisionService;

        public GetCompanyDivisonByCompanyCodeHandler(
            IMapper mapper,
            ICompanyDivisionService companyDivisionService)
        {
            this.mapper = mapper;
            this.companyDivisionService = companyDivisionService;
        }

        public Task<BUCompanyDetailsDivisionView> Handle(GetCompanyDivisonByBUQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var companyDivision = companyDivisionService.GetCompanyDivisionByBUCode(request.BusinessUnitCode);
            return Task.FromResult(companyDivision);
        }
        private static bool IsValidRequest(GetCompanyDivisonByBUQuery request)
        {
            return (request != null && request.BusinessUnitCode != "");
        }
    }
}
