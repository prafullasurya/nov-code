﻿namespace NOV.ES.TAT.BoomiWrapper.Domain.WriteModels;

public class InventoryTransferDetails
{
    public string InventoryTransactionType { get; set; }
    public string FromItemNumber { get; set; }
    public string ToItemNumber { get; set; }
    public string FromQuantity { get; set; }
    public string ToQuantity { get; set; }
    public string FromBU { get; set; }
    public string ToBU { get; set; }
    public string ToDisplayLocation { get; set; }
    public string FromDisplayLocation { get; set; }
    public string CFromTo { get; set; }
    public string UpdateQuantityOnHand { get; set; }
    public string AllowQtyOverAvailable { get; set; }
    public string CAllowHeldLot { get; set; }
    public string CToLotStatusCode { get; set; }
    public string CLotStatusCode { get; set; }    
    public string ToSerialNumber { get; set; }
    public string FromLotNumber { get; set; }
    public string JDEJobNumber { get; set; }
    public string PODefaultLotStatus { get; set; }
    public string ToLotNumber { get; set; }
    public string FromLocation { get; set; }
    public string ToLocation { get; set; }
    public int? TransactionReference { get; set; }
    public string FromSerialNumber { get; set; }

}
