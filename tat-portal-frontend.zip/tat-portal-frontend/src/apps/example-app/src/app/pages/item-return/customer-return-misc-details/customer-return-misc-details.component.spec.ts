import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerReturnMiscDetailsComponent } from './customer-return-misc-details.component';

describe('CustomerReturnMiscDetailsComponent', () => {
  let component: CustomerReturnMiscDetailsComponent;
  let fixture: ComponentFixture<CustomerReturnMiscDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerReturnMiscDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerReturnMiscDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
