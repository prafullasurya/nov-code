﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.FrontEnd.API.DTOs;
using NOV.ES.TAT.FrontEnd.Domain;

namespace NOV.ES.TAT.FrontEnd.API.Application
{
    public class MaintenanceQuery  : IQuery<IEnumerable<MaintenanceDto>>
    {
        public MaintenanceQuery()
        {
        }
    }
}

