﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetCompanyDivisionByConfigIdQuery : IQuery<IEnumerable<CompanyDivisionDto>>
    {
        public int CompanyConfigId { get; private set; }

        public GetCompanyDivisionByConfigIdQuery(int companyConfigId)
        {
            this.CompanyConfigId = companyConfigId;
        }
    }
}