import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerReturnInventoryItemCompletedComponent } from './customer-return-inventory-item-completed.component';

describe('CustomerReturnInventoryItemCompletedComponent', () => {
  let component: CustomerReturnInventoryItemCompletedComponent;
  let fixture: ComponentFixture<CustomerReturnInventoryItemCompletedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerReturnInventoryItemCompletedComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerReturnInventoryItemCompletedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
