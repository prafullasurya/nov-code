﻿using NOV.ES.TAT.Common.UserPermissions.Models;

namespace NOV.ES.TAT.Common.UserPermissions.Service
{
    public interface IUserProfileService
    {
        public Task<UserProfile> GetUserProfile();
       // public Task<UserProfile> GetUserProfileByRedisCache();
    }
}
