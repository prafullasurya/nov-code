import { Component} from '@angular/core';

interface City {
  name: string,
  code: string
}
@Component({
  selector: 'return-slip-single-item-component-completed',
  templateUrl: './return-slip-single-item-component-completed.component.html',
  styleUrls: ['./return-slip-single-item-component-completed.component.scss']
})
export class ReturnSlipSingleItemCompletedComponent {
  
  


}
