﻿using NOV.ES.TAT.Common.FeatureToggle.Models;

namespace NOV.ES.TAT.Common.FeatureToggle.Service
{
    public interface IFeatureToggleService
    {
        public Task<ToggleFeatures> GetUserToggleFeatures();
        bool HasAllowed(string feature);
    }
}
