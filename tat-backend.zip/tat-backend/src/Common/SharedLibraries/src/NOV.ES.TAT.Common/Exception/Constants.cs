﻿namespace NOV.ES.TAT.Common.Exception
{
    public static class Constants
    {
        #region Error Numbers

        public const int NONE = 0;

        public const int UNKNOWN = 1;

        public const int CONNECTION_LOST = 100;

        public const int INTERNAL_ERROR = 200;

        public const int NULL_REFERENCE = 300;

        public const int SQL_EXCEPTION = 400;

        public const int ARGUMENT_EXCEPTION = 500;

        #endregion

        #region Exception Type 

        public const string ArgumentException = "ArgumentException";

        public const string NullReferenceException = "NullReferenceException";

        public const string TimeoutException = "TimeoutException";

        public const string SqlException = "SqlException";

        #endregion

        #region Exception Messages

        public const string EX_NULL_REFERENCE = "Null Reference error occurred";

        public const string EX_CONNECTION_TIMEOUT = "Connection Timeout error occurred";

        public const string EX_ARGUMENT_EXCEPTION = "Invalid Argument error occurred";

        public const string EX_INTERNAL_ERROR = "Internal server error occurred";

        public const string EX_SQL_EXCEPTION = "SQL server error occurred";

        #endregion

    }
}
