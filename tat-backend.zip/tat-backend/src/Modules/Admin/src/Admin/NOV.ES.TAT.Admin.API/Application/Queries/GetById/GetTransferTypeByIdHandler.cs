﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;
using NOV.ES.TAT.Admin.DomainService.Interfaces;

namespace NOV.ES.TAT.Admin.API.Application.Queries.GetById
{
    public class GetTransferTypeByIdHandler : IQueryHandler<GetTransferTypeByIdQuery, TransferTypeDto>
    {
        private readonly IMapper mapper;
        private readonly ITransferTypeService transferTypeService;

        public GetTransferTypeByIdHandler(
            IMapper mapper,
            ITransferTypeService transferTypeService)
        {
            this.mapper = mapper;
            this.transferTypeService = transferTypeService;
        }

        public Task<TransferTypeDto> Handle(GetTransferTypeByIdQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var transferType = transferTypeService.GetTransferTypeById(request.Id);
            var result = mapper.Map<TransferType, TransferTypeDto>(transferType);
            return Task.FromResult(result);
        }
        private static bool IsValidRequest(GetTransferTypeByIdQuery request)
        {
            return (request != null && request.Id != 0);
        }
    }
}
