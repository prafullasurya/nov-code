﻿using NOV.ES.Framework.Core.DTOs;

namespace NOV.ES.TAT.BoomiWrapper.Domain.ReadModel
{
    public enum ItemType
    {
        A, //Assembly
        M, //Miscellaneous
        C, //Component
        J, //Inventory Item (Erp Item)
        K, //Kit
        R  //Container
    }
    public enum EditMode
    {
        DETAIL,
        SUMMARY
    }

    public enum CommunityFlag
    {
        NONE,
        FCG,
        IPR
    }

    public class CustomerTransferSlipDetail : BaseModel<int>
    {
        public int CustomerTransferId { get; set; }
        public string ItemType { get; set; }
        public string SubItemType { get; set; }
        public bool Consignment { get; set; } // LineType
        public int ItemId { get; set; }
        public string ItemSerialNumber { get; set; }
        public string ItemName { get; set; }
        public string ItemDescription { get; set; }
        public int? UsageId { get; set; }
        public int? LocationId { get; set; }
        public string LocationName { get; set; }
        public int? SizeId { get; set; }
        public string SizeValue { get; set; }
        public int? LobeId { get; set; }
        public string Lobe { get; set; }
        public int? StageId { get; set; }
        public string Stage { get; set; }
        public decimal? QuantityShipped { get; set; }
        public decimal? PreviousQuantityShipped { get; set; }
        public string Comments { get; set; }
        public bool? NonInventoryItem { get; set; }
        public bool? IsDisplayOnPrint { get; set; }
        public int? TopConnJointTypeId { get; set; }
        public string TopConnJointTypeDesc { get; set; }
        public int? TopConnTypeId { get; set; }
        public string TopConnTypeDesc { get; set; }
        public int? BottomConnJointTypeId { get; set; }
        public string BottomConnJointTypeDesc { get; set; }
        public int? BottomConnTypeId { get; set; }
        public string BottomConnTypeDesc { get; set; }
        public string LeasingType { get; set; }
        public string Currency { get; set; }
        public decimal? ItemValue { get; set; }
        public int? CommunityFlag { get; set; }
        public string FieldTicket { get; set; }
        public string RotorHeatNumber { get; set; }
        public string StatorHeatNumber { get; set; }
        public double? RotorOD { get; set; }
        public double? StatorID { get; set; }
        public bool? IsIntendedUseOnLand { get; set; }
        public string BitType { get; set; }
        public string HTS { get; set; }
        public string ErrorMessage { get; set; }
        public string PartNumber { get; set; }
        public string PartDescription { get; set; }
        public string NewPartNumber { get; set; }
        public string NewPartDescription { get; set; }
        public int SequenceNumber { get; set; }
        public bool? IsThresholdOverride { get; set; }
        public string ThresholdOverridenBy { get; set; }
        public string ErpDocType { get; set; }
        public string ErpDocNumber { get; set; }
        public string ErpLocation { get; set; }
        public string ErpLocationZone { get; set; }
        public string ErpLotStatus { get; set; }
        public int? LastErpSoftCommitmentId { get; set; }
        public bool? LastActionCompleted { get; set; }
        public short? IsCompleted { get; set; }
        public int? StationaryValvePlateSizeId { get; set; }
        public int? OscillatingValvePlateSizeId { get; set; }
        public string UsageFileNumberDisplay { get; set; }
        public string OscillatingValvePlateSize { get; set; }
        public string StationaryValvePlateSize { get; set; }
    }
    public class CustomerTransferSlipErpItem
    {
        public int CustomerTransferSlipDetailId { get; set; }
        public int ItemId { get; set; }
        public ItemType? ItemType { get; set; }
        public string PartSerialNumber { get; set; } //Lot Number
        public string PartNumber { get; set; }
        public string PartDescription { get; set; }
        public decimal QuantityShipped { get; set; }
        public decimal PreviousQuantityShipped { get; set; }
        public int SequenceNumber { get; set; }
        public short IsCompleted { get; set; }
        public string FieldTicket { get; set; }
        public bool? IsDisplayOnPrint { get; set; }
        public bool? IsIntendedUseOnLand { get; set; }
        public string LeasingType { get; set; }
        public decimal? ItemValue { get; set; } //Cost
        public string HTS { get; set; }
        public string Comments { get; set; }
        public CommunityFlag? CommunityFlag { get; set; }
        public string ErpLocation { get; set; }
        public string ErpLocationZone { get; set; }
        public string ErpLotStatus { get; set; }
        public long? LastErpSoftCommitmentId { get; set; }
        public bool? LastActionCompleted { get; set; }
        public EditMode EditMode { get; set; }
        public string ErrorMessage { get; set; }
        public string LineType { get; set; }
        public string ErpDocNumber { get; set; }
        public string ErpDocType { get; set; }
        public string FromKeyCompany { get; set; }
        public decimal ConsolidatedQuantityShipped { get; set; }

    }
}
