import { ComponentFixture, TestBed } from '@angular/core/testing';

import { nftCompletedComponent } from './nft-completed.component';

describe('nftCompletedComponent', () => {
  let component: nftCompletedComponent;
  let fixture: ComponentFixture<nftCompletedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ nftCompletedComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(nftCompletedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
