﻿namespace NOV.ES.TAT.BoomiWrapper.DomainService
{
    public static class Constants
    {
        #region ValidatorMessages

        public const string InventoryTransactionType_Reclassification = "Reclassification";
        public const string InventoryTransactionType_Adjustment = "Adjustment";
        public const string STAGING = "STAGING";
        public const string Version_DDSOPS0001 = "DDSOPS0001";
        public const string InventoryTransfer = "InventoryTransfer";
        public const string InventoryAdjustment = "InventoryAdjustment";
        public const string CDS = "CDS";
        public const string FTS = "FTS"; // Field Transfer Slip
        public const string AddERPItems = "AddERPItems";
        public const string UpdateERPItems = "UpdateERPItems";
        public const string ResubmitERPItems = "ResubmitERPItems";
        public const string DeleteERPItems = "DeleteERPItems";
        public const string ADD = "ADD";
        public const string UPDATE = "UPDATE";
        public const string TargetInterface_InventoryTransfer = "InventoryTransfer";
        public const string TargetInterface_InventoryAdjustment = "InventoryAdjustment";
        public const string TargetERP_JDE = "JDE";
        public const string TransferSlipOrderType_TT = "TT";
        public const string TransactionType_RI = "RI";
        public const string TransactionType_RT = "RT"; // RT-Rig Transfer

        #endregion
    }
}
