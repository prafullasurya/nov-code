﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetDefinedInputGroupValueByDefinedInputGroupIdHandler : IQueryHandler<GetDefinedInputGroupValueByDefinedInputGroupIdQuery, IEnumerable<DefinedInputGroupValueDto>>
    {
        private readonly IMapper mapper;
        private readonly IDefinedInputGroupValueService definedInputGroupValueService;

        public GetDefinedInputGroupValueByDefinedInputGroupIdHandler(
            IMapper mapper,
            IDefinedInputGroupValueService definedInputGroupValueService)
        {
            this.mapper = mapper;
            this.definedInputGroupValueService = definedInputGroupValueService;
        }

        public Task<IEnumerable<DefinedInputGroupValueDto>> Handle(GetDefinedInputGroupValueByDefinedInputGroupIdQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var definedInputGroupValues = definedInputGroupValueService.GetDefinedInputGroupValuesByDefinedInputGroupId(request.DefinedInputGroupId);
        
            var result = mapper.Map<IEnumerable<DefinedInputGroupValue>, IEnumerable<DefinedInputGroupValueDto>>(definedInputGroupValues);
            return Task.FromResult(result);
        }
        private static bool IsValidRequest(GetDefinedInputGroupValueByDefinedInputGroupIdQuery request)
        {
            return (request != null);    
        }
    }
}