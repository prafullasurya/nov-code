﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetTatReferenceByIdHandler : IQueryHandler<GetTatReferenceByIdQuery, TatReferenceDto>
    {
        private readonly IMapper mapper;
        private readonly ITatReferenceService tatReferenceService;
        
        public GetTatReferenceByIdHandler(
            IMapper mapper,
            ITatReferenceService tatReferenceService)
        {
            this.mapper = mapper;
            this.tatReferenceService = tatReferenceService;
        }

        public Task<TatReferenceDto> Handle(GetTatReferenceByIdQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var tatReference = tatReferenceService.GetTatReferenceById(request.TatReferenceId);
            return Task.FromResult(mapper.Map<TatReference, TatReferenceDto>(tatReference));
        }

        private static bool IsValidRequest(GetTatReferenceByIdQuery request)
        {
            return (request != null && request.TatReferenceId != 0);
        }
    }
}
