﻿using Newtonsoft.Json;
using NOV.ES.Framework.Core.Messaging.IntegrationEvents;
using NOV.ES.Framework.Core.Sagas;
using NOV.ES.TAT.BoomiWrapper.API.Application.IntegrationEvents.PublishEvents;
using NOV.ES.TAT.BoomiWrapper.Domain;
using NOV.ES.TAT.BoomiWrapper.Domain.WriteModels;
using NOV.ES.TAT.BoomiWrapper.DomainService;
using NOV.ES.TAT.BoomiWrapper.DomainService.RequestModel;
using NOV.ES.TAT.BoomiWrapper.DomainService.ResponseModel;

namespace NOV.ES.TAT.BoomiWrapper.API.Application.IntegrationEvents.SubscribedEvents
{
    public class GenerateBatchNextNumberHandler
        : IIntegrationEventHandler<GenerateBatchNextNumber>
    {
        private readonly ILogger<GenerateBatchNextNumberHandler> logger;
        private readonly IBoomiWrapperService boomiWrapperService;
        private readonly IIntegrationEventBus integrationEventBus;

        public GenerateBatchNextNumberHandler(
            ILogger<GenerateBatchNextNumberHandler> logger,
            IBoomiWrapperService boomiWrapperService,
            IIntegrationEventBus integrationEventBus)
        {
            this.logger = logger;
            this.boomiWrapperService = boomiWrapperService;
            this.integrationEventBus = integrationEventBus;
        }

        public Task Handle(GenerateBatchNextNumber @event)
        {
            logger.LogInformation("----- Consuming Event: Generate Batch Next Number Integration Event");
            logger.LogInformation("----- CorelationId is {id}", @event.CorelationId);
            logger.LogInformation("----- Event Detail is {info}", @event.JsonStringData);

            BoomiRequestResponse boomiRequestResponse;
            //1.Generate request for boomi 
            GenerateBatchNextNumberRequest batchNextNumberRequest = GenerateRequestPayload(@event.CorelationId, @event.ActionBy, @event.JsonStringData, out boomiRequestResponse);

            //2.Record request in database
            boomiWrapperService.RecordRequestPayload(boomiRequestResponse);

            //3. Boomi Call
            BatchNextNumberResponse batchNextNumberResponse = boomiWrapperService.GetBatchNextNumber(batchNextNumberRequest).Result;

            //4. Record Response
            boomiRequestResponse.Status = BoomiResponseType.Success.ToString();
            boomiRequestResponse.ResponseStatus = batchNextNumberResponse.Success;
            boomiRequestResponse.RequestDateTime = DateTime.UtcNow;
            boomiRequestResponse.ResponseBody = JsonConvert.SerializeObject(batchNextNumberResponse);
            if (batchNextNumberResponse.Errors != null && batchNextNumberResponse.Errors.Any())
            {
                boomiRequestResponse.ErrorMessage = JsonConvert.SerializeObject(batchNextNumberResponse.Errors);
                boomiRequestResponse.Status = BoomiResponseType.Failed.ToString();
            }

            boomiWrapperService.RecordResponse(boomiRequestResponse);

            //5.Generate response for publish event
            var result = GenerateResponseForPublishEvent(batchNextNumberResponse);

            //6.publish event
            GeneratedBatchNextNumber success =
            new(
                boomiRequestResponse.RequestId.ToString(),
                @event.CorelationId,
                JsonConvert.SerializeObject(result),
                DateTime.UtcNow,
                SagaEventExecutionResult.Success,
                @event.ActionBy
                );

            logger.LogInformation("Publish Generated Batch Next Number event  - GeneratedBatchNextNumber.");
            integrationEventBus.Publish(success);

            return Task.CompletedTask;

        }

        private static GenerateBatchNextNumberRequest GenerateRequestPayload(Guid corelationId, string actionBy, string jsonStringData, out BoomiRequestResponse boomiRequestResponse)
        {
            var generateBatchNextNumberRequest = JsonConvert.DeserializeObject<GenerateBatchNextNumberRequest>(jsonStringData);

            GenerateBatchNextNumberRequest batchNextNumberRequest = new GenerateBatchNextNumberRequest()
            {
                Source = generateBatchNextNumberRequest.Source,
                TargetERP = generateBatchNextNumberRequest.TargetERP
            };
            boomiRequestResponse = new BoomiRequestResponse()
            {
                RequestId = generateBatchNextNumberRequest.RequestId,
                CorelationId = corelationId,
                EventId = generateBatchNextNumberRequest.EventId,
                KeyName = generateBatchNextNumberRequest.KeyName,
                KeyValue = generateBatchNextNumberRequest.KeyValue,
                RequestDateTime = DateTime.UtcNow,
                RequestStatus = BoomiResponseType.Success.ToString(),
                RequestBody = JsonConvert.SerializeObject(batchNextNumberRequest),
                RequestURL = "inBatchNumber/getBatchNextNumber",
                RequestMethod = "getBatchNextNumber",
                HttpVerb = "Post",
                ActionBy = actionBy
            };

            return batchNextNumberRequest;
        }

        private static string GenerateResponseForPublishEvent(BatchNextNumberResponse batchNextNumberResponse)
        {
            return batchNextNumberResponse.ERPBatchNumber;
        }
    }
}

