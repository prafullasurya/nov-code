﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using Microsoft.Net.Http.Headers;
using System.IdentityModel.Tokens.Jwt;

namespace NOV.ES.TAT.Common.Authentication
{
    public static class AuthenticationExtension
    {
        public static IServiceCollection AddTatOktaAuthentication(this IServiceCollection services, IConfiguration configuration)
        {
            var oktaAuthServerConfig = configuration["OktaAuthServer"];
            var oktaAuthServer = string.IsNullOrEmpty(oktaAuthServerConfig) ? string.Empty : oktaAuthServerConfig;
            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
            .AddJwtBearer(options =>
            {

                options.Authority = configuration["Authority"] + $"/oauth2/{oktaAuthServer}";
                options.Audience = configuration["OktaAudience"]; //"api://Tat2v2app";

                options.TokenValidationParameters = new TokenValidationParameters
                {
                    RequireExpirationTime = true,
                    //RequireSignedTokens = true,
                    ValidateIssuer = true,
                    ValidIssuer = configuration["Authority"] + $"/oauth2/{oktaAuthServer}",
                    ValidateIssuerSigningKey = false,
                    //IssuerSigningKeys = signingKeys,
                    ValidateLifetime = true,
                    ValidAudience = configuration["OktaAudience"],
                    ValidateAudience = true
                };
                options.Events = new Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerEvents()
                {
                    OnTokenValidated = context =>
                    {

                        context.HttpContext.Items["user_email_id"] = ((JwtSecurityToken)context.SecurityToken).Subject;
                        context.HttpContext.Items["access_token"] = (JwtSecurityToken)context.SecurityToken;
                        Console.WriteLine("Okta Token validation Succeeded");
                        return Task.CompletedTask;
                    },

                    OnAuthenticationFailed = context =>
                    {
                        Console.WriteLine("Okta Token validation Failed");
                        return Task.CompletedTask;
                    }
                };
            });
            return services;
        }
        public static IServiceCollection AddTatCustomAuthentication(this IServiceCollection services, IConfiguration configuration)
        {
            var oktaAuthServerConfig = configuration["OktaAuthServer"];
            var oktaAuthServer = string.IsNullOrEmpty(oktaAuthServerConfig) ? string.Empty : oktaAuthServerConfig;
            services.AddAuthentication(options =>
            {
                options.DefaultScheme = "Okta_OR_InternalIdentity";
                options.DefaultChallengeScheme = "Okta_OR_InternalIdentity";
            })
            .AddJwtBearer(Constants.OKTA_AUTH_SCHEME, options =>
            {

                options.Authority = configuration["Authority"] + $"/oauth2/{oktaAuthServer}";
                options.Audience = configuration["OktaAudience"]; //"api://Tat2v2app";

                options.TokenValidationParameters = new TokenValidationParameters
                {
                    RequireExpirationTime = true,
                    //RequireSignedTokens = true,
                    ValidateIssuer = true,
                    ValidIssuer = configuration["Authority"] + $"/oauth2/{oktaAuthServer}",
                    ValidateIssuerSigningKey = false,
                    //IssuerSigningKeys = signingKeys,
                    ValidateLifetime = true,
                    ValidAudience = configuration["OktaAudience"],
                    ValidateAudience = true
                };
                options.Events = new Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerEvents()
                {
                    OnTokenValidated = context =>
                    {

                        context.HttpContext.Items["user_email_id"] = ((JwtSecurityToken)context.SecurityToken).Subject;
                        context.HttpContext.Items["access_token"] = (JwtSecurityToken)context.SecurityToken;
                        Console.WriteLine("Okta Token validation Succeeded");
                        return Task.CompletedTask;
                    },

                    OnAuthenticationFailed = context =>
                    {
                        Console.WriteLine("Okta Token validation Failed");
                        return Task.CompletedTask;
                    }
                };
            })
            .AddJwtBearer(Constants.IDENTITY_AUTH_SCHEME, options =>
            {
                /// local url from rancher for internal identity server
                /// http://tat-identity-server.trackatool-dev.svc.cluster.local
                options.Authority = configuration["InternalIdentity"];
                options.RequireHttpsMetadata = false;

                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateAudience = false
                };
                options.Events = new Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerEvents()
                {
                    OnTokenValidated = context =>
                    {
                        Console.WriteLine("Internal Identity Token validation Succeeded");
                        context.HttpContext.Items["x-internal-identity"] = "true";
                        return Task.CompletedTask;
                    },

                    OnAuthenticationFailed = context =>
                    {
                        Console.WriteLine("Internal identity Token validation Failed");
                        return Task.CompletedTask;
                    }
                };
            })
            .AddPolicyScheme("Okta_OR_InternalIdentity",
            "Okta_OR_InternalIdentity",
            options =>
            {
                options.ForwardDefaultSelector = context =>
                {
                    string authorization = context.Request.Headers[HeaderNames.Authorization];
                    if (!string.IsNullOrEmpty(authorization) && authorization.StartsWith("Bearer "))
                    {
                        var token = authorization.Substring("Bearer ".Length).Trim();
                        var jwtHandler = new JwtSecurityTokenHandler();
                        var scheme = (jwtHandler.CanReadToken(token) &&
                            jwtHandler.ReadJwtToken(token).Issuer.Equals(configuration["Authority"] + $"/oauth2/{oktaAuthServer}")
                        ) ? "Okta" : "InternalIdentity";
                        Console.WriteLine("Scheme selected is " + scheme);
                        return scheme;
                    }
                    return "Okta";
                };
            });
            return services;
        }

    }
}
