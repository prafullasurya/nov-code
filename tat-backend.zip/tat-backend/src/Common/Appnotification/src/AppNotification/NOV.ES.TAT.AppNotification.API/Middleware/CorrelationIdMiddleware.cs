﻿using Serilog.Context;

namespace NOV.ES.TAT.AppNotification.API.Middleware
{
    public class CorrelationIdMiddleware
    {
        private readonly RequestDelegate next;
        private readonly ILogger<CorrelationIdMiddleware> logger;

        public CorrelationIdMiddleware(RequestDelegate next, ILogger<CorrelationIdMiddleware> logger)
        {
            this.next = next;
            this.logger = logger;
        }

        public async Task Invoke(HttpContext context)
        {
            string correlationId = null;
            var key = context.Request.Headers.Keys.FirstOrDefault(x => x.ToLower().Equals("x-correlation-id"));
            if (!string.IsNullOrWhiteSpace(key))
            {
                correlationId = context.Request.Headers[key];
                logger.LogInformation("Header contained CorrelationId: {@CorrelationId}", correlationId);
            }
            else
            {
                correlationId = Guid.NewGuid().ToString();
                logger.LogInformation("Generated new CorrelationId: {@CorrelationId}", correlationId);
            }
            context.Response.Headers.Append("x-correlation-id", correlationId);
            using (LogContext.PushProperty("CorrelationId", correlationId))
            {
                await next.Invoke(context);
            }
        }
    }

}
