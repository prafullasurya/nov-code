import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ItemsHeaderComponent } from './tems-header.component';

describe('ItemsHeaderComponent', () => {
  let component: ItemsHeaderComponent;
  let fixture: ComponentFixture<ItemsHeaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ItemsHeaderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ItemsHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
function beforeEach(arg0: () => void) {
  throw new Error('Function not implemented.');
}

