import { Component, OnInit } from '@angular/core';
import { ConfirmationService, MessageService } from 'primeng/api';

interface City {
  name: string,
  code: string
}
@Component({
  selector: 'active-usage-detach',
  templateUrl: './active-usage-detach.component.html',
  styleUrls: ['./active-usage-detach.component.scss']
})
export class ActiveUsageDetachComponent {
  
}
