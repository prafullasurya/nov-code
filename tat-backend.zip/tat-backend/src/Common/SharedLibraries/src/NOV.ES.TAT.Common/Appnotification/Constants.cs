﻿namespace NOV.ES.TAT.Common.Appnotification
{
    public enum Event
    {
        CTSCREATEHEADER = 1,
        UpdatedCtsHeaderCustSalesInfo = 2,
        UpdatedCtsHeaderRigWellInfo = 3,
        UpdatedCtsHeaderShippingInfo = 4,
        DeleteCtsHeader = 5,
        CTSADDASSEMBLY = 6,
        CTSADDCOMPONENT = 7,
        CTSCOMPLETECTS = 8,
        CTSADDERP = 9,
        CTSUPDATEERP = 10,
        CTSDELETEERP = 11,
        CTSRESUBMITERP = 12,
        CTSADDITEMS = 13,
        CTSUPDATEITEMS = 14,
        CTSDELETEITEMS = 15,

    }
    public static class Constants
    {
        private static Dictionary<Event, Dictionary<int, string>> events = new Dictionary<Event, Dictionary<int, string>>()
        {
            {   Event.CTSCREATEHEADER,
                new Dictionary<int, string>()
                {
                    {1, "Save Customer Transfer Slip Header."},
                    {2, "Record Create CTS Header Event Info."}
                }
            },
             {   Event.UpdatedCtsHeaderCustSalesInfo,
                new Dictionary<int, string>()
                {
                    {1, "Recorded CTS Header -Update CustSalesInfo Request in event store."},
                    {2, "Save Customer Transfer Slip Header."},
                    {3, "Record CTS Header -Update CustSalesInfo Event Info."}
                }
            },
             {   Event.UpdatedCtsHeaderRigWellInfo,
                new Dictionary<int, string>()
                {
                    {1, "Recorded CTS Header -Update RigWellInfo Request in event store."},
                    {2, "Save Customer Transfer Slip Header."},
                    {3, "Record CTS Header -Update RigWellInfo Event Info."}
                }
            },
             {   Event.UpdatedCtsHeaderShippingInfo,
                new Dictionary<int, string>()
                {
                    {1, "Recorded CTS Header -Update ShippingInfo Request in event store."},
                    {2, "Save Customer Transfer Slip Header."},
                    {3, "Record CTS Header -Update ShippingInfo Event Info."}
                }
            },
             {   Event.DeleteCtsHeader,
                new Dictionary<int, string>()
                {
                    {1, "Recorded Delete CTS Header Request in event store."},
                    {2, "Save Customer Transfer Slip Header."},
                    {3, "Record Delete CTS Header Event Info."}
                }
            },
            {   Event.CTSADDCOMPONENT,
                new Dictionary<int, string>()
                {
                    {1, "Recorded Add Component Request in event store."},
                    {2, "Save Component to Customer Transfer Slip "},
                    {3, "Record Event Info for add Component."},
                    {4, "Reserve Component for Customer Transfer Slip."},
                    {5, "Record Event Info for Reserve Component."}
                }
            },
             {   Event.CTSADDASSEMBLY,
                new Dictionary<int, string>()
                {
                    {1, "Recorded Add Assembly Request in event store."},
                    {2, "Save Assembly to Customer Transfer Slip "},
                    {3, "Record Event Info for add Assembly."},
                    {4, "Reserve Assembly for Customer Transfer Slip."},
                    {5, "Record Event Info for Reserve Assembly."}
                }
            },
              {   Event.CTSCOMPLETECTS,
                new Dictionary<int, string>()
                {
                    {1, "Recorded complete CTS Request in event store."},
                    {2, "Save Initiate Complete Customer Transfer Slip "},
                    {3, "Record Event Info Initiate Complete Cts."},
                    {4, "Initiate Complete Cts API call  from Titan to Tat."},
                    {5, "Save Complete Cts Response From Tat"},
                    {6, "Record EventInfo For Complete Cts"},
                }
            },
              {   Event.CTSADDERP,
                new Dictionary<int, string>()
                {
                    {1, "Add Inventory Items To Cts initiated."},
                    {2, "Add Inventory Items To Cts Completed."}
                }
            },
              {   Event.CTSUPDATEERP,
                new Dictionary<int, string>()
                {
                    {1, "Update Inventory Items To Cts initiated."},
                    {2, "Update Inventory Items To Cts Completed."}
                }
            },
              {   Event.CTSDELETEERP,
                new Dictionary<int, string>()
                {
                    {1, "Delete Inventory Items To Cts initiated."},
                    {2, "Delete Inventory Items To Cts Completed."}
                }
            },
              {   Event.CTSRESUBMITERP,
                new Dictionary<int, string>()
                {
                    {1, "Resubmit Inventory Items To Cts initiated."},
                    {2, "Resubmit Inventory Items To Cts Completed."}
                }
            },
              {   Event.CTSADDITEMS,
                new Dictionary<int, string>()
                {
                    {1, "Record Add Items Request."},
                    {2, "Item Build Validation."},
                    {3, "Reserve Items in TAT."},
                    {4, "Save Items to Customer Transfer Slip."},
                    {5, "Recorded Add Items Request."},
                }
            },
              {   Event.CTSUPDATEITEMS,
                new Dictionary<int, string>()
                {
                    {1, "Record Update Items Request."},
                    {2, "Update Items in TAT."},
                    {3, "Update Items to Customer Transfer Slip."},
                    {4, "Recorded Add Items Request."},
                }
            },
              {   Event.CTSDELETEITEMS,
                new Dictionary<int, string>()
                {
                    {1, "Record Delete Items Request."},
                    {2, "Release Items in TAT."},
                    {3, "Delete Items from Customer Transfer Slip."},
                    {4, "Recorded Add Items Request."},
                }
            }
        };

        public static Dictionary<Event, Dictionary<int, string>> Events { get => events; }
    }
}
