export const environment = {
  production: true,
  guidtointenabled: true,
  apiHostUrl: 'https://tatservicetest.nov.cloud',
  errorLoggingApiEndPoint:'https://tatservicetest.nov.cloud/frontendcommonsvc/ErrorLogging',
  gridPageSize:50,
  dropdownPazeSize:100,
  assemblyUrl: 'https://wbtat04.nov.com/tat/Tools/ToolsDetails.aspx?id=',
  componentUrl: 'https://wbtat04.nov.com/tat/Components/ComponentsDetails.aspx?id=',
  usageUrl: 'https://wbtat04.nov.com/tat/Usages/UsagesDetails.aspx?id=',
  OldTatURl: 'https://wbtat04.nov.com/tat/',
};
