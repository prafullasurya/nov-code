﻿using Newtonsoft.Json;
using NOV.ES.Framework.Core.Messaging.IntegrationEvents;
using NOV.ES.Framework.Core.Sagas;
using NOV.ES.TAT.BoomiWrapper.API.Application.IntegrationEvents.PublishEvents;
using NOV.ES.TAT.BoomiWrapper.Domain;
using NOV.ES.TAT.BoomiWrapper.Domain.WriteModels;
using NOV.ES.TAT.BoomiWrapper.DomainService;
using NOV.ES.TAT.BoomiWrapper.DomainService.RequestModel;
using NOV.ES.TAT.BoomiWrapper.DomainService.ResponseModel;
using AutoMapper;

namespace NOV.ES.TAT.BoomiWrapper.API.Application.IntegrationEvents.SubscribedEvents
{
    public class GenerateCreateWorkOrderHandler
        : IIntegrationEventHandler<GenerateCreateWorkOrder>
    {
        private ILogger<GenerateCreateWorkOrderHandler> logger;
        private readonly IBoomiWrapperService boomiWrapperService;
        private readonly IIntegrationEventBus integrationEventBus;
        private readonly IMapper mapper;

        public GenerateCreateWorkOrderHandler(
            ILogger<GenerateCreateWorkOrderHandler> logger,
            IBoomiWrapperService boomiWrapperService,
            IIntegrationEventBus integrationEventBus,
            IMapper mapper)
        {
            this.logger = logger;
            this.boomiWrapperService = boomiWrapperService;
            this.integrationEventBus = integrationEventBus;
            this.mapper = mapper;
        }

        public Task Handle(GenerateCreateWorkOrder @event)
        {
            logger.LogInformation("----- Consuming Event: Generate Batch Next Number Integration Event");
            logger.LogInformation("----- CorelationId is {id}", @event.CorelationId);
            logger.LogInformation("----- Event Detail is {info}", @event.JsonStringData);

            BoomiRequestResponse boomiRequestResponse;
            //1.Generate request for boomi 
            CreateWorkOrderRequest createWorkOrderRequest = GenerateRequestPayload(@event.CorelationId, @event.ActionBy, @event.JsonStringData, out boomiRequestResponse);

            //2.Record request in database
            boomiWrapperService.RecordRequestPayload(boomiRequestResponse);

            //3. Boomi Call
            CreateWorkOrderResponse createWorkOrderResponse = boomiWrapperService.CreateWorkOrder(createWorkOrderRequest).Result;

            //4. Record Response
            boomiRequestResponse.Status = BoomiResponseType.Success.ToString();
            boomiRequestResponse.ResponseStatus = createWorkOrderResponse.Success;
            boomiRequestResponse.RequestDateTime = DateTime.UtcNow;
            boomiRequestResponse.ResponseBody = JsonConvert.SerializeObject(createWorkOrderResponse);
            if (createWorkOrderResponse.Errors != null && createWorkOrderResponse.Errors.Any())
            {
                boomiRequestResponse.ErrorMessage = JsonConvert.SerializeObject(createWorkOrderResponse.Errors);
                boomiRequestResponse.Status = BoomiResponseType.Failed.ToString();
            }

            boomiWrapperService.RecordResponse(boomiRequestResponse);

            //5.Generate response for publish event
            var result = GenerateResponseForPublishEvent(createWorkOrderResponse);

            //6.publish event
            GeneratedCreateWorkOrder success =
            new(
                boomiRequestResponse.RequestId.ToString(),
                @event.CorelationId,
                JsonConvert.SerializeObject(result),
                DateTime.UtcNow,
                SagaEventExecutionResult.Success,
                @event.ActionBy
                );

            logger.LogInformation("Publish Generated Batch Next Number event  - GeneratedBatchNextNumber.");
            integrationEventBus.Publish(success);

            return Task.CompletedTask;

        }

        private CreateWorkOrderRequest GenerateRequestPayload(Guid corelationId, string actionBy, string jsonStringData, out BoomiRequestResponse boomiRequestResponse)
        {
            var generateCreateWorkOrderRequest = JsonConvert.DeserializeObject<GenerateCreateWorkOrderRequest>(jsonStringData);

            var createWorkOrderRequest = mapper.Map<GenerateCreateWorkOrderRequest, CreateWorkOrderRequest>(generateCreateWorkOrderRequest);
            boomiRequestResponse = new BoomiRequestResponse()
            {
                RequestId = generateCreateWorkOrderRequest.RequestId,
                CorelationId = corelationId,
                EventId = generateCreateWorkOrderRequest.EventId,
                KeyName = generateCreateWorkOrderRequest.KeyName,
                KeyValue = generateCreateWorkOrderRequest.KeyValue,
                RequestDateTime = DateTime.UtcNow,
                RequestStatus = BoomiResponseType.Success.ToString(),
                RequestBody = JsonConvert.SerializeObject(createWorkOrderRequest),
                RequestURL = "inWorkOrder/createWorkorder",
                RequestMethod = "createWorkorder",
                HttpVerb = "Post",
                ActionBy = actionBy
            };

            return createWorkOrderRequest;
        }

        private static string GenerateResponseForPublishEvent(CreateWorkOrderResponse createWorkOrderResponse)
        {
            return createWorkOrderResponse.ItemNumber;
        }
    }
}

