﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetSystemStatusByNameHandler : IQueryHandler<GetSystemStatusByNameQuery, SystemStatusDto>
    {
        private readonly IMapper mapper;
        private readonly ISystemStatusService systemStatusService;

        public GetSystemStatusByNameHandler(
            IMapper mapper,
            ISystemStatusService systemStatusService)
        {
            this.mapper = mapper;
            this.systemStatusService = systemStatusService;
        }

        public Task<SystemStatusDto> Handle(GetSystemStatusByNameQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var systemStatus = systemStatusService.GetSystemStatusByName(request.Name);
            var result = mapper.Map<SystemStatus, SystemStatusDto>(systemStatus);
            return Task.FromResult(result);
        }

        private static bool IsValidRequest(GetSystemStatusByNameQuery request)
        {
            return (request != null && request.Name != string.Empty);
        }
    }
}