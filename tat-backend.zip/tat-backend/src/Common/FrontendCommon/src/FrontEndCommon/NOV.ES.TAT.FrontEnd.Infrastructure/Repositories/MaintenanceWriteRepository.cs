﻿using Microsoft.EntityFrameworkCore;
using NOV.ES.Framework.Core.Data.Repositories;
using NOV.ES.TAT.FrontEnd.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NOV.ES.TAT.FrontEnd.Infrastructure
{
    public class MaintenanceWriteRepository
        : GenericWriteRepository<MaintenanceModel>, 
        IMaintenanceWriteRepository
    {
        public readonly MaintenanceDBContext maintenanceDBContext;
        public MaintenanceWriteRepository(MaintenanceDBContext context)
            : base(context)
        {
            this.maintenanceDBContext = context;
        }

        public void SetUserProvider(string actionBy)
        {
            maintenanceDBContext.UserProvider = actionBy;
        }

        public async Task<MaintenanceModel?> GetById(int id)
        {
            return await Task.Run(() => maintenanceDBContext.MaintenanceModels
               .AsNoTracking()               
               .Where(x => x.Id == id && x.IsActive)
               .FirstOrDefault());
        }

        public  void AddSystemDownMessage(MaintenanceModel maintenanceModel)
        {
            maintenanceDBContext.MaintenanceModels.Add(maintenanceModel);
        }

        public int SaveChanges()
        {
            return maintenanceDBContext.SaveChanges();
        }

        public Task<int> SaveChangesAsync(CancellationToken cancellationToken)
        {
            return maintenanceDBContext.SaveChangesAsync(cancellationToken);
        }
    }
}
