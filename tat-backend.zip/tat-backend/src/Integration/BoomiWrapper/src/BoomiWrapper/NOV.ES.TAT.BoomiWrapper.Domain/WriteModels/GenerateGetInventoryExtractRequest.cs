﻿namespace NOV.ES.TAT.BoomiWrapper.Domain.WriteModels
{
    public class GenerateGetInventoryExtractRequest : BoomiRequestBaseModel
    {
        public string UniqueOrderReferenceNumber { get; set; }
    }
}
