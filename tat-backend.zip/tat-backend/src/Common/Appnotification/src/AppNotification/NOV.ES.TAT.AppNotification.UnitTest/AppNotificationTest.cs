namespace NOV.ES.TAT.AppNotification.UnitTest
{
    [TestClass]
    public class AppNotificationTest
    {
        [TestMethod]
        public void TestMethod1()
        {
            Assert.IsNull(null);
        }
    }
}