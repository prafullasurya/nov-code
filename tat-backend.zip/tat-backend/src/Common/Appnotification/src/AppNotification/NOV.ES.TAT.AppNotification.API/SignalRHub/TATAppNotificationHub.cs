﻿using Microsoft.AspNetCore.SignalR;
using NOV.ES.TAT.AppNotification.API.Models;

namespace NOV.ES.TAT.AppNotification.API.SignalRHub
{
    public class TATAppNotificationHub
        : Hub<ITATAppNotificationHub>
    {
        public async Task RequestConnectionId()
            => await Clients.Caller.GetConnectionId(Context.ConnectionId);

        public async Task AddToGroup(string connectionId, string groupName)
            => await Groups.AddToGroupAsync(connectionId, groupName);

        public async Task RemoveFromGroup(string connectionId, string groupName)
            => await Groups.RemoveFromGroupAsync(connectionId, groupName);
    }
}
