﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetLanguageByNameHandler : IQueryHandler<GetLanguageByNameQuery, LanguageDto>
    {
        private readonly IMapper mapper;
        private readonly ILanguageService languageService;

        public GetLanguageByNameHandler(
            IMapper mapper,
            ILanguageService languageService)
        {
            this.mapper = mapper;
            this.languageService = languageService;
        }

        public Task<LanguageDto> Handle(GetLanguageByNameQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var language = languageService.GetLanguageByName(request.LanguageName);
            var result = mapper.Map<Language, LanguageDto>(language);
            return Task.FromResult(result);
        }
        private static bool IsValidRequest(GetLanguageByNameQuery request)
        {
            return (request != null && request.LanguageName != string.Empty);
        }
    }
}