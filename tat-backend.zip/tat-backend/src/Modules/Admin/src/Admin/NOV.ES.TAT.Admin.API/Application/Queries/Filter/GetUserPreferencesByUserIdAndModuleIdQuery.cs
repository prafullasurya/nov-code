﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Admin.API.DTOs;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetUserPreferencesByUserIdAndModuleIdQuery : IQuery<PagedResult<UserPreferenceDto>>
    {
        public Paging PagingParameters { get; private set; }
        public int UserId { get; private set; }
        public int ModuleId { get; private set; }
        public GetUserPreferencesByUserIdAndModuleIdQuery(Paging pagingParameters, int userId, int moduleId)
        {
            this.PagingParameters = pagingParameters;
            this.UserId = userId;
            this.ModuleId = moduleId;
        }
    }
}
