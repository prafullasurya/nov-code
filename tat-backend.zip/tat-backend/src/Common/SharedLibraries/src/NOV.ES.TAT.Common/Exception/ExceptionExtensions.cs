﻿using Microsoft.AspNetCore.Mvc.Filters;
using System.Net;

namespace NOV.ES.TAT.Common.Exception
{
    public static class ExceptionExtensions
    {
        private static readonly Dictionary<string, Func<ExceptionContext, int, string, ErrorModel>> exceptionMap
            = new Dictionary<string, Func<ExceptionContext, int, string, ErrorModel>>()
        {
            {Constants.ArgumentException, ArgumentExceptionHandler},
            {Constants.NullReferenceException, NullReferenceExceptionHandler},
            {Constants.TimeoutException, TimeoutExceptionHandler},
            {Constants.SqlException , SqlExceptionHandler }

        };
        public static ErrorModel GetCustomErrorModel(ExceptionContext context, string requestId, string traceId, int moduleNo, string baseHelpUrl)
        {
            var errorModel = new ErrorModel
            {
                Code = (int)HttpStatusCode.InternalServerError,
                Error = $"{moduleNo}-{Constants.UNKNOWN}",
                Message = Constants.EX_INTERNAL_ERROR,
                Details = context.Exception.Message,
                RequestId = requestId,
                TraceId = traceId,
                HelpUrl = $"{baseHelpUrl}/ISE"
            };

            if (exceptionMap.TryGetValue(context.Exception.GetType().Name
                , out Func<ExceptionContext, int, string, ErrorModel> customExceptionHandler))
                errorModel = customExceptionHandler(context, moduleNo, baseHelpUrl);

            return errorModel;

        }
        private static ErrorModel ArgumentExceptionHandler(ExceptionContext context, int moduleNo, string baseHelpUrl)
        {
            var errorModel = new ErrorModel();
            errorModel.Code = (int)HttpStatusCode.BadRequest;
            errorModel.Error = $"{moduleNo}-{Constants.ARGUMENT_EXCEPTION}";
            errorModel.Message = Constants.EX_ARGUMENT_EXCEPTION;
            errorModel.Details = context.Exception.Message;
            errorModel.HelpUrl = $"{baseHelpUrl}/BadRequestError";
            return errorModel;
        }
        private static ErrorModel TimeoutExceptionHandler(ExceptionContext context, int moduleNo, string baseHelpUrl)
        {
            var errorModel = new ErrorModel();
            errorModel.Error = $"{moduleNo}-{Constants.CONNECTION_LOST}";
            errorModel.Message = Constants.EX_CONNECTION_TIMEOUT;
            errorModel.Details = context.Exception.Message;
            errorModel.HelpUrl = $"{baseHelpUrl}/TimeoutError";
            return errorModel;
        }
        private static ErrorModel NullReferenceExceptionHandler(ExceptionContext context, int moduleNo, string baseHelpUrl)
        {
            var errorModel = new ErrorModel();
            errorModel.Error = $"{moduleNo}-{Constants.NULL_REFERENCE}";
            errorModel.Message = Constants.EX_NULL_REFERENCE;
            errorModel.Details = context.Exception.Message;
            errorModel.HelpUrl = $"{baseHelpUrl}/NullReferenceError";
            return errorModel;

        }
        private static ErrorModel SqlExceptionHandler(ExceptionContext context, int moduleNo, string baseHelpUrl)
        {
            var errorModel = new ErrorModel();
            errorModel.Error = $"{moduleNo}-{Constants.SQL_EXCEPTION}";
            errorModel.Message = Constants.EX_SQL_EXCEPTION;
            errorModel.Details = context.Exception.Message;
            errorModel.HelpUrl = $"{baseHelpUrl}/SqlExceptionError";
            return errorModel;
        }
    }
}
