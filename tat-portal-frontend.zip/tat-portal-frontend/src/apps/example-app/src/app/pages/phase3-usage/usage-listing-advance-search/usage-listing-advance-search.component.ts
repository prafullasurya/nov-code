import { Component, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'usage-listing-advance-search',
  templateUrl: './usage-listing-advance-search.component.html',
  styleUrls: ['./usage-listing-advance-search.component.scss'],
})
export class UsageListingAdvanceSearchComponent {
  
}
