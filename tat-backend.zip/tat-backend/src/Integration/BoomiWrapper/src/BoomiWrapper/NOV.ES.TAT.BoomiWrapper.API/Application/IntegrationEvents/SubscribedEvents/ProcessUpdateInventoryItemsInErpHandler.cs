﻿using Newtonsoft.Json;
using NOV.ES.Framework.Core.Messaging.IntegrationEvents;
using NOV.ES.Framework.Core.Sagas;
using NOV.ES.TAT.BoomiWrapper.API.Application.IntegrationEvents.PublishEvents;
using NOV.ES.TAT.BoomiWrapper.Domain.Event;
using NOV.ES.TAT.BoomiWrapper.DomainService;
using NOV.ES.TAT.Common.CompressDecompress;

namespace NOV.ES.TAT.BoomiWrapper.API.Application.IntegrationEvents.SubscribedEvents
{
    public class ProcessUpdateInventoryItemsInErpHandler
        : IIntegrationEventHandler<ProcessUpdateInventoryItemsInErp>
    {
        private readonly ILogger<ProcessUpdateInventoryItemsInErpHandler> logger;
        private readonly IInventoryItemsService inventoryItemsService;
        private readonly IIntegrationEventBus integrationEventBus;

        public ProcessUpdateInventoryItemsInErpHandler(
            ILogger<ProcessUpdateInventoryItemsInErpHandler> logger
            , IInventoryItemsService inventoryItemsService
            , IIntegrationEventBus integrationEventBus)
        {
            this.logger = logger;
            this.inventoryItemsService = inventoryItemsService;
            this.integrationEventBus = integrationEventBus;
        }

        public Task Handle(ProcessUpdateInventoryItemsInErp @event)
        {
            logger.LogInformation("----- Consuming Event: Process Update Erp Items Integration Event");
            logger.LogInformation("----- CorelationId is {id}", @event.CorelationId);
            logger.LogInformation("----- Event Detail is {info}", @event.JsonStringData);

            var processInventoryItemsInErp = JsonConvert.DeserializeObject<ProcessInventoryItemsInErp>(CompressDecompress
                .DecompressData(@event.JsonStringData));
            var boomiRequestId = inventoryItemsService.ProcessErpItems(@event, processInventoryItemsInErp, ErpOperations.UPDATE);

            #region publish event

            ProcessedUpdateInventoryItemsInErp success =
            new(
                @event.KeyId,
                @event.CorelationId,
                CompressDecompress.CompressData(JsonConvert.SerializeObject(processInventoryItemsInErp)),
                DateTime.UtcNow,
                SagaEventExecutionResult.Success,
                @event.ActionBy
                );

            logger.LogInformation("Publish Processed Update Erp Items  - ProcessedUpdateInventoryItemsInErp.");
            integrationEventBus.Publish(success);
            #endregion

            return Task.CompletedTask;
        }
    }
}


