﻿namespace NOV.ES.TAT.BoomiWrapper.DomainService.RequestModel
{
    public class BatchNextNumberRequest : BaseRequestModel
    {
    }
}
