﻿using NOV.ES.TAT.FrontEnd.Domain;
using NOV.ES.TAT.FrontEnd.Domain.WriteModels;

namespace NOV.ES.TAT.FrontEnd.DomainService
{
    public interface IMaintenanceService
    {
        List<MaintenanceModel> GetMaintenance();
        MaintenanceModel AddMaintenanceInfo(AddMaintenanceModel request);
        Task<bool> MarkAsCompleted(int id);
    }
}
