import { Component, OnInit } from '@angular/core';
import { ConfirmationService, MessageService } from 'primeng/api';


interface City {
  name: string,
  code: string
}
@Component({
  selector: 'usage-basic-screen',
  templateUrl: './usage-basic-screen.component.html',
  styleUrls: ['./usage-basic-screen.component.scss']
})
export class UsageBasicScreenComponent {
  
  // activeIndex1: number = 0;

  // activeIndex2: number = 0;

  // scrollableTabs: any[] = Array.from({ length: 50 }, (_, i) => ({ title: `Tab ${i + 1}`, content: `Tab ${i + 1} Content` }));

}
