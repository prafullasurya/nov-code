﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetCompanyDivisionByCompanyConfigIdHandler : IQueryHandler<GetCompanyDivisionByCompanyConfigIdQuery, IEnumerable<CompanyDivisionDto>>
    {
        private readonly IMapper mapper;
        private readonly ICompanyDivisionService companyDivisionService;

        public GetCompanyDivisionByCompanyConfigIdHandler(
            IMapper mapper,
            ICompanyDivisionService companyDivisionService)
        {
            this.mapper = mapper;
            this.companyDivisionService = companyDivisionService;
        }

        public Task<IEnumerable<CompanyDivisionDto>> Handle(GetCompanyDivisionByCompanyConfigIdQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var companyDivision = companyDivisionService.GetDivisionsByCompanyConfigId(request.CompanyConfigId);
            var result = mapper.Map<IEnumerable<CompanyDivision>, IEnumerable<CompanyDivisionDto>>(companyDivision);
            return Task.FromResult(result);
        }
        private static bool IsValidRequest(GetCompanyDivisionByCompanyConfigIdQuery request)
        {
            return (request != null && request.CompanyConfigId != 0);
        }
    }
}