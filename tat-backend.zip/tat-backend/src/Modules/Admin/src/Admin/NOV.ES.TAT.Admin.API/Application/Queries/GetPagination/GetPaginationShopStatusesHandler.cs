﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.API.Helper;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetPaginationShopStatusesHandler : IQueryHandler<GetPaginationShopStatusesQuery, PagedResult<ShopStatusDto>>
    {
        private readonly IMapper mapper;
        private readonly IShopStatusService shopStatusService;
        private readonly IHttpContextAccessor httpContextAccessor;

        public GetPaginationShopStatusesHandler(
            IMapper mapper,
            IShopStatusService shopStatusService,
            IHttpContextAccessor httpContextAccessor)
        {            
            this.mapper = mapper;
            this.shopStatusService = shopStatusService;
            this.httpContextAccessor = httpContextAccessor;
        }
        public Task<PagedResult<ShopStatusDto>> Handle(GetPaginationShopStatusesQuery request,
            CancellationToken cancellationToken)
        {
            var shopStatuses = shopStatusService.GetShopStatuses(request.PagingParameters);
            var result = mapper.Map<PagedResult<ShopStatus>, PagedResult<ShopStatusDto>>(shopStatuses);
            PagingHelper.AddPagingMetadata<ShopStatusDto>(result, httpContextAccessor);
            return Task.FromResult(result);
        }
    }
}
