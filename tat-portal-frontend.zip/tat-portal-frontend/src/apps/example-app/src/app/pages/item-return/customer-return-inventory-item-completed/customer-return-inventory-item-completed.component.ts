import { Component} from '@angular/core';

interface City {
  name: string,
  code: string
}
@Component({
  selector: 'customer-return-inventory-item-completed',
  templateUrl: './customer-return-inventory-item-completed.component.html',
  styleUrls: ['./customer-return-inventory-item-completed.component.scss']
})
export class CustomerReturnInventoryItemCompletedComponent {


}
