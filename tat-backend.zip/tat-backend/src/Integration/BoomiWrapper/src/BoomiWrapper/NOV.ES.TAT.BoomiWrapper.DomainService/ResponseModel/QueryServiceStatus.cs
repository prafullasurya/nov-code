﻿namespace NOV.ES.TAT.BoomiWrapper.DomainService.ResponseModel
{
    public class QueryServiceStatus
    {
        public List<InventoryExtractDetails> InventoryExtractDetails { get; set; }
    }
}
