import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'usage-list',
  templateUrl: './usage-list.component.html',
  styleUrls: ['./usage-list.component.scss'],
})
export class UsageListComponent {
  displayOption: boolean;
  displayCreateNft: boolean;
  
  showOptionDialog() {
    this.displayOption = true;
  }
  showCreateNftDialog() {
    this.displayCreateNft = true;
  }
}
