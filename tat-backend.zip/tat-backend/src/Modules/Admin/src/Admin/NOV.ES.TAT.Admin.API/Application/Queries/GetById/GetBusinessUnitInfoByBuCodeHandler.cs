﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetBusinessUnitInfoByBuCodeHandler : IQueryHandler<GetBusinessUnitInfoByBuCodeQuery, BusinessUnitInfoDto>
    {
        private readonly IMapper mapper;
        private readonly IBusinessUnitInfoService businessUnitInfoService;

        public GetBusinessUnitInfoByBuCodeHandler(
            IMapper mapper,
            IBusinessUnitInfoService businessUnitInfoService)
        {
            this.mapper = mapper;
            this.businessUnitInfoService = businessUnitInfoService;
        }

        public Task<BusinessUnitInfoDto> Handle(GetBusinessUnitInfoByBuCodeQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var businessUnitInfo = businessUnitInfoService.GetBusinessUnitInfoByBuCode(request.BusinessUnitCode);
            var result = mapper.Map<BusinessUnitInfo, BusinessUnitInfoDto>(businessUnitInfo);
            return Task.FromResult(result);
        }
        private static bool IsValidRequest(GetBusinessUnitInfoByBuCodeQuery request)
        {
            return (request != null);
        }
    }
}