﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NOV.ES.TAT.EmailService.API
{
    public static class Constants
    {
        public const string EMAIL_SEND_ERROR_MSG = "Error to send an email";
        public const string EMAIL_SEND_SUCCESS_MSG = "Email sent successfully";
    }
}
