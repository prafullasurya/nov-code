﻿using Newtonsoft.Json;
using NOV.ES.Framework.Core.Sagas;

namespace NOV.ES.TAT.BoomiWrapper.API.Application.IntegrationEvents.SubscribedEvents
{
    public class GenerateJobCreation
        : SagaEvent
    {
        public GenerateJobCreation(Guid corelationId,
            string jsonStringData)
        {
            this.CorelationId = corelationId;
            this.JsonStringData = jsonStringData;
            this.SagaEventExecutionResult = SagaEventExecutionResult.Success;
        }

        [JsonConstructor]
        public GenerateJobCreation(Guid corelationId,
            string jsonStringData,
            SagaEventExecutionResult executionResult)
        {
            this.CorelationId = corelationId;
            this.JsonStringData = jsonStringData;
            this.SagaEventExecutionResult = executionResult;
        }
    }
}

