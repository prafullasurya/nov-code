﻿using System.Data;

namespace NOV.ES.TAT.EmailService.Helper
{
    public class EmailContent
    {
        public string? From { get; set; }
        public string? Subject { get; set; }
        public string? Body { get; set; }
        private DataSet? XmlDataSet { get; set; }
        public string? ResourceFilePath { get; set; }
        public string? XmlData { get; set; }

        public EmailContent(string resourceFilePath)
        {
            this.ResourceFilePath = resourceFilePath;
            LoadContentFromFile();
        }

        public EmailContent(DataSet xmlDataSet)
        {
            this.XmlDataSet = xmlDataSet;
            LoadContentFromFile(xmlDataSet);
        }
        public void LoadContentFromFile()
        {
            XmlDataSet = new DataSet("XmlDataSet");
            XmlDataSet.ReadXml(ResourceFilePath);
            From = XmlDataSet.Tables[0].Rows[0]["from"].ToString();
            Subject = XmlDataSet.Tables[0].Rows[0]["subject"].ToString();

            Body = XmlDataSet.Tables[0].Rows[0]["body"].ToString();
            if (!string.IsNullOrEmpty(Body))
            {
                if (Body.Contains("[footer]"))
                {
                    Body = Body.Replace("[footer]", "Footer Text");
                }
                if ( Body.Contains("[TAT_App_Link]"))
                {
                    Body = Body.Replace("[TAT_App_Link]", "TAT App Link for Object View");
                }
            }
        }

        public void LoadContentFromFile(DataSet xmlDataSet)
        {           
            From = xmlDataSet.Tables[0].Rows[0]["from"].ToString();
            Subject = xmlDataSet.Tables[0].Rows[0]["subject"].ToString();

            Body = xmlDataSet.Tables[0].Rows[0]["body"].ToString();
            if (!string.IsNullOrEmpty(Body))
            {
                if (Body.Contains("[footer]"))
                {
                    Body = Body.Replace("[footer]", "Footer Text");
                }
                if (Body.Contains("[TAT_App_Link]"))
                {
                    Body = Body.Replace("[TAT_App_Link]", "TAT App Link for Object View");
                }
            }
        }
    }
}
