import { Component, OnInit } from '@angular/core';
import {TreeNode} from 'primeng/api';
import { ProductService } from '../../models/productservice';
import { Product } from '../../models/product';

interface City {
  name: string,
  code: string
}

@Component({
  selector: 'tat-portal-frontend-rig-well-site-info',
  templateUrl: './rig-well-site-info.component.html',
  styleUrls: ['./rig-well-site-info.component.scss']
})
export class RigWellSiteInfoComponent implements OnInit {
  cities: City[];
  ChangeSequenceDisplay: boolean;
  productService: any;
  products: any;
  
  ngOnInit() {
    this.productService.getProductsWithOrdersSmall().then((data: any) => this.products = data);
}

    ChangeSequenceDialog() {
    this.ChangeSequenceDisplay = true;
    }

}
