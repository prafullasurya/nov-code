﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetPaginationModulesHandler
           : IQueryHandler<GetPaginationModulesQuery, PagedResult<ModuleDto>>
    {
        private readonly IMapper mapper;
        private readonly IModuleService moduleService;
        private readonly IHttpContextAccessor httpContextAccessor;

        public GetPaginationModulesHandler(
             IMapper mapper
            , IModuleService moduleService
            , IHttpContextAccessor httpContextAccessor)
        {            
            this.mapper = mapper;
            this.moduleService = moduleService;
            this.httpContextAccessor = httpContextAccessor;
        }

        public Task<PagedResult<ModuleDto>> Handle(GetPaginationModulesQuery request,
          CancellationToken cancellationToken)
        {
            var modules = moduleService.GetModules(request.PagingParameters);
            var result = mapper.Map<PagedResult<Module>, PagedResult<ModuleDto>>(modules);

            if (result.Paging != null)
            {
                httpContextAccessor.HttpContext.Response.Headers.Add("X-Paging-PageCount", result.TotalNumberOfPages.ToString());
                httpContextAccessor.HttpContext.Response.Headers.Add("X-Paging-TotalRecordCount", result.TotalNumberOfItems.ToString());
                httpContextAccessor.HttpContext.Response.Headers.Add("X-Paging-PageIndex", result.Paging.PageIndex.ToString());
                httpContextAccessor.HttpContext.Response.Headers.Add("X-Paging-PageSize", result.Paging.PageSize.ToString());
            }
            return Task.FromResult(result);
        }
    }
}