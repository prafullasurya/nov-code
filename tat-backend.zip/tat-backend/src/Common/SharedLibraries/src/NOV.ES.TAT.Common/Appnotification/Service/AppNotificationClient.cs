﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using NOV.ES.Framework.Core.Caching;
using NOV.ES.TAT.Common.Appnotification.Models;
using NOV.ES.TAT.Common.ServiceBase;
using System.Net.Http.Headers;
using System.Text;
using TaskStatus = NOV.ES.TAT.Common.Appnotification.Models.TaskStatus;

namespace NOV.ES.TAT.Common.Appnotification.Service
{
    /// <summary>
    /// This common class provides an interface to 
    /// 1. Save Saga Events Progress and 
    /// 2. send realtime notification to group of users.
    /// </summary>
    public class AppNotificationClient
        : InternalServiceBaseClient, IAppNotificationClient
    {
        private const int dafaultCacheExpirationInDays = 7;
        private readonly ICache cache;
        public AppNotificationClient(ILogger<InternalServiceBaseClient> logger,
            IConfiguration configuration, ICache cache) : base(logger, configuration)
        {
            this.cache = cache;
        }

        /// <summary>
        /// Gets cached event progress details.
        /// </summary>
        /// <param name="primaryEvent">Primary Event which initiated the saga orchestrator. e.g. Create CTS Header</param>
        /// <param name="keyId">Aggregate root id of domain object. e.g. Customer Transfer Slip Id</param>
        /// <param name="secondaryKeyId">Aggregate id of subtask domain object. e.g. Item Id</param>
        /// <returns>Returns list of Event Entries. It contains status of Primary events and its subtask executio status.</returns>
        public List<EventEntry> GetEventEntries(Event primaryEvent, string keyId, string secondaryKeyId = null)
        {
            return this.cache.Get<List<EventEntry>>(GetEventKey(primaryEvent, keyId, secondaryKeyId));
        }

        /// <summary>
        /// Creates Primary event and list of subtask associated with that event and 
        /// cache its initial status.
        /// </summary>
        /// <param name="primaryEvent">Primary Event which initiated the saga orchestrator. e.g. Create CTS Header</param>
        /// <param name="keyId">Aggregate root id of domain object. e.g. Customer Transfer Slip Id</param>
        /// <param name="secondaryKeyId">Aggregate id of subtask domain object. e.g. Item Id</param>
        public void CreateEventProgressStatus(Event primaryEvent, string keyId,
            string secondaryKeyId = null)
        {
            this.logger.LogInformation("About to save Event Record in redis.");
            EventProgress eventProgress = new EventProgress(primaryEvent, keyId);

            AddEventEntryToCache(GetEventKey(primaryEvent, keyId, secondaryKeyId), eventProgress);
        }

        /// <summary>
        /// Update subtask execution status and send notification to group.
        /// </summary>
        /// <param name="primaryEvent">Primary Event which initiated the saga orchestrator. e.g. Create CTS Header</param>
        /// <param name="keyId">Aggregate root id of domain object. e.g. Customer Transfer Slip Id</param>
        /// <param name="subTaskId">Id of Sub Task of Primary Events</param>
        /// <param name="taskStatus">Sub Task </param>
        /// <param name="notificationMethod">Notification method name to be called.</param>
        /// <param name="notificationJson">Payload of notification in json</param>
        /// <param name="secondaryKeyId">Aggregate id of subtask domain object. e.g. Item Id</param>
        /// <param name="errorMessage">Error message if task fails otherwise null.</param>
        /// <param name="action">Possible action user can perform to fix the error.</param>
        public void UpdateSubTaskEventProgressAndNotify(Event primaryEvent, string keyId,
            int subTaskId, TaskStatus taskStatus,
            string notificationMethod, string notificationJson,
            string secondaryKeyId = null,
            string errorMessage = "", string action = "")
        {
            this.logger.LogInformation("About to update Event status in redis.");

            var key = GetEventKey(primaryEvent, keyId, secondaryKeyId);

            var entries = GetEventEntries(primaryEvent, keyId, secondaryKeyId);
            if (entries == null)
            {
                return;
            }
            var count = entries.Count;
            var subTask = entries[count - 1].EventProgress?.SubTasks?.Where(k => k.SubTaskId == subTaskId).FirstOrDefault();
            if (subTask != null)
            {
                subTask.TaskStatus = taskStatus;
                subTask.ErrorMessage = errorMessage;
                subTask.Action = action;

                this.cache.Add(key, entries, new TimeSpan(dafaultCacheExpirationInDays, 0, 0, 0));
            }
            SendEventProgressNotification(notificationMethod, notificationJson);
            return;
        }


        /// <summary>
        /// Update cache expiration of event entries.
        /// Use this to set cache expiration after successfully completing all subtask.
        /// </summary>
        /// <param name="primaryEvent">Primary Event which initiated the saga orchestrator. e.g. Create CTS Header</param>
        /// <param name="keyId">Aggregate root id of domain object. e.g. Customer Transfer Slip Id</param>
        /// <param name="secondaryKeyId">Aggregate id of subtask domain object. e.g. Item Id</param>
        /// <param name="inMinutes">Cache expiration time in minutes.</param>
        /// <returns>Cache key</returns>
        public string UpdateCacheExpiration(Event primaryEvent, string keyId, string secondaryKeyId = null, int inMinutes = 60)
        {
            var key = GetEventKey(primaryEvent, keyId, secondaryKeyId);
            var entries = GetEventEntries(primaryEvent, keyId, secondaryKeyId);
            if (entries != null)
            {
                this.cache.Add(key, entries, new TimeSpan(0, inMinutes, 0));
                key = null;
            }
            return key;
        }

        /// <summary>
        /// Removes event entry cached value from cache.
        /// Use this to remove cache after successfully completing all subtask.
        /// </summary>
        /// <param name="primaryEvent">Primary Event which initiated the saga orchestrator. e.g. Create CTS Header</param>
        /// <param name="keyId">Aggregate root id of domain object. e.g. Customer Transfer Slip Id</param>
        /// <param name="secondaryKeyId">Aggregate id of subtask domain object. e.g. Item Id</param>        
        /// <returns>Cache key</returns>
        public string RemoveEventEntryCache(Event primaryEvent, string keyId, string secondaryKeyId = null)
        {
            var key = GetEventKey(primaryEvent, keyId, secondaryKeyId);
            cache.Remove(key);
            return key;
        }



        private string GetEventKey(Event primaryEvent, string keyId, string secondaryKeyId = null)
        {
            var key = $"{configuration["deployenvironment"]}_{primaryEvent.ToString()}_{keyId}";
            if (!string.IsNullOrEmpty(secondaryKeyId))
            {
                key = key + "_" + secondaryKeyId.Trim();
            }
            return key;
        }

        private bool AddEventEntryToCache(string key, EventProgress eventProgress)
        {
            bool result = false;

            List<EventEntry> cachedVal = null;
            cachedVal = this.cache.Get<List<EventEntry>>(key);
            int index = 1;
            if (cachedVal != null)
            {
                index = cachedVal.Count + 1;
                this.cache.Remove(key);
            }
            else
            {
                cachedVal = new List<EventEntry>();
            }

            cachedVal.Add(new EventEntry(index, eventProgress));
            this.cache.Add(key, cachedVal, new TimeSpan(dafaultCacheExpirationInDays, 0, 0, 0));

            result = true;

            return result;
        }

        private bool SendEventProgressNotification(string notificationMethod, string notificationJson)
        {
            bool result = false;
            logger.LogInformation("Get Security token to make internal call to MDM service.");
            var accessToken = GetIdentityToken().Result.AccessToken;

            using (var httpClient = new HttpClient())
            {

                var stringContent = new StringContent(notificationJson, UnicodeEncoding.UTF8, "application/json");

                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer"
                , accessToken);

                var responseTask = httpClient.PostAsync($"{configuration["AppNotificationBaseUrl"]}/appnotificationsvc/AppNotification/{notificationMethod}", stringContent);


                responseTask.Wait();
                var response = responseTask.Result;
                if (response != null && !response.IsSuccessStatusCode)
                {
                    result = false;
                }
            }

            return result;
        }
    }
}
