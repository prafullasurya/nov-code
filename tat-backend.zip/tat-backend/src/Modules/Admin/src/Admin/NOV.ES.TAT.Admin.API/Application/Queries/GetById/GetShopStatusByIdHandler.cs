﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetShopStatusByIdHandler : IQueryHandler<GetShopStatusByIdQuery, ShopStatusDto>
    {
        private readonly IMapper mapper;
        private readonly IShopStatusService shopStatusService;

        public GetShopStatusByIdHandler(
            IMapper mapper,
            IShopStatusService shopStatusService)
        {
            this.mapper = mapper;
            this.shopStatusService = shopStatusService;
        }

        public Task<ShopStatusDto> Handle(GetShopStatusByIdQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var shopStatus = shopStatusService.GetShopStatusById(request.ShopStatusId);
            return Task.FromResult(mapper.Map<ShopStatus, ShopStatusDto>(shopStatus));
        }

        private static bool IsValidRequest(GetShopStatusByIdQuery request)
        {
            return (request != null && request.ShopStatusId != 0);
        }
    }
}
