﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using NOV.ES.Framework.Core.CQRS.Commands;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.CustomerTransfer.EventSourcing.API.Application.Commands;
using NOV.ES.TAT.FrontEnd.API.Application;
using NOV.ES.TAT.FrontEnd.API.DTOs;
using System.Net;

namespace NOV.ES.TAT.FrontEnd.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MaintenanceController : ControllerBase
    {
        private readonly ILogger<MaintenanceController> logger;
        private readonly IQueryBus queryBus;
        private readonly ICommandBus commandBus;
        public MaintenanceController(
            ILogger<MaintenanceController> logger,
            IQueryBus queryBus,
            ICommandBus commandBus)
        {
            this.logger = logger;
            this.queryBus = queryBus;
            this.commandBus = commandBus;
        }

        [HttpGet]
        [Route("SystemDown")]
        [ProducesResponseType(typeof(MaintenanceDto), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(string), (int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IAsyncEnumerable<MaintenanceDto>>> GetMaintenance()
        {
            MaintenanceQuery getMaintenanceQuery = new MaintenanceQuery();
            var result = await queryBus.Send<MaintenanceQuery, IEnumerable<MaintenanceDto>>(getMaintenanceQuery);

            if (result == null)
                return NotFound($" not found");

            return Ok(result);
        }

        [HttpPost]
        [Route("addsystemdownmessage")]
        [ProducesResponseType(typeof(bool), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> AddMaintenanceInfo([FromBody] AddMaintenanceInfoCommand command)
        {
            var result = await commandBus.Send<AddMaintenanceInfoCommand, ContentResult>(command);
            if (result.StatusCode == (int)HttpStatusCode.BadRequest)
                return BadRequest(JsonConvert.DeserializeObject(result.Content));
            return Ok(result);
        }


        [HttpPost]
        [Route("markascompleted/{id}")]
        [ProducesResponseType(typeof(bool), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> MarkAsComplete([FromRoute] int id)
        {
            var result = await commandBus.Send<MarkAsCompletedCommaand, ContentResult>(new MarkAsCompletedCommaand(id));
            if (result.StatusCode == (int)HttpStatusCode.BadRequest)
                return BadRequest(JsonConvert.DeserializeObject(result.Content));
            return Ok(result);
        }

    }
}
