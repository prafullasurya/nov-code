﻿namespace NOV.ES.TAT.BoomiWrapper.Domain.WriteModels
{
    public class GenerateItemAvailabilityRequest : BoomiRequestBaseModel
    {
        public string PartNumber { get; set; }
        public int BusinessUnit { get; set; }
        public string Location { get; set; }
        public string Mode { get; set; }
        public string SerialNumber { get; set; }
    }
}
