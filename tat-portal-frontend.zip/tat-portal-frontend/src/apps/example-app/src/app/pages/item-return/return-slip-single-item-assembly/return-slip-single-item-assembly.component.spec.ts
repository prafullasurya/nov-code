import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReturnSlipSingleItemAssemblyComponent } from './return-slip-single-item-assembly.component';

describe('ReturnSlipSingleItemAssemblyComponent', () => {
  let component: ReturnSlipSingleItemAssemblyComponent;
  let fixture: ComponentFixture<ReturnSlipSingleItemAssemblyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReturnSlipSingleItemAssemblyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReturnSlipSingleItemAssemblyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
