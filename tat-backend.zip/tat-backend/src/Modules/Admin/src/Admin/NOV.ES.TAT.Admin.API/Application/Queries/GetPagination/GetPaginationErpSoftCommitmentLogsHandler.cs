﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.API.Helper;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetPaginationErpSoftCommitmentLogsHandler
           : IQueryHandler<GetPaginationErpSoftCommitmentLogsQuery, PagedResult<ErpSoftCommitmentLogDto>>
    {
        private readonly IMapper mapper;
        private readonly IErpSoftCommitmentLogService erpSoftCommitmentLogService;
        private readonly IHttpContextAccessor httpContextAccessor;

        public GetPaginationErpSoftCommitmentLogsHandler(
            IMapper mapper
            ,IErpSoftCommitmentLogService erpSoftCommitmentLogService
            , IHttpContextAccessor httpContextAccessor)
        {            
            this.mapper = mapper;
            this.erpSoftCommitmentLogService = erpSoftCommitmentLogService;
            this.httpContextAccessor = httpContextAccessor;
        }

        public Task<PagedResult<ErpSoftCommitmentLogDto>> Handle(GetPaginationErpSoftCommitmentLogsQuery request,
          CancellationToken cancellationToken)
        {
            var erpSoftCommitmentLogs = erpSoftCommitmentLogService.GetErpSoftCommitmentLogs(request.PagingParameters);
            var result = mapper.Map<PagedResult<ErpSoftCommitmentLog>, PagedResult<ErpSoftCommitmentLogDto>>(erpSoftCommitmentLogs);
            PagingHelper.AddPagingMetadata<ErpSoftCommitmentLogDto>(result, httpContextAccessor);
            return Task.FromResult(result);
        }
    }
}