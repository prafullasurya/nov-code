﻿using AutoMapper;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NOV.ES.Framework.Core.Data;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;
using NOV.ES.TAT.BoomiWrapper.Domain;
using NOV.ES.TAT.BoomiWrapper.Domain.ReadModel;
using NOV.ES.TAT.BoomiWrapper.Domain.WriteModels;
using NOV.ES.TAT.BoomiWrapper.DomainService.RequestModel;
using NOV.ES.TAT.BoomiWrapper.DomainService.ResponseModel;
using NOV.ES.TAT.BoomiWrapper.Infrastructure;
using NOV.ES.TAT.MDM.Domain;
using NOV.ES.TAT.MDM.DomainService;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Xml.Linq;

namespace NOV.ES.TAT.BoomiWrapper.DomainService.Service
{
    public class BoomiWrapperService : IBoomiWrapperService
    {
        private readonly HttpClient httpClient;
        private readonly IConfiguration configuration;
        private readonly ILogger<BoomiWrapperService> logger;
        private readonly IBoomiRequestResponseCommandRepository boomiRequestResponseCommandRepository;
        private readonly IBoomiRequestResponseQueryRepository boomiRequestResponseQueryRepository;
        private readonly IMapper mapper;
        private readonly IBusinessUnitService businessUnitService;
        private readonly ICompanyConfigService companyConfigService;
        private readonly ICompanyDivisionService companyDivisionService;
        private readonly IDivisionService divisionService;
        private readonly INotaFiscalInfoService notaFiscalInfoService;

        const string VATransaction = "VA";
        const string VBTransaction = "VB";
        const string VCTransaction = "VC";
        const string VDTransaction = "VD";
        const string VHTransaction = "VH";
        const string VSTransaction = "VS";

        public BoomiWrapperService(HttpClient httpClient
            , IConfiguration configuration
            , ILogger<BoomiWrapperService> logger
            , IBoomiRequestResponseCommandRepository boomiRequestResponseCommandRepository
            , IBoomiRequestResponseQueryRepository boomiRequestResponseQueryRepository
            , IMapper mapper
            , IBusinessUnitService businessUnitService
            , ICompanyConfigService companyConfigService
            , ICompanyDivisionService companyDivisionService
            , IDivisionService divisionService
            , INotaFiscalInfoService notaFiscalInfoService)
        {
            this.httpClient = httpClient;
            //HttpClientHandler clientHandler = new HttpClientHandler();
            //clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
            //this.httpClient = new HttpClient(clientHandler);
            this.configuration = configuration;
            this.logger = logger;
            this.boomiRequestResponseCommandRepository = boomiRequestResponseCommandRepository;
            this.boomiRequestResponseQueryRepository = boomiRequestResponseQueryRepository;
            this.mapper = mapper;
            this.businessUnitService = businessUnitService;
            this.companyDivisionService = companyDivisionService;
            this.companyConfigService = companyConfigService;
            this.divisionService = divisionService;
            this.notaFiscalInfoService = notaFiscalInfoService;
            httpClient.DefaultRequestHeaders.CacheControl = new CacheControlHeaderValue
            {
                NoCache = true,
                NoStore = true
            };

        }
        public async Task<BatchNextNumberResponse> GetBatchNextNumber(GenerateBatchNextNumberRequest generateBatchNextNumberRequest)
        {
            generateBatchNextNumberRequest.erpUserId = GetDefaultErpUserId(generateBatchNextNumberRequest.erpUserId);
            BatchNextNumberResponse batchNextNumberRequestResponse = new BatchNextNumberResponse();
            var request = JsonConvert.SerializeObject(generateBatchNextNumberRequest);
            BoomiRequestResponse boomiRequestResponse = new BoomiRequestResponse()
            {
                RequestId = generateBatchNextNumberRequest.RequestId,
                CorelationId = generateBatchNextNumberRequest.CorelationId,
                EventId = generateBatchNextNumberRequest.EventId,
                KeyName = generateBatchNextNumberRequest.KeyName,
                KeyValue = generateBatchNextNumberRequest.KeyValue,
                RequestDateTime = DateTime.UtcNow,
                RequestStatus = BoomiResponseType.Success.ToString(),
                RequestBody = request,
                RequestURL = "inBatchNumber/getBatchNextNumber",
                RequestMethod = "getBatchNextNumber",
                HttpVerb = "Post",
                ActionBy = string.IsNullOrEmpty(generateBatchNextNumberRequest.ActionBy)
                    ? "BoomiWrapper API" : generateBatchNextNumberRequest.ActionBy
            };
            RecordRequestPayload(boomiRequestResponse);
            var data = new StringContent(request, Encoding.UTF8, "application/json");

            httpClient.DefaultRequestHeaders.Add("KeyId", configuration["API_Key"]);
            var url = configuration["BatchNextNumber_URI"];
            var responseTask = httpClient.PostAsync(url, data);
            responseTask.Wait();
            var result = responseTask.Result;
            if (result.IsSuccessStatusCode)
            {
                batchNextNumberRequestResponse = await result.Content.ReadFromJsonAsync<BatchNextNumberResponse>();
            }

            boomiRequestResponse.Status = BoomiResponseType.Success.ToString();
            boomiRequestResponse.ResponseStatus = batchNextNumberRequestResponse.Success;
            boomiRequestResponse.RequestDateTime = DateTime.UtcNow;
            boomiRequestResponse.ResponseBody = JsonConvert.SerializeObject(batchNextNumberRequestResponse);
            if (!batchNextNumberRequestResponse.Success.Equals("1")
                && batchNextNumberRequestResponse.Errors != null && batchNextNumberRequestResponse.Errors.Any())
            {
                boomiRequestResponse.ErrorMessage = JsonConvert.SerializeObject(batchNextNumberRequestResponse.Errors);
                boomiRequestResponse.Status = BoomiResponseType.Failed.ToString();
            }
            RecordResponse(boomiRequestResponse);
            return batchNextNumberRequestResponse;
        }
        public async Task<RemitoResponse> GenerateRemito(GenerateRemitoRequest generateRemitoRequest)
        {
            generateRemitoRequest.erpUserId = GetDefaultErpUserId(generateRemitoRequest.erpUserId);
            RemitoResponse remitoResponse = new RemitoResponse();
            RemitoRequest remitoArgentinaInformationRequest = new RemitoRequest()
            {

                AddressNumber = generateRemitoRequest.AddressNumber,
                BusinessUnit = generateRemitoRequest.BusinessUnit,
                Company = generateRemitoRequest.Company,
                CustomerName = generateRemitoRequest.CustomerName,
                CustomerPOAFE = generateRemitoRequest.CustomerPOAFE,
                DocumentCode = generateRemitoRequest.DocumentCode,
                DocumentDesc = generateRemitoRequest.DocumentDesc,
                DocumentNumber = generateRemitoRequest.DocumentNumber,
                DocumentType = generateRemitoRequest.DocumentType,
                FrieghtType = generateRemitoRequest.FrieghtType,
                Letter = generateRemitoRequest.Letter,
                ShipmentAddress = generateRemitoRequest.ShipmentAddress,
                ShippedDate = generateRemitoRequest.ShippedDate,
                ShipToAddress = generateRemitoRequest.ShipToAddress,
                TargetERP = generateRemitoRequest.TargetERP,
                WellRigName = generateRemitoRequest.WellRigName,
                TargetInterface = generateRemitoRequest.TargetInterface,
                Details = generateRemitoRequest.Details

            };
            var boomiRequestResponse = new BoomiRequestResponse()
            {
                RequestId = generateRemitoRequest.RequestId,
                CorelationId = generateRemitoRequest.CorelationId,
                EventId = generateRemitoRequest.EventId,
                KeyName = generateRemitoRequest.KeyName,
                KeyValue = generateRemitoRequest.KeyValue,
                RequestDateTime = DateTime.UtcNow,
                RequestStatus = BoomiResponseType.Success.ToString(),
                RequestBody = JsonConvert.SerializeObject(remitoArgentinaInformationRequest),
                RequestURL = "inRemito/MexicoandArgentina",
                RequestMethod = "MexicoandArgentina",
                HttpVerb = "Post",
                ActionBy = string.IsNullOrEmpty(generateRemitoRequest.ActionBy)
                    ? "BoomiWrapper API" : generateRemitoRequest.ActionBy
            };
            RecordRequestPayload(boomiRequestResponse);
            var request = JsonConvert.SerializeObject(remitoArgentinaInformationRequest);
            var data = new StringContent(request, Encoding.UTF8, "application/json");

            httpClient.DefaultRequestHeaders.Add("KeyId", configuration["API_Key"]);
            var url = configuration["RemitoInformation_URI"];
            var responseTask = httpClient.PostAsync(url, data);
            responseTask.Wait();
            var result = responseTask.Result;
            if (result.IsSuccessStatusCode)
            {
                remitoResponse = await result.Content.ReadFromJsonAsync<RemitoResponse>();
            }
            boomiRequestResponse.Status = BoomiResponseType.Success.ToString();
            boomiRequestResponse.ResponseStatus = remitoResponse.Success;
            boomiRequestResponse.RequestDateTime = DateTime.UtcNow;
            boomiRequestResponse.ResponseBody = JsonConvert.SerializeObject(remitoResponse);
            if (!remitoResponse.Success.Equals("1") &&
                remitoResponse.Errors != null && remitoResponse.Errors.Any())
            {
                boomiRequestResponse.ErrorMessage = JsonConvert.SerializeObject(remitoResponse.Errors);
                boomiRequestResponse.Status = BoomiResponseType.Failed.ToString();
            }
            RecordResponse(boomiRequestResponse);
            return remitoResponse;
        }
        public async Task<CreateSalesOrderResponse> CreateSalesOrder(GenerateCreateSalesOrderRequest createSalesOrderRequest)
        {
            CreateSalesOrderResponse createSalesOrderResponse = new CreateSalesOrderResponse();
            createSalesOrderRequest.erpUserId = GetDefaultErpUserId(createSalesOrderRequest.erpUserId);
            createSalesOrderRequest.Header.erpUserId = GetDefaultErpUserId(createSalesOrderRequest.Header.erpUserId);
            var boomiRequestResponse = new BoomiRequestResponse()
            {
                RequestId = createSalesOrderRequest.RequestId,
                CorelationId = createSalesOrderRequest.CorelationId,
                EventId = createSalesOrderRequest.EventId,
                KeyName = createSalesOrderRequest.KeyName,
                KeyValue = createSalesOrderRequest.KeyValue,
                RequestDateTime = DateTime.UtcNow,
                RequestStatus = BoomiResponseType.Success.ToString(),
                RequestBody = JsonConvert.SerializeObject(createSalesOrderRequest),
                RequestURL = "inSalesOrder/createsalesorder",
                RequestMethod = "createsalesorder",
                HttpVerb = "Post",
                ActionBy = string.IsNullOrEmpty(createSalesOrderRequest.ActionBy)
                    ? "BoomiWrapper API" : createSalesOrderRequest.ActionBy
            };
            RecordRequestPayload(boomiRequestResponse);
            var request = JsonConvert.SerializeObject(createSalesOrderRequest);
            var data = new StringContent(request, Encoding.UTF8, "application/json");

            httpClient.DefaultRequestHeaders.Add("KeyId", configuration["API_Key"]);
            var url = configuration["SalesOrder_URI"];
            var responseTask = httpClient.PostAsync(url, data);
            responseTask.Wait();
            var result = responseTask.Result;
            if (result.IsSuccessStatusCode)
            {
                try
                {
                    createSalesOrderResponse = await result.Content.ReadFromJsonAsync<CreateSalesOrderResponse>();
                }
                catch (Exception)
                {
                    var json = result.Content.ReadAsStringAsync().Result;
                    if (json.Contains("title"))
                    {
                        var firstindex = json.IndexOf("<title>");
                        var lastindex = json.IndexOf("</title>");
                        json = json.Substring(firstindex + 7, lastindex - firstindex - 7).Replace('"', '\'');
                    }
                    createSalesOrderResponse.Success = "0";
                    createSalesOrderResponse.Errors = new List<ErpError>() { new ErpError() { Error = json } };
                }

            }
            boomiRequestResponse.Status = BoomiResponseType.Success.ToString();
            boomiRequestResponse.ResponseStatus = createSalesOrderResponse.Success;
            boomiRequestResponse.RequestDateTime = DateTime.UtcNow;
            boomiRequestResponse.ResponseBody = JsonConvert.SerializeObject(createSalesOrderResponse);
            if (!createSalesOrderResponse.Success.Equals("1") &&
                createSalesOrderResponse.Errors != null && createSalesOrderResponse.Errors.Any())
            {
                boomiRequestResponse.ErrorMessage = JsonConvert.SerializeObject(createSalesOrderResponse.Errors);
                boomiRequestResponse.Status = BoomiResponseType.Failed.ToString();
            }
            RecordResponse(boomiRequestResponse);
            return createSalesOrderResponse;
        }

        public async Task<InsertEDIGLResponse> InsertEDIGL(InsertEDIGLRequest insertEDIGLRequest)
        {
            insertEDIGLRequest.erpUserId = GetDefaultErpUserId(insertEDIGLRequest.erpUserId);
            var request = JsonConvert.SerializeObject(insertEDIGLRequest);
            LogPayload(request, "Request");
            InsertEDIGLResponse insertEDIGLResponse = new InsertEDIGLResponse();

            var data = new StringContent(request, Encoding.UTF8, "application/json");

            httpClient.DefaultRequestHeaders.Add("KeyId", configuration["API_Key"]);
            var url = configuration["EDIGL_URI"];
            var responseTask = httpClient.PostAsync(url, data);
            responseTask.Wait();
            var result = responseTask.Result;
            if (result.IsSuccessStatusCode)
            {
                insertEDIGLResponse = await result.Content.ReadFromJsonAsync<InsertEDIGLResponse>();
            }
            LogPayload(JsonConvert.SerializeObject(insertEDIGLResponse), "Response");
            return insertEDIGLResponse;
        }
        public async Task<JobCreationResponse> CreateJob(JobCreationRequest jobCreationRequest)
        {
            var request = JsonConvert.SerializeObject(jobCreationRequest);
            LogPayload(request, "Request");
            JobCreationResponse jobCreationResponse = new JobCreationResponse();

            var data = new StringContent(request, Encoding.UTF8, "application/json");

            httpClient.DefaultRequestHeaders.Add("KeyId", configuration["API_Key"]);
            var url = configuration["JobCreation_URI"];
            var responseTask = httpClient.PostAsync(url, data);
            responseTask.Wait();
            var result = responseTask.Result;
            if (result.IsSuccessStatusCode)
            {
                jobCreationResponse = await result.Content.ReadFromJsonAsync<JobCreationResponse>();
            }
            LogPayload(JsonConvert.SerializeObject(jobCreationResponse), "Response");
            return jobCreationResponse;
        }

        public async Task<JobCreationResponse> CreateJob(GenerateJobCreationRequest generateJobCreationRequest)
        {
            generateJobCreationRequest.erpUserId = GetDefaultErpUserId(generateJobCreationRequest.erpUserId);
            var jobCreationRequest = mapper.Map<GenerateJobCreationRequest, JobCreationRequest>(generateJobCreationRequest);
            var boomiRequestResponse = new BoomiRequestResponse()
            {
                RequestId = generateJobCreationRequest.RequestId,
                CorelationId = generateJobCreationRequest.CorelationId,
                EventId = generateJobCreationRequest.EventId,
                KeyName = generateJobCreationRequest.KeyName,
                KeyValue = generateJobCreationRequest.KeyValue,
                RequestDateTime = DateTime.UtcNow,
                RequestStatus = BoomiResponseType.Success.ToString(),
                RequestBody = JsonConvert.SerializeObject(jobCreationRequest),
                RequestURL = "injob/jobcreation",
                RequestMethod = "jobcreation",
                HttpVerb = "Post",
                ActionBy = string.IsNullOrEmpty(generateJobCreationRequest.ActionBy)
                    ? "BoomiWrapper API" : generateJobCreationRequest.ActionBy
            };
            RecordRequestPayload(boomiRequestResponse);

            var request = JsonConvert.SerializeObject(jobCreationRequest);
            LogPayload(request, "Request");
            JobCreationResponse jobCreationResponse = new JobCreationResponse();

            var data = new StringContent(request, Encoding.UTF8, "application/json");

            httpClient.DefaultRequestHeaders.Add("KeyId", configuration["API_Key"]);
            var url = configuration["JobCreation_URI"];
            var responseTask = httpClient.PostAsync(url, data);
            responseTask.Wait();
            var result = responseTask.Result;
            if (result.IsSuccessStatusCode)
            {
                //var json = JsonConvert.SerializeObject(result.Content.ReadAsStringAsync().Result);
                jobCreationResponse = await result.Content.ReadFromJsonAsync<JobCreationResponse>();
            }

            boomiRequestResponse.Status = BoomiResponseType.Success.ToString();
            boomiRequestResponse.ResponseStatus = jobCreationResponse.Success;
            boomiRequestResponse.RequestDateTime = DateTime.UtcNow;
            boomiRequestResponse.ResponseBody = JsonConvert.SerializeObject(jobCreationResponse);
            if (!jobCreationResponse.Success.Equals("1")
               && jobCreationResponse.Errors != null && jobCreationResponse.Errors.Any())
            {
                boomiRequestResponse.ErrorMessage = JsonConvert.SerializeObject(jobCreationResponse.Errors);
                boomiRequestResponse.Status = BoomiResponseType.Failed.ToString();
            }

            RecordResponse(boomiRequestResponse);
            return jobCreationResponse;
        }
        public async Task<ItemAvailabilityResponse> GetItemAvailability(ItemAvailabilityRequest itemAvailabilityRequest)
        {
            var request = JsonConvert.SerializeObject(itemAvailabilityRequest);
            LogPayload(request, "Request");
            ItemAvailabilityResponse itemAvailabilityResponse = new ItemAvailabilityResponse();

            var data = new StringContent(request, Encoding.UTF8, "application/json");

            httpClient.DefaultRequestHeaders.Add("KeyId", configuration["API_Key"]);
            var url = configuration["ItemAvailability_URI"];
            httpClient.Timeout = new TimeSpan(0, 5, 0);
            var responseTask = httpClient.PostAsync(url, data);
            responseTask.Wait();
            var result = responseTask.Result;
            if (result.IsSuccessStatusCode)
            {
                itemAvailabilityResponse = await result.Content.ReadFromJsonAsync<ItemAvailabilityResponse>();
                LogPayload(JsonConvert.SerializeObject(itemAvailabilityResponse), "Response");
            }

            return itemAvailabilityResponse;
        }
        public async Task<SalesOrderStatusResponse> GetSalesOrderStatus(SalesOrderStatusRequest salesOrderStatusRequest)
        {
            var request = JsonConvert.SerializeObject(salesOrderStatusRequest);
            LogPayload(request, "Request");
            SalesOrderStatusResponse salesOrderStatusResponse = new SalesOrderStatusResponse();

            var data = new StringContent(request, Encoding.UTF8, "application/json");

            httpClient.DefaultRequestHeaders.Add("KeyId", configuration["API_Key"]);
            var url = configuration["SalesOrderStatus_URI"];
            var responseTask = httpClient.PostAsync(url, data);
            responseTask.Wait();
            var result = responseTask.Result;
            if (result.IsSuccessStatusCode)
            {
                salesOrderStatusResponse = await result.Content.ReadFromJsonAsync<SalesOrderStatusResponse>();
            }
            LogPayload(JsonConvert.SerializeObject(salesOrderStatusResponse), "Response");
            return salesOrderStatusResponse;
        }
        public async Task<ExchangeRateResponse> GetExchangeRate(ExchangeRateRequest exchangeRateRequest)
        {
            var request = JsonConvert.SerializeObject(exchangeRateRequest);
            LogPayload(request, "Request");
            ExchangeRateResponse exchangeRateResponse = new ExchangeRateResponse();

            var data = new StringContent(request, Encoding.UTF8, "application/json");

            httpClient.DefaultRequestHeaders.Add("KeyId", configuration["API_Key"]);
            var url = configuration["ExchangeRate_URI"];
            var responseTask = httpClient.PostAsync(url, data);
            responseTask.Wait();
            var result = responseTask.Result;
            if (result.IsSuccessStatusCode)
            {
                exchangeRateResponse = await result.Content.ReadFromJsonAsync<ExchangeRateResponse>();
            }
            LogPayload(JsonConvert.SerializeObject(exchangeRateResponse), "Response");
            return exchangeRateResponse;
        }
        public async Task<InventoryAdjustmentResponse> InventoryAdjustment(InventoryAdjustmentRequest inventoryAdjustmentRequest)
        {
            var request = JsonConvert.SerializeObject(inventoryAdjustmentRequest);
            LogPayload(request, "Request");
            InventoryAdjustmentResponse inventoryAdjustmentResponse = new InventoryAdjustmentResponse();

            var data = new StringContent(request, Encoding.UTF8, "application/json");

            httpClient.DefaultRequestHeaders.Add("KeyId", configuration["API_Key"]);
            var url = configuration["InventoryAdjustment_URI"];
            var responseTask = httpClient.PostAsync(url, data);
            responseTask.Wait();
            var result = responseTask.Result;
            if (result.IsSuccessStatusCode)
            {
                inventoryAdjustmentResponse = await result.Content.ReadFromJsonAsync<InventoryAdjustmentResponse>();
            }
            LogPayload(JsonConvert.SerializeObject(inventoryAdjustmentResponse), "Response");
            return inventoryAdjustmentResponse;
        }

        public async Task<InventoryTransferResponse> InventoryTransfer(InventoryTransferRequest inventoryTransferRequest)
        {
            var request = JsonConvert.SerializeObject(inventoryTransferRequest);
            LogPayload(request, "Request");
            InventoryTransferResponse inventoryTransferResponse = new InventoryTransferResponse();

            var data = new StringContent(request, Encoding.UTF8, "application/json");

            httpClient.DefaultRequestHeaders.Add("KeyId", configuration["API_Key"]);
            var url = configuration["inInventory/InventoryTransfer"];
            var responseTask = httpClient.PostAsync(url, data);
            responseTask.Wait();
            var result = responseTask.Result;
            if (result.IsSuccessStatusCode)
            {
                inventoryTransferResponse = await result.Content.ReadFromJsonAsync<InventoryTransferResponse>();
            }
            LogPayload(JsonConvert.SerializeObject(inventoryTransferResponse), "Response");
            return inventoryTransferResponse;
        }
        public async Task<InventoryTransferResponse> InventoryTransfer(GenerateInventoryTransferRequest generateInventoryTransferRequest)
        {

            #region InventoryErrorMessages
            List<string> errorMessages = new List<string>
            {
                   "There is no Item Location Record for this Business Unit/Location",
                   "The item location record entered does not exist",
                   "The Lot Status is about to be updated",
                   "Quantity entered is greater than quantity available",
            };
            #endregion
            generateInventoryTransferRequest.erpUserId = GetDefaultErpUserId(generateInventoryTransferRequest.erpUserId);
            var inventoryTransferRequest = mapper.Map<GenerateInventoryTransferRequest, InventoryTransferRequest>(generateInventoryTransferRequest);
            var boomiRequestResponse = new BoomiRequestResponse()
            {
                RequestId = generateInventoryTransferRequest.RequestId,
                CorelationId = generateInventoryTransferRequest.CorelationId,
                EventId = generateInventoryTransferRequest.EventId,
                KeyName = generateInventoryTransferRequest.KeyName,
                KeyValue = generateInventoryTransferRequest.KeyValue,
                RequestDateTime = DateTime.UtcNow,
                RequestStatus = BoomiResponseType.Success.ToString(),
                RequestBody = JsonConvert.SerializeObject(inventoryTransferRequest),
                RequestURL = "inInventory/InventoryTransfer",
                RequestMethod = generateInventoryTransferRequest.TargetInterface,
                HttpVerb = "Post",
                ActionBy = generateInventoryTransferRequest.ActionBy
            };
            RecordRequestPayload(boomiRequestResponse);

            var request = JsonConvert.SerializeObject(inventoryTransferRequest);
            InventoryTransferResponse inventoryTransferResponse = new InventoryTransferResponse();

            var data = new StringContent(request, Encoding.UTF8, "application/json");
            httpClient.DefaultRequestHeaders.Clear();
            httpClient.DefaultRequestHeaders.Add("KeyId", configuration["API_Key"]);
            var url = configuration["InventoryAdjustment_URI"];
            var responseTask = httpClient.PostAsync(url, data);
            responseTask.Wait();
            var result = responseTask.Result;
            if (result.IsSuccessStatusCode)
            {
                inventoryTransferResponse = await result.Content.ReadFromJsonAsync<InventoryTransferResponse>();
            }

            boomiRequestResponse.Status = BoomiResponseType.Success.ToString();
            boomiRequestResponse.ResponseStatus = inventoryTransferResponse.Success;
            boomiRequestResponse.ResponseDateTime = DateTime.UtcNow;
            boomiRequestResponse.ResponseBody = JsonConvert.SerializeObject(inventoryTransferResponse);
            if (!inventoryTransferResponse.Success.Equals("1")
                && inventoryTransferResponse.Errors != null && inventoryTransferResponse.Errors.Any())
            {
                boomiRequestResponse.ErrorMessage = JsonConvert.SerializeObject(inventoryTransferResponse.Errors);
                boomiRequestResponse.Status = BoomiResponseType.Failed.ToString();
            }
            if (boomiRequestResponse.ErrorMessage != null && errorMessages.Any(e => boomiRequestResponse.ErrorMessage.Contains(e)))
            {
                inventoryTransferResponse.DictErrors = ParseJDEReturnErrorMessage(inventoryTransferResponse.Errors[0].Error);
            }
            RecordResponse(boomiRequestResponse);
            return inventoryTransferResponse;
        }

        public InventoryTransferResponse SaveTransferJDEItems(CustomerTransferSlip customerTransferSlip, List<CustomerTransferSlipDetail> inventoryItems)
        {
            string returnMessage = string.Empty;
            InventoryTransferResponse inventoryTransferResponse = new InventoryTransferResponse();
            bool related = businessUnitService.AreRelatedBUs(customerTransferSlip.BusinessUnitCode, customerTransferSlip.SendingBuCode);            //Todo add Related = true wherever is required
            BusinessUnit businessUnit = businessUnitService.GetBusinessUnitByBU(customerTransferSlip.BusinessUnitCode);
            List<Domain.WriteModels.InventoryTransferDetails> detailsPayload = new List<Domain.WriteModels.InventoryTransferDetails>();

            foreach (CustomerTransferSlipDetail obj in inventoryItems)
            {
                Domain.WriteModels.InventoryTransferDetails details = new Domain.WriteModels.InventoryTransferDetails();

                //Create JDE Item Collections
                //Add To DT Collection 

                if ((customerTransferSlip.BusinessUnitCode == customerTransferSlip.SendingBuCode) || (customerTransferSlip.BusinessUnitCode != customerTransferSlip.SendingBuCode && related) //Related == true
                    || (customerTransferSlip.BusinessUnitCode != customerTransferSlip.SendingBuCode && !related && !string.IsNullOrEmpty(customerTransferSlip.ErpDocNumber)))  //Related
                {
                    details.FromItemNumber = obj.PartNumber;
                    details.FromQuantity = obj.QuantityShipped.ToString();
                    details.FromDisplayLocation = Constants.STAGING;
                    details.ToDisplayLocation = ((businessUnit.DivisionCode == "WS" && businessUnit.SubDivisionCode != "MDT") || (businessUnit.DivisionCode == "RH")) ?
                                        customerTransferSlip.ErpJobNumber.ToString() : customerTransferSlip.RigJDEName; //DDTAT-2313 //DDTAT-6167
                    details.CAllowHeldLot = "1";
                    details.PODefaultLotStatus = "2";
                    details.CToLotStatusCode = "N";
                    details.AllowQtyOverAvailable = "";
                    details.ToLotNumber = "";
                    details.FromLotNumber = obj.ItemSerialNumber;
                    details.FromSerialNumber = obj.ItemSerialNumber; //ISWT-3563
                    detailsPayload.Add(details);
                }
                //DDTAT-7625
                else
                {
                    details.FromItemNumber = obj.PartNumber;
                    details.FromQuantity = obj.QuantityShipped.ToString();
                    details.FromDisplayLocation = Constants.STAGING;
                    details.ToDisplayLocation = Constants.STAGING;
                    details.CAllowHeldLot = "1";
                    details.PODefaultLotStatus = "2";
                    details.CToLotStatusCode = "N";
                    details.AllowQtyOverAvailable = "";
                    details.ToLotNumber = "";
                    details.FromLotNumber = obj.ItemSerialNumber;
                    details.FromSerialNumber = obj.ItemSerialNumber; //ISWT-3563
                    detailsPayload.Add(details);
                }
            }
            GenerateInventoryTransferRequest generateInventoryTransferRequest = new GenerateInventoryTransferRequest();
            generateInventoryTransferRequest.CreatedDate = DateTime.Now;
            generateInventoryTransferRequest.Version = Constants.Version_DDSOPS0001;
            generateInventoryTransferRequest.TransferSlipNumber = customerTransferSlip.CustomerTransferNumber.ToString();
            generateInventoryTransferRequest.TransactionType = Constants.TransactionType_RI;
            generateInventoryTransferRequest.TransferSlipOrderType = Constants.TransferSlipOrderType_TT;
            generateInventoryTransferRequest.TargetInterface = Constants.TargetInterface_InventoryTransfer;
            generateInventoryTransferRequest.TargetERP = Constants.TargetERP_JDE;
            generateInventoryTransferRequest.Details = detailsPayload;
            if (customerTransferSlip.BusinessUnitCode == customerTransferSlip.SendingBuCode && detailsPayload.Count > 0)
            {
                generateInventoryTransferRequest.FromBranchPlant = Convert.ToString(customerTransferSlip.SendingBuCode);
                generateInventoryTransferRequest.ToBranchPlant = Convert.ToString(customerTransferSlip.SendingBuCode);
                inventoryTransferResponse = InventoryTransfer(generateInventoryTransferRequest).Result;
                customerTransferSlip.ErpDocNumber = inventoryTransferResponse.JDEDocNumber;
            }
            if ((customerTransferSlip.BusinessUnitCode != customerTransferSlip.SendingBuCode && detailsPayload.Count > 0 && related != true && !string.IsNullOrEmpty(customerTransferSlip.ErpDocNumber)))
            {
                generateInventoryTransferRequest.FromBranchPlant = Convert.ToString(customerTransferSlip.BusinessUnitCode);
                generateInventoryTransferRequest.ToBranchPlant = Convert.ToString(customerTransferSlip.BusinessUnitCode);
                inventoryTransferResponse = InventoryTransfer(generateInventoryTransferRequest).Result;
                customerTransferSlip.ErpDocNumber = inventoryTransferResponse.JDEDocNumber;

            }
            if (customerTransferSlip.BusinessUnitCode != customerTransferSlip.SendingBuCode && detailsPayload.Count > 0 && related == true)
            {
                generateInventoryTransferRequest.FromBranchPlant = Convert.ToString(customerTransferSlip.SendingBuCode);
                generateInventoryTransferRequest.ToBranchPlant = Convert.ToString(customerTransferSlip.BusinessUnitCode);
                inventoryTransferResponse = InventoryTransfer(generateInventoryTransferRequest).Result;
                customerTransferSlip.ErpDocNumber = inventoryTransferResponse.JDEDocNumber;

            }
            if (customerTransferSlip.BusinessUnitCode != customerTransferSlip.SendingBuCode && detailsPayload.Count > 0 && related != true && string.IsNullOrEmpty(customerTransferSlip.ErpDocNumber))
            {
                generateInventoryTransferRequest.FromBranchPlant = Convert.ToString(customerTransferSlip.SendingBuCode);
                generateInventoryTransferRequest.ToBranchPlant = Convert.ToString(customerTransferSlip.BusinessUnitCode);
                inventoryTransferResponse = InventoryTransfer(generateInventoryTransferRequest).Result;
                customerTransferSlip.ErpDocNumber = inventoryTransferResponse.JDEDocNumber;

            }
            return inventoryTransferResponse;
        }
        public InventoryTransferResponse SaveAdjustmentJDEItems(CustomerTransferSlip customerTransferSlip, List<CustomerTransferSlipDetail> inventoryItems)
        {
            string returnMessage = string.Empty;
            InventoryTransferResponse inventoryTransferResponse = new InventoryTransferResponse();
            BusinessUnit businessUnit = businessUnitService.GetBusinessUnitByBU(customerTransferSlip.BusinessUnitCode);
            List<Domain.WriteModels.InventoryTransferDetails> detailsPayload = new List<Domain.WriteModels.InventoryTransferDetails>();

            //Check if BUs Are Related Via JDE

            bool related = businessUnitService.AreRelatedBUs(customerTransferSlip.BusinessUnitCode, customerTransferSlip.SendingBuCode);
            foreach (CustomerTransferSlipDetail obj in customerTransferSlip.CustomerTransferSlipDetails)
            {
                ItemMasterRequest itemMasterRequest = new ItemMasterRequest();
                itemMasterRequest.PartNumber = obj.PartNumber;
                itemMasterRequest.TargetERP = Constants.TargetERP_JDE;
                ItemMasterResponse itemMasterResponse = this.GetItemMaster(itemMasterRequest).Result;
                Domain.WriteModels.InventoryTransferDetails details = new Domain.WriteModels.InventoryTransferDetails();
                details.CFromTo = "F";
                details.UpdateQuantityOnHand = "1";
                details.InventoryTransactionType = Constants.InventoryTransactionType_Reclassification;
                details.FromItemNumber = obj.PartNumber;
                details.ToItemNumber = itemMasterResponse.RAPartNumber;
                details.ToDisplayLocation = ((businessUnit.DivisionCode == "WS" && businessUnit.SubDivisionCode != "MDT") || (businessUnit.DivisionCode == "RH")) ? //WTBIZAPPS - 13591
                                    customerTransferSlip.ErpJobNumber.ToString() : customerTransferSlip.RigJDEName; //DDTAT-6167
                details.FromQuantity = (-1 * Convert.ToDecimal(obj.QuantityShipped)).ToString();
                details.ToQuantity = obj.QuantityShipped.ToString();
                details.CAllowHeldLot = "1";
                details.CToLotStatusCode = "N";
                details.AllowQtyOverAvailable = "";
                //details.FromLotNumber = obj.ItemSerialNumber; //ISWT-3563
                details.ToLotNumber = obj.ItemSerialNumber;  //ISWT-3563 // check for payload
                details.FromLocation = Constants.STAGING;
                details.FromSerialNumber = obj.ItemSerialNumber; //ISWT-3563

                details.ToLocation = ((businessUnit.DivisionCode == "WS" && businessUnit.SubDivisionCode != "MDT") || (businessUnit.DivisionCode == "RH")) ?
                                    customerTransferSlip.ErpJobNumber.ToString() : customerTransferSlip.RigJDEName; //DDTAT-6167
                if (!string.IsNullOrEmpty(customerTransferSlip.ErpJobNumber.ToString()))
                    details.TransactionReference = customerTransferSlip.ErpJobNumber;
                if (customerTransferSlip.BusinessUnitCode == customerTransferSlip.SendingBuCode)
                {
                    details.FromBU = Convert.ToString(customerTransferSlip.SendingBuCode);
                    details.ToBU = Convert.ToString(customerTransferSlip.SendingBuCode);
                    detailsPayload.Add(details);
                }
                //DDTAT-7625
                else if (customerTransferSlip.BusinessUnitCode != customerTransferSlip.SendingBuCode && related != true && !string.IsNullOrEmpty(customerTransferSlip.ErpDocNumber))
                {
                    details.FromBU = Convert.ToString(customerTransferSlip.BusinessUnitCode);
                    details.ToBU = Convert.ToString(customerTransferSlip.BusinessUnitCode);
                    detailsPayload.Add(details);
                }
                else if (customerTransferSlip.BusinessUnitCode != customerTransferSlip.SendingBuCode && related == true)
                {
                    details.FromBU = Convert.ToString(customerTransferSlip.SendingBuCode);
                    details.ToBU = Convert.ToString(customerTransferSlip.BusinessUnitCode);
                    detailsPayload.Add(details);
                }
            } //End Detail Items Creation

            //DDTAT-7625
            GenerateInventoryTransferRequest generateInventoryTransferRequest = new GenerateInventoryTransferRequest();
            if ((customerTransferSlip.BusinessUnitCode == customerTransferSlip.SendingBuCode && detailsPayload.Count > 0)
                || (customerTransferSlip.BusinessUnitCode != customerTransferSlip.SendingBuCode && detailsPayload.Count > 0 && related == true)
                || (customerTransferSlip.BusinessUnitCode != customerTransferSlip.SendingBuCode && detailsPayload.Count > 0 && related != true && !string.IsNullOrEmpty(customerTransferSlip.ErpDocNumber)))
            {
                //Set Header
                generateInventoryTransferRequest.TransferSlipOrderType = Constants.TransferSlipOrderType_TT;
                generateInventoryTransferRequest.TransferSlipNumber = customerTransferSlip.CustomerTransferNumber.ToString();
                generateInventoryTransferRequest.CreatedDate = DateTime.Now;
                generateInventoryTransferRequest.Version = Constants.Version_DDSOPS0001; ;
                generateInventoryTransferRequest.TransactionType = Constants.TransactionType_RI;
                generateInventoryTransferRequest.TargetInterface = Constants.TargetInterface_InventoryAdjustment;
                generateInventoryTransferRequest.TargetERP = Constants.TargetERP_JDE;
                generateInventoryTransferRequest.Details = detailsPayload;
                inventoryTransferResponse = InventoryTransfer(generateInventoryTransferRequest).Result;
                customerTransferSlip.ErpDocNumber = inventoryTransferResponse.JDEDocNumber;

            }
            return inventoryTransferResponse;
        }
        public InventoryTransferResponse SaveAdjustmentNRJDEItems(CustomerTransferSlip customerTransferSlip, List<CustomerTransferSlipDetail> inventoryItems)
        {
            string returnMessage = string.Empty;
            InventoryTransferResponse inventoryTransferResponse = new InventoryTransferResponse();
            List<Domain.WriteModels.InventoryTransferDetails> detailsPayload = new List<Domain.WriteModels.InventoryTransferDetails>();

            //Check if BUs Are Related Via JDE 
            bool related = businessUnitService.AreRelatedBUs(customerTransferSlip.BusinessUnitCode, customerTransferSlip.SendingBuCode);
            foreach (CustomerTransferSlipDetail obj in customerTransferSlip.CustomerTransferSlipDetails)
            {
                Domain.WriteModels.InventoryTransferDetails details = new Domain.WriteModels.InventoryTransferDetails();
                details.InventoryTransactionType = Constants.InventoryTransactionType_Adjustment;
                details.FromItemNumber = obj.PartNumber;
                details.FromLocation = Constants.STAGING;
                details.FromQuantity = (-1 * Convert.ToDecimal(obj.QuantityShipped)).ToString();
                details.CAllowHeldLot = "1";
                details.CToLotStatusCode = "N";
                details.AllowQtyOverAvailable = "";
                details.FromLotNumber = obj.ItemSerialNumber; //ISWT-3563
                details.ToLotNumber = "";
                details.UpdateQuantityOnHand = "1";
                details.FromSerialNumber = obj.ItemSerialNumber; //ISWT-3563

                if (!string.IsNullOrEmpty(customerTransferSlip.ErpJobNumber.ToString()))
                    details.TransactionReference = customerTransferSlip.ErpJobNumber;

                if ((customerTransferSlip.BusinessUnitCode == customerTransferSlip.SendingBuCode) ||
                    (customerTransferSlip.BusinessUnitCode != customerTransferSlip.SendingBuCode && related == true))
                {
                    details.FromBU = Convert.ToString(customerTransferSlip.SendingBuCode);
                    detailsPayload.Add(details);
                }

                //DDTAT-7625
                else if (customerTransferSlip.BusinessUnitCode != customerTransferSlip.SendingBuCode && related != true && !string.IsNullOrEmpty(customerTransferSlip.ErpDocNumber))
                {
                    details.FromBU = Convert.ToString(customerTransferSlip.BusinessUnitCode);
                    detailsPayload.Add(details);
                }
            } //End Detail Items Creation

            //DDTAT-7625
            GenerateInventoryTransferRequest generateInventoryTransferRequest = new GenerateInventoryTransferRequest();
            if ((customerTransferSlip.BusinessUnitCode == customerTransferSlip.SendingBuCode && detailsPayload.Count > 0)
                || (customerTransferSlip.BusinessUnitCode != customerTransferSlip.SendingBuCode && detailsPayload.Count > 0 && related == true)
                || (customerTransferSlip.BusinessUnitCode != customerTransferSlip.SendingBuCode && related != true && !string.IsNullOrEmpty(customerTransferSlip.ErpDocNumber)))
            {
                //Set Header
                generateInventoryTransferRequest.TransferSlipOrderType = Constants.TransferSlipOrderType_TT;
                generateInventoryTransferRequest.TransferSlipNumber = customerTransferSlip.Id.ToString();
                generateInventoryTransferRequest.CreatedDate = DateTime.Now;
                generateInventoryTransferRequest.Version = Constants.Version_DDSOPS0001; ;
                generateInventoryTransferRequest.TransactionType = Constants.TransactionType_RI;
                generateInventoryTransferRequest.TargetInterface = Constants.TargetInterface_InventoryAdjustment;
                generateInventoryTransferRequest.TargetERP = Constants.TargetERP_JDE;
                generateInventoryTransferRequest.Details = detailsPayload;
                inventoryTransferResponse = InventoryTransfer(generateInventoryTransferRequest).Result;
                customerTransferSlip.ErpDocNumber = inventoryTransferResponse.JDEDocNumber;

            }
            return inventoryTransferResponse;
        }
        public static Dictionary<string, ErrorMessage> ParseJDEReturnErrorMessage(string jdeReturnMessage)
        {
            string returnMessage = string.Empty;
            Dictionary<string, ErrorMessage> dictErrors = new Dictionary<string, ErrorMessage>();

            XElement xmlroot = XElement.Parse(jdeReturnMessage);
            string firstNodeContent = ((System.Xml.Linq.XElement)(xmlroot.Element("head"))).Value;
            try
            {
                var newString = firstNodeContent.ToUpper().Split(new string[] { "LINE NO:" }, StringSplitOptions.None);

                for (int i = 1; i < newString.Length; i++)
                {
                    if (newString[i].IndexOf("ITEM NUMBER:") != -1)
                    {
                        ErrorMessage errMsg = new ErrorMessage();

                        errMsg.LineNumber = Convert.ToInt32(newString[i].Substring(newString[i].IndexOf("LINE NO:") + 1, newString[i].IndexOf("ITEM NUMBER:") - 1));
                        errMsg.PartNumber = (newString[i].Substring(newString[i].IndexOf("ITEM NUMBER:") + 13, newString[i].IndexOf("LOCATION:") - 16)).Trim();
                        errMsg.Location = newString[i].Substring(newString[i].IndexOf("LOCATION:") + 9, newString[i].IndexOf(":CAUSE") - 38).Trim();
                        errMsg.ErrorMsg = newString[i].Substring(newString[i].IndexOf(":CAUSE") + 15, newString[i].IndexOf("RESOLUTION") - newString[i].IndexOf(":CAUSE") - 15);

                        if (newString[i].IndexOf("PROCESS DETAIL:") != -1)
                            errMsg.Resolution = newString[i].Substring(newString[i].IndexOf("RESOLUTION") + 13, newString[i].IndexOf("PROCESS DETAIL:") - (newString[i].IndexOf("RESOLUTION") + 13));
                        else if (newString[i].IndexOf("PROCESS POST DETAIL:") != -1)
                            errMsg.Resolution = newString[i].Substring(newString[i].IndexOf("RESOLUTION") + 13, newString[i].IndexOf("PROCESS POST DETAIL:") - (newString[i].IndexOf("RESOLUTION") + 13));
                        else
                            errMsg.Resolution = newString[i].Substring(newString[i].IndexOf("RESOLUTION") + 13, (newString[i].Length - newString[i].IndexOf("RESOLUTION") - 13));


                        if (!dictErrors.ContainsKey(errMsg.PartNumber.ToString().Trim().ToLower()))
                            dictErrors.Add(errMsg.PartNumber.ToString().Trim().ToLower(), errMsg);
                        else
                        {
                            dictErrors[errMsg.PartNumber.ToString().Trim().ToLower()].ErrorMsg = dictErrors[errMsg.PartNumber.ToString().Trim().ToLower()].ErrorMsg + " Error(" + i + "): " + errMsg.ErrorMsg;
                        }
                    }
                }
                return dictErrors;
            }
            catch (Exception ex)
            {
                return dictErrors = null;
            }
        }
        public async Task<CreateWorkOrderResponse> CreateWorkOrder(CreateWorkOrderRequest createWorkOrderRequest)
        {
            var request = JsonConvert.SerializeObject(createWorkOrderRequest);
            LogPayload(request, "Request");
            var boomiRequestResponse = new BoomiRequestResponse()
            {
                RequestId = createWorkOrderRequest.RequestId,
                CorelationId = createWorkOrderRequest.CorelationId,
                EventId = createWorkOrderRequest.EventId,
                KeyName = createWorkOrderRequest.KeyName,
                KeyValue = createWorkOrderRequest.KeyValue,
                RequestDateTime = DateTime.UtcNow,
                RequestStatus = BoomiResponseType.Success.ToString(),
                RequestBody = request,
                RequestURL = "inServiceWorkOrder/CreateServiceWorkOrder",
                RequestMethod = "CreateServiceWorkOrder",
                HttpVerb = "Post",
                ActionBy = createWorkOrderRequest.ActionBy
            };
            RecordRequestPayload(boomiRequestResponse);

            CreateWorkOrderResponse createWorkOrderResponse = new CreateWorkOrderResponse();

            var data = new StringContent(request, Encoding.UTF8, "application/json");
            httpClient.DefaultRequestHeaders.Clear();
            httpClient.DefaultRequestHeaders.Add("KeyId", configuration["API_Key"]);
            var url = configuration["ServiceWorkOrder_URL"];
            var responseTask = httpClient.PostAsync(url, data);
            responseTask.Wait();
            var result = responseTask.Result;
            if (result.IsSuccessStatusCode)
            {
                createWorkOrderResponse = await result.Content.ReadFromJsonAsync<CreateWorkOrderResponse>();
            }
            LogPayload(JsonConvert.SerializeObject(createWorkOrderResponse), "Response");
            boomiRequestResponse.Status = BoomiResponseType.Success.ToString();
            boomiRequestResponse.ResponseStatus = createWorkOrderResponse.Success;
            boomiRequestResponse.ResponseDateTime = DateTime.UtcNow;
            boomiRequestResponse.ResponseBody = JsonConvert.SerializeObject(createWorkOrderResponse);

            if (!createWorkOrderResponse.Success.Equals("1")
                && createWorkOrderResponse.Errors != null && createWorkOrderResponse.Errors.Any())
            {
                boomiRequestResponse.ErrorMessage = JsonConvert.SerializeObject(createWorkOrderResponse.Errors);
                boomiRequestResponse.Status = BoomiResponseType.Failed.ToString();
            }
            RecordResponse(boomiRequestResponse);
            return createWorkOrderResponse;
        }

        public async Task<GetInventoryExtractResponse> GetInventoryExtract(GetInventoryExtractRequest getInventoryExtractRequest)
        {
            var request = JsonConvert.SerializeObject(getInventoryExtractRequest);
            LogPayload(request, "Request");
            GetInventoryExtractResponse getInventoryExtractResponse = new GetInventoryExtractResponse();

            var data = new StringContent(request, Encoding.UTF8, "application/json");

            httpClient.DefaultRequestHeaders.Add("KeyId", configuration["API_Key"]);
            var url = configuration["inInventory/GetInventoryExtract"];
            var responseTask = httpClient.PostAsync(url, data);
            responseTask.Wait();
            var result = responseTask.Result;
            if (result.IsSuccessStatusCode)
            {
                getInventoryExtractResponse = await result.Content.ReadFromJsonAsync<GetInventoryExtractResponse>();
            }
            LogPayload(JsonConvert.SerializeObject(getInventoryExtractResponse), "Response");
            return getInventoryExtractResponse;
        }
        public async Task<GetTransferMarkupResponse> GetTransferMarkup(GetTransferMarkupRequest getTransferMarkupRequest)
        {
            var request = JsonConvert.SerializeObject(getTransferMarkupRequest);
            LogPayload(request, "Request");
            GetTransferMarkupResponse getTransferMarkupResponse = new GetTransferMarkupResponse();

            var data = new StringContent(request, Encoding.UTF8, "application/json");

            httpClient.DefaultRequestHeaders.Add("KeyId", configuration["API_Key"]);
            var url = configuration["inSalesOrder/GetTransferMarkup"];
            var responseTask = httpClient.PostAsync(url, data);
            responseTask.Wait();
            var result = responseTask.Result;
            if (result.IsSuccessStatusCode)
            {
                getTransferMarkupResponse = await result.Content.ReadFromJsonAsync<GetTransferMarkupResponse>();
            }
            LogPayload(JsonConvert.SerializeObject(getTransferMarkupResponse), "Response");
            return getTransferMarkupResponse;
        }
        private void LogPayload(string payload, string type)
        {
            logger.LogInformation($"{type} Payload: {payload}");
        }

        public void RecordRequestPayload(BoomiRequestResponse boomiRequestResponse)
        {
            boomiRequestResponseCommandRepository.Create(boomiRequestResponse);
            boomiRequestResponseCommandRepository.SaveChanges();
        }

        public void RecordResponse(BoomiRequestResponse boomiRequestResponse)
        {
            boomiRequestResponseCommandRepository.Update(boomiRequestResponse);
            boomiRequestResponseCommandRepository.SaveChanges();
        }

        public Task<List<BoomiRequestResponse>> GetEventInfo(long eventId)
        {
            var filter = PredicateBuilder.Create<BoomiRequestResponse>(x => x.EventId == eventId);
            return Task.FromResult(boomiRequestResponseQueryRepository.Get(filter, null, null).ToList());
        }
        public async Task<ItemBranchResponse> GetItemBranch(ItemBranchRequest itemBranchRequest)
        {
            itemBranchRequest.erpUserId = GetDefaultErpUserId(itemBranchRequest.erpUserId);
            var boomiRequestResponse = new BoomiRequestResponse()
            {
                RequestId = itemBranchRequest.RequestId,
                CorelationId = itemBranchRequest.CorelationId,
                EventId = itemBranchRequest.EventId,
                KeyName = itemBranchRequest.KeyName,
                KeyValue = itemBranchRequest.KeyValue,
                RequestDateTime = DateTime.UtcNow,
                RequestStatus = BoomiResponseType.Success.ToString(),
                RequestBody = JsonConvert.SerializeObject(itemBranchRequest),
                RequestURL = configuration["ItemBranch_URI"],
                RequestMethod = "GetItemBranch",
                HttpVerb = "Post",
                ActionBy = itemBranchRequest.ActionBy
            };
            RecordRequestPayload(boomiRequestResponse);
            var request = JsonConvert.SerializeObject(itemBranchRequest);
            LogPayload(request, "Request");
            ItemBranchResponse itemBranchResponse = new ItemBranchResponse();
            var data = new StringContent(request, Encoding.UTF8, "application/json");
            httpClient.DefaultRequestHeaders.Add("KeyId", configuration["API_Key"]);
            var url = configuration["ItemBranch_URI"];
            httpClient.Timeout = new TimeSpan(0, 2, 0);
            var responseTask = httpClient.PostAsync(url, data);
            responseTask.Wait();
            var result = responseTask.Result;
            LogPayload(JsonConvert.SerializeObject(result.Content), "Result");
            if (result.IsSuccessStatusCode)
            {
                try
                {
                    itemBranchResponse = await result.Content.ReadFromJsonAsync<ItemBranchResponse>();
                }
                catch (Exception ex)
                {
                    itemBranchResponse.Success = "0";
                    itemBranchResponse.Errors[0].Error = ex.Message;
                }

            }
            boomiRequestResponse.Status = BoomiResponseType.Success.ToString();
            boomiRequestResponse.ResponseStatus = itemBranchResponse.Success;
            boomiRequestResponse.RequestDateTime = DateTime.UtcNow;
            boomiRequestResponse.ResponseBody = JsonConvert.SerializeObject(itemBranchResponse);
            if (itemBranchResponse.Success != null && !itemBranchResponse.Success.Equals("1") &&
                itemBranchResponse.Errors != null && itemBranchResponse.Errors.Any())
            {
                boomiRequestResponse.ErrorMessage = JsonConvert.SerializeObject(itemBranchResponse.Errors);
                boomiRequestResponse.Status = BoomiResponseType.Failed.ToString();
            }
            RecordResponse(boomiRequestResponse);
            LogPayload(JsonConvert.SerializeObject(itemBranchResponse), "Response");
            return itemBranchResponse;

        }
        public async Task<ItemMasterResponse> GetItemMaster(ItemMasterRequest itemMasterRequest)
        {
            itemMasterRequest.erpUserId = GetDefaultErpUserId(itemMasterRequest.erpUserId);
            var boomiRequestResponse = new BoomiRequestResponse()
            {
                RequestId = itemMasterRequest.RequestId,
                CorelationId = itemMasterRequest.CorelationId,
                EventId = itemMasterRequest.EventId,
                KeyName = itemMasterRequest.KeyName,
                KeyValue = itemMasterRequest.KeyValue,
                RequestDateTime = DateTime.UtcNow,
                RequestStatus = BoomiResponseType.Success.ToString(),
                RequestBody = JsonConvert.SerializeObject(itemMasterRequest),
                RequestURL = configuration["ItemMaster_URI"],
                RequestMethod = "GetItemMaster",
                HttpVerb = "Post",
                ActionBy = itemMasterRequest.ActionBy
            };
            RecordRequestPayload(boomiRequestResponse);
            var request = JsonConvert.SerializeObject(itemMasterRequest);
            LogPayload(request, "Request");
            ItemMasterResponse itemMasterResponse = new ItemMasterResponse();
            var data = new StringContent(request, Encoding.UTF8, "application/json");
            httpClient.DefaultRequestHeaders.Add("KeyId", configuration["API_Key"]);
            var url = configuration["ItemMaster_URI"];
            httpClient.Timeout = new TimeSpan(0, 5, 0);
            var responseTask = httpClient.PostAsync(url, data);
            responseTask.Wait();
            var result = responseTask.Result;
            LogPayload(result.Content.ToString(), "Direct Result");
            LogPayload(JsonConvert.SerializeObject(result.Content), "Result");
            if (result.IsSuccessStatusCode)
            {
                if (result.IsSuccessStatusCode)
                {
                    try
                    {
                        itemMasterResponse = await result.Content.ReadFromJsonAsync<ItemMasterResponse>();
                    }
                    catch (Exception ex)
                    {
                        itemMasterResponse.Success = "0";
                        itemMasterResponse.Errors[0].Error = ex.Message;
                    }

                }
                boomiRequestResponse.Status = BoomiResponseType.Success.ToString();
                boomiRequestResponse.ResponseStatus = itemMasterResponse.Success;
                boomiRequestResponse.RequestDateTime = DateTime.UtcNow;
                boomiRequestResponse.ResponseBody = JsonConvert.SerializeObject(itemMasterResponse);
                if (!itemMasterResponse.Success.Equals("1") &&
                    itemMasterResponse.Errors != null && itemMasterResponse.Errors.Any())
                {
                    boomiRequestResponse.ErrorMessage = JsonConvert.SerializeObject(itemMasterResponse.Errors);
                    boomiRequestResponse.Status = BoomiResponseType.Failed.ToString();
                }
                RecordResponse(boomiRequestResponse);
                LogPayload(JsonConvert.SerializeObject(itemMasterResponse), "Response");
            }

            return itemMasterResponse;
        }

        public async Task<JdeInventoryResponse> GetJdeInventory(GetJdeInventoryRequest getJdeInventoryRequest)
        {
            getJdeInventoryRequest.erpUserId = GetDefaultErpUserId(getJdeInventoryRequest.erpUserId);
            var boomiRequestResponse = new BoomiRequestResponse()
            {
                RequestId = getJdeInventoryRequest.RequestId,
                CorelationId = getJdeInventoryRequest.CorelationId,
                EventId = getJdeInventoryRequest.EventId,
                KeyName = getJdeInventoryRequest.KeyName,
                KeyValue = getJdeInventoryRequest.KeyValue,
                RequestDateTime = DateTime.UtcNow,
                RequestStatus = BoomiResponseType.Success.ToString(),
                RequestBody = JsonConvert.SerializeObject(getJdeInventoryRequest),
                RequestURL = configuration["GetJDEInventory"],
                RequestMethod = "GetJdeInventory",
                HttpVerb = "Post",
                ActionBy = getJdeInventoryRequest.ActionBy
            };
            RecordRequestPayload(boomiRequestResponse);
            var generateGetJDEInventoryRequest = new
            {
                PartNumber = getJdeInventoryRequest.PartNumber,
                ReferenceNumber = getJdeInventoryRequest.ReferenceNumber,
                TargetERP = getJdeInventoryRequest.TargetERP
            };

            var request = JsonConvert.SerializeObject(generateGetJDEInventoryRequest);
            JdeInventoryResponse jdeInventoryResponse = new JdeInventoryResponse();
            logger.LogInformation($"GetJdeInventory Request : {request}");
            var data = new StringContent(request, Encoding.UTF8, "application/json");
            httpClient.DefaultRequestHeaders.Clear();
            httpClient.DefaultRequestHeaders.Add("KeyId", configuration["API_Key"]);
            var url = configuration["GetJDEInventory"];
            var responseTask = httpClient.PostAsync(url, data);
            responseTask.Wait();
            var result = responseTask.Result;
            if (result.IsSuccessStatusCode)
            {
                jdeInventoryResponse = await result.Content.ReadFromJsonAsync<JdeInventoryResponse>();
                var json = result.Content.ReadAsStringAsync().Result;
                logger.LogInformation($"GetJdeInventory Response : {json}");
                boomiRequestResponse.Status = BoomiResponseType.Success.ToString();
                boomiRequestResponse.ResponseStatus = jdeInventoryResponse.Success;
                boomiRequestResponse.ResponseDateTime = DateTime.UtcNow;
                boomiRequestResponse.ResponseBody = JsonConvert.SerializeObject(jdeInventoryResponse);
                if (!jdeInventoryResponse.Success.Equals("1") &&
                    jdeInventoryResponse.Errors != null && jdeInventoryResponse.Errors.Any()
                    && !string.IsNullOrEmpty(jdeInventoryResponse.Errors.FirstOrDefault().Error))
                {
                    boomiRequestResponse.ErrorMessage = JsonConvert.SerializeObject(jdeInventoryResponse.Errors);
                    boomiRequestResponse.Status = BoomiResponseType.Failed.ToString();
                }
            }
            RecordResponse(boomiRequestResponse);
            return jdeInventoryResponse;
        }

        private string GetDefaultErpUserId(string erpUserId)
        {
            return string.IsNullOrEmpty(erpUserId) ? configuration["Default_ErpUserId"] : erpUserId;
        }

        public async Task<ValidateInventoryResponse> ValidateInventory(ValidateInventoryRequest validateInventoryRequest)
        {
            var request = JsonConvert.SerializeObject(validateInventoryRequest);
            LogPayload(request, "Request");
            ValidateInventoryResponse validateInventoryResponse = new ValidateInventoryResponse();

            var data = new StringContent(request, Encoding.UTF8, "application/json");
            httpClient.DefaultRequestHeaders.Clear();
            httpClient.DefaultRequestHeaders.Add("KeyId", configuration["API_Key"]);
            var url = configuration["InventoryValidation_URI"];
            httpClient.Timeout = new TimeSpan(0, 5, 0);
            var responseTask = httpClient.PostAsync(url, data);
            responseTask.Wait();
            var result = responseTask.Result;
            if (result.IsSuccessStatusCode)
            {
                validateInventoryResponse = await result.Content.ReadFromJsonAsync<ValidateInventoryResponse>();
                LogPayload(JsonConvert.SerializeObject(validateInventoryResponse), "Response");
            }

            return validateInventoryResponse;
        }

        public async Task<NotaFiscalResponse> UpdateNotfiscalInCDS(NotaFiscalRequest notaFiscalRequest)
        {
            var request = JsonConvert.SerializeObject(notaFiscalRequest);
            LogPayload(request, "Request");
            NotaFiscalResponse notaFiscalResponse = new NotaFiscalResponse(); UpdateNotaFiscalNumber updateNotaFiscalNumber = new UpdateNotaFiscalNumber();
            updateNotaFiscalNumber.OtherDocInfo = notaFiscalRequest.NotaFiscalNumber.ToString();
            updateNotaFiscalNumber.OtherDocNumber = notaFiscalRequest.NotaFiscalNumber.ToString();
            var updateNotafiscalrequest = JsonConvert.SerializeObject(updateNotaFiscalNumber);
            var data = new StringContent(updateNotafiscalrequest, Encoding.UTF8, "application/json");
            LogPayload(updateNotafiscalrequest, "UpdateNotafiscalrequest");
            httpClient.DefaultRequestHeaders.Clear();
            httpClient.DefaultRequestHeaders.Add("KeyId", configuration["API_Key"]);
            var url = configuration["CDS_URI"];
            var responseTask = httpClient.PostAsync(url, data);
            responseTask.Wait();
            var result = responseTask.Result;
            if (result.IsSuccessStatusCode)
            {
                var notaFiscalResponsestring = await result.Content.ReadAsStringAsync();
                var userObj = JObject.Parse(notaFiscalResponsestring);
                var StatusCode = Convert.ToString(userObj["content"]) == "Created" ? 1 : 0;
                var Content = Convert.ToString(userObj["content"]) == "Created" ? "" : Convert.ToString(userObj["content"]);
                notaFiscalResponse.Status = StatusCode;
                notaFiscalResponse.ErrorMessage = Content;
                LogPayload(JsonConvert.SerializeObject(notaFiscalResponse), "Response");
            }
            return notaFiscalResponse;
        }

        public async Task<NotaFiscalResponse> UpdateNotafiscal(NotaFiscalRequest notaFiscalRequest)
        {
            var request = JsonConvert.SerializeObject(notaFiscalRequest);
            string url = string.Empty;
            LogPayload(request, "Request");
            NotaFiscalResponse notaFiscalResponse = new NotaFiscalResponse();
            UpdateNotaFiscalNumber updateNotaFiscalNumber = new UpdateNotaFiscalNumber();
            var nfNumber = Convert.ToInt32(notaFiscalRequest.NotaFiscalNumber);
            var ukId = Convert.ToInt32(notaFiscalRequest.NotaFiscalNumber);
            var notaFiscalInfoData = notaFiscalInfoService.GetNotaFiscalInfoService(nfNumber, notaFiscalRequest.NotaFiscalSeries, notaFiscalRequest.DocumentType, ukId);

            if (notaFiscalInfoData.Count() > 0)
            {
                var notaFiscaldetails = notaFiscalInfoData.FirstOrDefault();

                updateNotaFiscalNumber.OtherDocInfo = notaFiscaldetails.NotaFiscalNumber.ToString();
                updateNotaFiscalNumber.OtherDocNumber = notaFiscaldetails.NotaFiscalNumber.ToString();
                updateNotaFiscalNumber.OrderType = notaFiscaldetails.OrderType;
            }

            var updateNotafiscalrequest = JsonConvert.SerializeObject(updateNotaFiscalNumber);
            var data = new StringContent(updateNotafiscalrequest, Encoding.UTF8, "application/json");
            LogPayload(updateNotafiscalrequest, "UpdateNotafiscalrequest");
            httpClient.DefaultRequestHeaders.Clear();
            httpClient.DefaultRequestHeaders.Add("KeyId", configuration["API_Key"]);

            if (updateNotaFiscalNumber.OrderType == VHTransaction || updateNotaFiscalNumber.OrderType == VSTransaction ||
               updateNotaFiscalNumber.OrderType == VDTransaction || updateNotaFiscalNumber.OrderType == VBTransaction) // FNTS
            {
                url = configuration["FNTS_RefreshNota_url"];
            }
            else if (updateNotaFiscalNumber.OrderType == VATransaction || updateNotaFiscalNumber.OrderType == VCTransaction) // CDS
            {
                url = configuration["CDS_RefreshNota_url"];
            }

            var responseTask = httpClient.PostAsync(url, data);
            responseTask.Wait();
            var result = responseTask.Result;
            if (result.IsSuccessStatusCode)
            {
                var notaFiscalResponsestring = await result.Content.ReadAsStringAsync();
                var userObj = JObject.Parse(notaFiscalResponsestring);
                var StatusCode = Convert.ToString(userObj["content"]) == "Created" ? 1 : 0;
                var Content = Convert.ToString(userObj["content"]) == "Created" ? "" : Convert.ToString(userObj["content"]);
                notaFiscalResponse.Status = StatusCode;
                notaFiscalResponse.ErrorMessage = Content;
                LogPayload(JsonConvert.SerializeObject(notaFiscalResponse), "Response");
            }
            return notaFiscalResponse;
        }
    }

}

