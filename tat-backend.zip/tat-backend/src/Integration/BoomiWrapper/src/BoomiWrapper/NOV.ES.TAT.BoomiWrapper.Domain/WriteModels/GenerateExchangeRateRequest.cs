﻿namespace NOV.ES.TAT.BoomiWrapper.Domain.WriteModels
{
    public class GenerateExchangeRateRequest : BoomiRequestBaseModel
    {
        public string CurrencyCodeFrom { get; set; }
        public string CurrencyCodeTo { get; set; }
        public DateTime ExchangeDate { get; set; }
    }
}
