﻿using NOV.ES.TAT.Common.Appnotification.Models;
using TaskStatus = NOV.ES.TAT.Common.Appnotification.Models.TaskStatus;

namespace NOV.ES.TAT.Common.Appnotification.Service
{
    public interface IAppNotificationClient
    {
        public List<EventEntry> GetEventEntries(Event primaryEvent, string keyId, string secondaryKeyId = null);
        public void CreateEventProgressStatus(Event primaryEvent, string keyId,
            string secondaryKeyId = null);
        public void UpdateSubTaskEventProgressAndNotify(Event primaryEvent, string keyId,
            int subTaskId, TaskStatus taskStatus,
            string notificationMethod, string notificationJson,
            string secondaryKeyId = null,
            string errorMessage = "", string action = "");
        public string UpdateCacheExpiration(Event primaryEvent, string keyId, string secondaryKeyId = null, int inMinutes = 60);
        public string RemoveEventEntryCache(Event primaryEvent, string keyId, string secondaryKeyId = null);
    }
}
