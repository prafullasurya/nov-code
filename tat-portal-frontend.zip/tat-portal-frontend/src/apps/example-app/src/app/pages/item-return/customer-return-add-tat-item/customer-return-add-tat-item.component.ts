import { Component} from '@angular/core';

interface City {
  name: string,
  code: string
}
@Component({
  selector: 'customer-return-add-tat-item',
  templateUrl: './customer-return-add-tat-item.component.html',
  styleUrls: ['./customer-return-add-tat-item.component.scss']
})
export class CustomerReturnTatItemComponent {
  
  displayonfirmAssemblyNft: boolean;

  showConfirmAssemblyNftDialog() {
    this.displayonfirmAssemblyNft = true;
  } 

}
