import { Component, OnInit } from '@angular/core';
import { ConfirmationService, MessageService } from 'primeng/api';

interface City {
  name: string,
  code: string
}
@Component({
  selector: 'active-usage-attach',
  templateUrl: './active-usage-attach.component.html',
  styleUrls: ['./active-usage-attach.component.scss']
})
export class ActiveUsageAttachComponent {
  
}
