﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.API.Helper;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetPaginationCompanyErpInfoHandler
           : IQueryHandler<GetPaginationCompanyErpInfoQuery, PagedResult<CompanyErpInfoDto>>
    {
        private readonly IMapper mapper;
        private readonly ICompanyErpInfoService companyErpInfoService;
        private readonly IHttpContextAccessor httpContextAccessor;

        public GetPaginationCompanyErpInfoHandler(
            IMapper mapper
            ,ICompanyErpInfoService companyErpInfoService
            , IHttpContextAccessor httpContextAccessor)
        {
            this.mapper = mapper;
            this.companyErpInfoService = companyErpInfoService;
            this.httpContextAccessor = httpContextAccessor;
        }

        public Task<PagedResult<CompanyErpInfoDto>> Handle(GetPaginationCompanyErpInfoQuery request,
          CancellationToken cancellationToken)
        {
            var companyErpInfo = companyErpInfoService.GetCompanyErpInfo(request.PagingParameters);
            var result = mapper.Map<PagedResult<CompanyErpInfo>, PagedResult<CompanyErpInfoDto>>(companyErpInfo);
            PagingHelper.AddPagingMetadata<CompanyErpInfoDto>(result, httpContextAccessor);
            return Task.FromResult(result);
        }
    }
}