﻿namespace NOV.ES.TAT.BoomiWrapper.Domain.WriteModels
{
    public class GenerateSalesOrderStatusRequest : BoomiRequestBaseModel
    { 
        public string SZUniqueOrderReferenceNumber { get; set; }
    }
}
