import { Component, OnInit } from '@angular/core';
import { ConfirmationService, MessageService } from 'primeng/api';



interface City {
  name: string,
  code: string
}
@Component({
  selector: 'add-attachment',
  templateUrl: './add-attachment.component.html',
  styleUrls: ['./add-attachment.component.scss']
})
export class AddAttachmentComponent {
  
  displayBasic: boolean;
  displayCreateNft: boolean;
  displayOption: boolean;

    // ngOnInit(): void {
    //   throw new Error('Method not implemented.');
    // }
    showBasicDialog() {
      this.displayBasic = true;
    }
    showCreateNftDialog() {
      this.displayCreateNft = true;
    }
    showOptionDialog() {
      this.displayOption = true;
    }
}
