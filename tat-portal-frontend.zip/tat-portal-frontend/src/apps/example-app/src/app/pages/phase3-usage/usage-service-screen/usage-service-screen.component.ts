import { Component, OnInit } from '@angular/core';
import { ConfirmationService, MessageService } from 'primeng/api';


interface City {
  name: string,
  code: string
}
@Component({
  selector: 'usage-service-screen',
  templateUrl: './usage-service-screen.component.html',
  styleUrls: ['./usage-service-screen.component.scss']
})
export class UsageServiceScreenComponent {
  
  // activeIndex1: number = 0;

  // activeIndex2: number = 0;

  // scrollableTabs: any[] = Array.from({ length: 50 }, (_, i) => ({ title: `Tab ${i + 1}`, content: `Tab ${i + 1} Content` }));

}
