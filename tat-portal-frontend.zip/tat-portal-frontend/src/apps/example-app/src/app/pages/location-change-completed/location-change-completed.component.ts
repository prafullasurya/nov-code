import { Component, OnInit } from '@angular/core';

interface City {
  name: string,
  code: string
}

@Component({
  selector: 'tat-portal-frontend-location-change-completed',
  templateUrl: './location-change-completed.component.html',
  styleUrls: ['./location-change-completed.component.scss']
})
export class LocationChangeCompletedComponent implements OnInit {
  displayBasic1: boolean;
  displayModal: boolean;
  displayCreateNewFinancialTransfer: boolean;
  displayAdvanceSearch: boolean;

  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }

  showBasicDialog() {
    this.displayBasic1 = true;
  }

  //Data Validation Message
  showModalDialog() {
    this.displayModal = true;
  }

  showCreateNewFinancialTransfer() {
    this.displayCreateNewFinancialTransfer = true;
  }
}
