﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Admin.API.DTOs;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetLocationByTatReferenceIdQuery : IQuery<LocationDto>
    {
        public int TATReferenceId { get; private set; }

        public GetLocationByTatReferenceIdQuery(int tatReferenceId)
        {
            this.TATReferenceId = tatReferenceId;
            
        }
    }
}
