﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using NOV.ES.Framework.Core.CQRS.Commands;
using NOV.ES.TAT.Admin.DomainService;
using System.Net;
using System.Net.Mime;

namespace NOV.ES.TAT.Admin.API.Application.Commands
{
    public class DeleteUserPreferenceHandler : ICommandHandler<DeleteUserPreferenceCommand, ContentResult>
    {        
        private readonly IUserPreferenceService userPreferenceService;

        public DeleteUserPreferenceHandler(          
            IUserPreferenceService userPreferenceService)
        {                      
            this.userPreferenceService = userPreferenceService;
        }
        public Task<ContentResult> Handle(DeleteUserPreferenceCommand request, CancellationToken cancellationToken)
        {
            ContentResult contentResult = new()
            {
                ContentType = MediaTypeNames.Application.Json
            };
            if (!IsValidRequest(request))
            {
                contentResult.Content = JsonConvert.SerializeObject("Value can not be null or Empty");
                contentResult.StatusCode = (int)HttpStatusCode.BadRequest;
                return Task.FromResult(contentResult);
            }
            bool result = userPreferenceService.DeleteUserPreference(request.Id);
            if (result)
                contentResult.StatusCode = (int)HttpStatusCode.OK;

            return Task.FromResult(contentResult);
        }
        private static bool IsValidRequest(DeleteUserPreferenceCommand request)
        {
            if (request != null && request.Id != 0)
                return true;
            return false;
        }
    }
}