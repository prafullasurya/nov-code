﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetErpItemsBatchByIdHandler : IQueryHandler<GetErpItemsBatchByIdQuery, ErpItemsBatchDto>
    {
        private readonly IMapper mapper;
        private readonly IErpItemsBatchService erpItemsBatchService;

        public GetErpItemsBatchByIdHandler(
            IMapper mapper,
            IErpItemsBatchService erpItemsBatchService)
        {
            this.mapper = mapper;
            this.erpItemsBatchService = erpItemsBatchService;
        }

        public Task<ErpItemsBatchDto> Handle(GetErpItemsBatchByIdQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var erpItemsBatch = erpItemsBatchService.GetErpItemsBatchById(request.Id);
            var result = mapper.Map<ErpItemsBatch, ErpItemsBatchDto>(erpItemsBatch);
            return Task.FromResult(result);
        }
        private static bool IsValidRequest(GetErpItemsBatchByIdQuery request)
        {
            return (request != null && request.Id != 0);
        }
    }
}