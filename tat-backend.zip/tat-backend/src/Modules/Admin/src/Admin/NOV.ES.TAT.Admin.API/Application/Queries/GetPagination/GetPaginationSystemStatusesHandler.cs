﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.API.Helper;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetPaginationSystemStatusesHandler
           : IQueryHandler<GetPaginationSystemStatusesQuery, PagedResult<SystemStatusDto>>
    {
        private readonly IMapper mapper;
        private readonly ISystemStatusService systemStatusService;
        private readonly IHttpContextAccessor httpContextAccessor;

        public GetPaginationSystemStatusesHandler(
            IMapper mapper
            ,ISystemStatusService systemStatusService
            , IHttpContextAccessor httpContextAccessor)
        {            
            this.mapper = mapper;
            this.systemStatusService = systemStatusService;
            this.httpContextAccessor = httpContextAccessor;
        }

        public Task<PagedResult<SystemStatusDto>> Handle(GetPaginationSystemStatusesQuery request,
          CancellationToken cancellationToken)
        {
            var systemStatuses = systemStatusService.GetSystemStatuses(request.PagingParameters);
            var result = mapper.Map<PagedResult<SystemStatus>, PagedResult<SystemStatusDto>>(systemStatuses);

            PagingHelper.AddPagingMetadata<SystemStatusDto>(result, httpContextAccessor);
            return Task.FromResult(result);
        }
    }
}