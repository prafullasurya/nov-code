﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetDefinedInputGroupValueByIdHandler : IQueryHandler<GetDefinedInputGroupValueByIdQuery, DefinedInputGroupValueDto>
    {
        private readonly IMapper mapper;
        private readonly IDefinedInputGroupValueService definedInputGroupValueService;

        public GetDefinedInputGroupValueByIdHandler(
            IMapper mapper,
            IDefinedInputGroupValueService definedInputGroupValueService)
        {
            this.mapper = mapper;
            this.definedInputGroupValueService = definedInputGroupValueService;
        }

        public Task<DefinedInputGroupValueDto> Handle(GetDefinedInputGroupValueByIdQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var definedInputGroupValue = definedInputGroupValueService.GetDefinedInputGroupValueById(request.DefinedInputGroupValueId);
            return Task.FromResult(mapper.Map<DefinedInputGroupValue, DefinedInputGroupValueDto>(definedInputGroupValue));
        }

        private static bool IsValidRequest(GetDefinedInputGroupValueByIdQuery request)
        {
            return (request != null && request.DefinedInputGroupValueId != 0);
        }
    }
}
