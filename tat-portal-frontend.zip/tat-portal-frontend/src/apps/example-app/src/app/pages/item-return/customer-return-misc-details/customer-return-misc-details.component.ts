import { Component} from '@angular/core';

interface City {
  name: string,
  code: string
}
@Component({
  selector: 'customer-return-misc-details',
  templateUrl: './customer-return-misc-details.component.html',
  styleUrls: ['./customer-return-misc-details.component.scss']
})
export class CustomerReturnMiscDetailsComponent {
  
}
