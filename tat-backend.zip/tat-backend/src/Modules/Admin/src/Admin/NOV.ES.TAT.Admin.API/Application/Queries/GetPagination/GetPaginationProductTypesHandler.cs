﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.API.Helper;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetPaginationProductTypesHandler
           : IQueryHandler<GetPaginationProductTypesQuery, PagedResult<ProductTypeDto>>
    {
        private readonly IMapper mapper;
        private readonly IProductTypeService productTypeService;
        private readonly IHttpContextAccessor httpContextAccessor;

        public GetPaginationProductTypesHandler(
             IMapper mapper
            , IProductTypeService productTypeService
            , IHttpContextAccessor httpContextAccessor)
        {            
            this.mapper = mapper;
            this.productTypeService = productTypeService;
            this.httpContextAccessor = httpContextAccessor;
        }

        public Task<PagedResult<ProductTypeDto>> Handle(GetPaginationProductTypesQuery request,
          CancellationToken cancellationToken)
        {
            var ProductTypes = productTypeService.GetProductTypes(request.PagingParameters);
            var result = mapper.Map<PagedResult<ProductType>, PagedResult<ProductTypeDto>>(ProductTypes);
            PagingHelper.AddPagingMetadata<ProductTypeDto>(result, httpContextAccessor);
            return Task.FromResult(result);
        }
    }
}