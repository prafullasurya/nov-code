﻿namespace NOV.ES.TAT.BoomiWrapper.DomainService.ResponseModel
{
    public class InventoryAdjustmentResponse
    {
        public string Success { get; set; }
        public int JDEDocNumber { get; set; }
        public string JDEDocType { get; set; }
        public string FromBranchPlant { get; set; }
        public string FromKeyCompany { get; set; }
        public string ToBranchPlant { get; set; }
        public List<ErpError> Errors { get; set; }
    }
}
