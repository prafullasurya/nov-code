﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;

namespace NOV.ES.TAT.Admin.API.Application.Queries.GetById
{

    public class GetCompanyDivisonByBUQuery : IQuery<BUCompanyDetailsDivisionView>
    {
        public string BusinessUnitCode { get; private set; }

        public GetCompanyDivisonByBUQuery(string businessUnitCode)
        {
            this.BusinessUnitCode = businessUnitCode;
        }
    }
}
