﻿using NOV.ES.TAT.AppNotification.API.Models;

namespace NOV.ES.TAT.AppNotification.API.SignalRHub
{
    public interface ITATAppNotificationHub
    {
        Task SendNotificationToAll(NotificationToAll notificationToAll);

        Task BroadcastCtsTaskProgress(CtsTaskProgressNotification ctsTaskProgressNotification);

        /// <summary>
        /// Function to Check and Update Notafical Number 
        /// </summary>
        /// <param name="broadcastNotaFiscalNotification"></param>
        /// <returns></returns>
        Task BroadcastNotaFiscal(BroadcastNotaFiscalNotification broadcastNotaFiscalNotification);
        Task GetConnectionId(string connectionId);

    }
}
