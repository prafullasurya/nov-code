﻿namespace NOV.ES.TAT.BoomiWrapper.DomainService.ResponseModel
{
    public class ItemAvailabilityResponse
    {
        public string Success { get; set; }
        public List<ErpError> Errors { get; set; }
        public List<ItemAvailabilityResponseData> Data { get; set; }
    }
}
