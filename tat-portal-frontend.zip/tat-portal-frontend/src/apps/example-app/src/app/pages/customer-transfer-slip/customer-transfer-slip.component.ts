import { Component } from '@angular/core';
import { MenuItem } from 'primeng/api';
import {CalendarModule} from 'primeng/calendar';
import { ProductService } from '../../models/productservice';
import { Product } from '../../models/product';
import { ThemeService } from '../../services/theme.service';

interface City {
  name: string,
  code: string
}

@Component({
  selector: 'tat-portal-frontend-customer-transfer-slip',
  templateUrl: './customer-transfer-slip.component.html',
  styleUrls: ['./customer-transfer-slip.component.scss']
})

export class CustomerTransferSlipComponent  {
  cities: City[];
  selectedCity: City;
  date3: Date;
  ChangeSequenceDisplay: boolean;
  city: string;
  search: string;
  selectedValues: string[] = [];

  //2nd Level DataGrid
  products: Product[];

  constructor(private productService: ProductService) { }
  
  selectedCategory: any = null;
  selectedCities: string[] = [];

  
  ngOnInit() {
      this.productService.getProductsWithOrdersSmall().then(data => this.products = data);
  }
    
  showBasicAdvanceSearch() {
    this.ChangeSequenceDisplay = true;
  }
  
}
