import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerReturnTatItemComponent } from './customer-return-add-tat-item.component';

describe('CustomerReturnTatItemComponent', () => {
  let component: CustomerReturnTatItemComponent;
  let fixture: ComponentFixture<CustomerReturnTatItemComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerReturnTatItemComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerReturnTatItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
