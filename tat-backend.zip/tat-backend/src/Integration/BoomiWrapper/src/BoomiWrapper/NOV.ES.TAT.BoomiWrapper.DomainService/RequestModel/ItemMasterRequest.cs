﻿using Newtonsoft.Json;
using NOV.ES.TAT.BoomiWrapper.Domain.WriteModels;

namespace NOV.ES.TAT.BoomiWrapper.DomainService.RequestModel
{
    public class ItemMasterRequest : BoomiRequestBaseModel

    {
        [JsonProperty("partNumber")]
        public string PartNumber { get; set; }
    }
}
