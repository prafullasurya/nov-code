﻿using Newtonsoft.Json;
using NOV.ES.Framework.Core.Messaging.IntegrationEvents;
using NOV.ES.Framework.Core.Sagas;
using NOV.ES.TAT.BoomiWrapper.API.Application.IntegrationEvents.PublishEvents;
using NOV.ES.TAT.BoomiWrapper.Domain;
using NOV.ES.TAT.BoomiWrapper.Domain.WriteModels;
using NOV.ES.TAT.BoomiWrapper.DomainService;
using NOV.ES.TAT.BoomiWrapper.DomainService.RequestModel;
using NOV.ES.TAT.BoomiWrapper.DomainService.ResponseModel;
using AutoMapper;

namespace NOV.ES.TAT.BoomiWrapper.API.Application.IntegrationEvents.SubscribedEvents
{
    public class GenerateSalesOrderStatusHandler
        : IIntegrationEventHandler<GenerateSalesOrderStatus>
    {
        private ILogger<GenerateSalesOrderStatusHandler> logger;
        private readonly IBoomiWrapperService boomiWrapperService;
        private readonly IIntegrationEventBus integrationEventBus;
        private readonly IMapper mapper;

        public GenerateSalesOrderStatusHandler(
            ILogger<GenerateSalesOrderStatusHandler> logger,
            IBoomiWrapperService boomiWrapperService,
            IIntegrationEventBus integrationEventBus,
            IMapper mapper)
        {
            this.logger = logger;
            this.boomiWrapperService = boomiWrapperService;
            this.integrationEventBus = integrationEventBus;
            this.mapper = mapper;
        }

        public Task Handle(GenerateSalesOrderStatus @event)
        {
            logger.LogInformation("----- Consuming Event: Generate Sales Order Status Integration Event");
            logger.LogInformation("----- CorelationId is {id}", @event.CorelationId);
            logger.LogInformation("----- Event Detail is {info}", @event.JsonStringData);

            BoomiRequestResponse boomiRequestResponse;
            //1.Generate request for boomi 
            SalesOrderStatusRequest salesOrderStatusRequest = GenerateRequestPayload(@event.CorelationId, @event.ActionBy, @event.JsonStringData, out boomiRequestResponse);

            //2.Record request in database
            boomiWrapperService.RecordRequestPayload(boomiRequestResponse);

            //3. Boomi Call
            SalesOrderStatusResponse salesOrderStatusResponse = boomiWrapperService.GetSalesOrderStatus(salesOrderStatusRequest).Result;

            //4. Record Response
            boomiRequestResponse.Status = BoomiResponseType.Success.ToString();
            boomiRequestResponse.ResponseStatus = salesOrderStatusResponse.Success;
            boomiRequestResponse.RequestDateTime = DateTime.UtcNow;
            boomiRequestResponse.ResponseBody = JsonConvert.SerializeObject(salesOrderStatusRequest);
            if (salesOrderStatusResponse.Errors != null && salesOrderStatusResponse.Errors.Any())
            {
                boomiRequestResponse.ErrorMessage = JsonConvert.SerializeObject(salesOrderStatusResponse.Errors);
                boomiRequestResponse.Status = BoomiResponseType.Failed.ToString();
            }

            boomiWrapperService.RecordResponse(boomiRequestResponse);

            //5.Generate response for publish event
            var result = GenerateResponseForPublishEvent(salesOrderStatusResponse);

            //6.publish event
            GeneratedSalesOrderStatus success =
            new(
                boomiRequestResponse.RequestId.ToString(),
                @event.CorelationId,
                JsonConvert.SerializeObject(result),
                DateTime.UtcNow,
                SagaEventExecutionResult.Success,
                @event.ActionBy
                );

            logger.LogInformation("Publish Generated Sales Order Status event  - GeneratedSalesOrderStatus.");
            integrationEventBus.Publish(success);

            return Task.CompletedTask;

        }

        private SalesOrderStatusRequest GenerateRequestPayload(Guid corelationId, string actionBy, string jsonStringData, out BoomiRequestResponse boomiRequestResponse)
        {
            var generateSalesOrderStatusRequest = JsonConvert.DeserializeObject<GenerateSalesOrderStatusRequest>(jsonStringData);

            var salesOrderStatusRequest = mapper.Map<GenerateSalesOrderStatusRequest, SalesOrderStatusRequest>(generateSalesOrderStatusRequest);
            boomiRequestResponse = new BoomiRequestResponse()
            {
                RequestId = generateSalesOrderStatusRequest.RequestId,
                CorelationId = corelationId,
                EventId = generateSalesOrderStatusRequest.EventId,
                KeyName = generateSalesOrderStatusRequest.KeyName,
                KeyValue = generateSalesOrderStatusRequest.KeyValue,
                RequestDateTime = DateTime.UtcNow,
                RequestStatus = BoomiResponseType.Success.ToString(),
                RequestBody = JsonConvert.SerializeObject(salesOrderStatusRequest),
                RequestURL = "inSalesOrder/GetSalesOrderStatus",
                RequestMethod = "GetSalesOrderStatus",
                HttpVerb = "Post",
                ActionBy = actionBy
            };

            return salesOrderStatusRequest;
        }

        private static int GenerateResponseForPublishEvent(SalesOrderStatusResponse salesOrderStatusResponse)
        {
            return salesOrderStatusResponse.UniqueOrderReferenceNumber;
        }
    }
}

