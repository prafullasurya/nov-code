﻿using IdentityModel.Client;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace NOV.ES.TAT.Common.ServiceBase
{
    public class InternalServiceBaseClient
    {
        protected readonly ILogger<InternalServiceBaseClient> logger;
        protected readonly IConfiguration configuration;

        public InternalServiceBaseClient(ILogger<InternalServiceBaseClient> logger,
            IConfiguration configuration)
        {
            this.logger = logger;
            this.configuration = configuration;
        }

        protected async Task<TokenResponse> GetIdentityToken()
        {
            using (var client = new HttpClient())
            {
                var disco = await client.GetDiscoveryDocumentAsync(
                    new DiscoveryDocumentRequest
                    {
                        Address = configuration["InternalIdentity"],
                        Policy =
                        {
                            RequireHttps = false
                        }
                    });

                if (disco.IsError)
                {
                    logger.LogError(disco.Error);
                    return null;
                }
                var tokenResponse = await client.RequestClientCredentialsTokenAsync(new ClientCredentialsTokenRequest
                {
                    Address = disco.TokenEndpoint,
                    ClientId = configuration["IdentityClientId"],
                    ClientSecret = configuration["IdentityClientSecret"],
                    Scope = "mdmapi.read lookupapi.read"
                });

                if (tokenResponse.IsError)
                {
                    logger.LogError(tokenResponse.Error);
                }

                return tokenResponse;
            }
        }
    }

}
