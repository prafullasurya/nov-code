import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UsageBasicScreenComponent } from './usage-basic-screen.component';

describe('UsageBasicScreenComponent', () => {
  let component: UsageBasicScreenComponent;
  let fixture: ComponentFixture<UsageBasicScreenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UsageBasicScreenComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UsageBasicScreenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
function beforeEach(arg0: () => void) {
  throw new Error('Function not implemented.');
}

