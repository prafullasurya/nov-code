﻿using Newtonsoft.Json;
using NOV.ES.Framework.Core.Sagas;

namespace NOV.ES.TAT.BoomiWrapper.API.Application.IntegrationEvents.PublishEvents
{
    public class GeneratedRemitoMexicoInformation
        : SagaEvent
    {
        public GeneratedRemitoMexicoInformation(Guid corelationId,
            string jsonStringData)
        {
            this.CorelationId = corelationId;
            this.JsonStringData = jsonStringData;
            this.SagaEventExecutionResult = SagaEventExecutionResult.Success;
        }

        // [JsonConstructor]
        public GeneratedRemitoMexicoInformation(Guid corelationId,
            string jsonStringData,
            SagaEventExecutionResult executionResult)
        {
            this.CorelationId = corelationId;
            this.JsonStringData = jsonStringData;
            this.SagaEventExecutionResult = executionResult;
        }

        [JsonConstructor]
        public GeneratedRemitoMexicoInformation(string keyId, Guid corelationId,
            string jsonStringData,
            DateTime eventDate,
            SagaEventExecutionResult executionResult, string actionBy)
            : base(keyId, corelationId, jsonStringData, eventDate, actionBy)
        {
            this.SagaEventExecutionResult = executionResult;
        }

    }

}
