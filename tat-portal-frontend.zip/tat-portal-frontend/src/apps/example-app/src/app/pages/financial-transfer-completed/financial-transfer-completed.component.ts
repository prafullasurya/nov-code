import { Component, OnInit } from '@angular/core';

interface City {
  name: string,
  code: string
}

@Component({
  selector: 'tat-portal-frontend-financial-transfer-completed',
  templateUrl: './financial-transfer-completed.component.html',
  styleUrls: ['./financial-transfer-completed.component.scss']
})
export class FinancialTransferCompletedComponent implements OnInit {
  displayBasic1: boolean;
  displayAddMiscReceiptItem: boolean;
  displayModal: boolean;
  displayCreateNewFinancialTransfer: boolean;
  displayAdvanceSearch: boolean;

  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }

  showBasicDialog() {
    this.displayBasic1 = true;
  }

  //Dialog Advance Search
  showAdvanceSearch() {
    this.displayAdvanceSearch = true;//showAddMiscReceiptItem
  }

  //Data Validation Message
  showModalDialog() {
    this.displayModal = true;
  }

  showCreateNewFinancialTransfer() {
    this.displayCreateNewFinancialTransfer = true;
  }
}
