import { Component } from '@angular/core';
@Component({
  selector: 'item-return-list',
  templateUrl: './item-return-list.component.html',
  styleUrls: ['./item-return-list.component.scss'],
})
export class ItemReturnListComponent {

  displayExportTOExcel: boolean;
  displayUndoCustReturn: boolean;
  displayCustReturn: boolean;
  
  showExportToExcel() {
    this.displayExportTOExcel = true;
  }
  ShowUndoCustRetun() {
    this.displayUndoCustReturn = true;
  }
  ShowCustRetun() {
    this.displayCustReturn = true;
  }
}
