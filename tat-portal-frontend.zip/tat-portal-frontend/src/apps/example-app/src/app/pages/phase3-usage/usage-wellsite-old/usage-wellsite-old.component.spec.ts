import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UsageWellsiteOldComponent } from './usage-wellsite-old.component';

describe('UsageWellsiteOldComponent', () => {
  let component: UsageWellsiteOldComponent;
  let fixture: ComponentFixture<UsageWellsiteOldComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UsageWellsiteOldComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UsageWellsiteOldComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
function beforeEach(arg0: () => void) {
  throw new Error('Function not implemented.');
}

