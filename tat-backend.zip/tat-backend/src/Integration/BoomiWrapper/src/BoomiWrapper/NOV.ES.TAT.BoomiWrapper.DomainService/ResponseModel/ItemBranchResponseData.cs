﻿namespace NOV.ES.TAT.BoomiWrapper.DomainService.ResponseModel
{
    public class ItemBranchResponseData
    {
        public string BusinessUnit { get; set; }
        public string PartNumber { get; set; }
        public string Itemnumbershort { get; set; }
        public string Description1 { get; set; }
        public string Description2 { get; set; }
        public string SerialNumber { get; set; }
        public string Location { get; set; }
        public string Unitofmeasureweight { get; set; }
        public string Itemnumber3rd { get; set; }
        public string UserDefinedCode { get; set; }
        public string Remark { get; set; }
        public string Remark2 { get; set; }
        public string SupplementalDatabaseCode { get; set; }
        public string QuaCategoryCodentity { get; set; }
    }
}
