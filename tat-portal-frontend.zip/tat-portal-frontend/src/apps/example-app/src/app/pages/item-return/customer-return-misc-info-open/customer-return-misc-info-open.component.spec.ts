import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerReturnMiscInfoComponent } from './customer-return-misc-info-open.component';

describe('CustomerReturnMiscInfoComponent', () => {
  let component: CustomerReturnMiscInfoComponent;
  let fixture: ComponentFixture<CustomerReturnMiscInfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerReturnMiscInfoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerReturnMiscInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
