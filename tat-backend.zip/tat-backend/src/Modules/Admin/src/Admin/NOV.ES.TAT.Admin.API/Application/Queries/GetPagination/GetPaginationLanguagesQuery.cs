﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Admin.API.DTOs;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetPaginationLanguagesQuery : IQuery<PagedResult<LanguageDto>>
    {
        public Paging PagingParameters { get; private set; }

        public GetPaginationLanguagesQuery(Paging pagingParameters)
        {
            this.PagingParameters = pagingParameters;
        }
    }
}
