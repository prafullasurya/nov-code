import { Component, OnInit } from '@angular/core';
import { ConfirmationService, MessageService } from 'primeng/api';
import { Product } from '../../../models/product';
import { ProductService } from '../../../models/productservice';


interface City {
  name: string,
  code: string
}
@Component({
  selector: 'admin-header',
  templateUrl: './admin-header.component.html',
  styleUrls: ['./admin-header.component.scss']
})
export class AdminHeaderComponent {
  toggleMenu =true;
  // activeIndex1: number = 0;

  // activeIndex2: number = 0;

  // scrollableTabs: any[] = Array.from({ length: 50 }, (_, i) => ({ title: `Tab ${i + 1}`, content: `Tab ${i + 1} Content` }));
  toggleSideMenu(){
    const nodeList = document.getElementById("mySidenavul").querySelectorAll("span");
    if(!this.toggleMenu){
      document.getElementById("mySidenav").style.width = "330px";
      for (let i = 0; i < nodeList.length; i++) {
        nodeList[i].style.display = "block";
      }
      document.getElementById("subnavContent").style.cssText = "left: 318px; top: -1px;";
    }else{
      document.getElementById("mySidenav").style.width = "75px";
      for (let i = 0; i < nodeList.length; i++) {
        nodeList[i].style.display = "none";
      }
      document.getElementById("subnavContent").style.cssText = "left: 64px; top: 1px;";
    }
    this.toggleMenu = !this.toggleMenu;
  }
}
