﻿using IdentityModel.Client;
using Microsoft.Extensions.Logging;
using NOV.ES.TAT.Common.ServiceBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NOV.ES.TAT.Common.JwtTokenUtil
{
    public class JwtTokenService
        : IJwtTokenService
    {
        private readonly ILogger<JwtTokenService> logger;
        private readonly HttpClient httpClient;
        
        public JwtTokenService(ILogger<JwtTokenService> logger, HttpClient httpClient)
        {
            this.httpClient = httpClient;
            this.logger = logger;
        }

        public async Task<string> GetClientCredentialTokenAsync(string issuerUrl, string clientId, string clientSecret, string scope, bool isSslEnabled = false)
        {
            if (string.IsNullOrEmpty(issuerUrl)) throw new ArgumentNullException(nameof(issuerUrl));
            if (string.IsNullOrEmpty(clientId)) throw new ArgumentNullException(nameof(clientId));
            if (string.IsNullOrEmpty(clientSecret)) throw new ArgumentNullException(nameof(clientSecret));
            if (string.IsNullOrEmpty(scope)) throw new ArgumentNullException(nameof(scope));

            string accessToken = null;

            var disco = await httpClient.GetDiscoveryDocumentAsync(
                    new DiscoveryDocumentRequest
                    {
                        Address = issuerUrl,
                        Policy =
                        {
                            ValidateIssuerName = false,
                            ValidateEndpoints = false,
                            RequireHttps = isSslEnabled
                        }
                    });

            if (disco.IsError)
            {
                logger.LogError($"Error returned by GetDiscoveryDocumentAsync: {disco.Error}");
                return accessToken;
            }

            var tokenResponse = await httpClient.RequestClientCredentialsTokenAsync(new ClientCredentialsTokenRequest
            {
                Address = disco.TokenEndpoint,
                ClientId = clientId,
                ClientSecret = clientSecret,
                Scope = scope
            });

            if (tokenResponse.IsError)
            {
                logger.LogError($"Error returned by RequestClientCredentialsTokenAsync: {tokenResponse.Error}");
            }
            else
            {
                accessToken = tokenResponse.AccessToken;
            }

            return accessToken;
        }
    }
}
