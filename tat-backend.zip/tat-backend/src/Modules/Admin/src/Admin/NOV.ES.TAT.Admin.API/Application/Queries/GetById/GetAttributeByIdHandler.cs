﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.DomainService;
using Attribute = NOV.ES.TAT.Admin.Domain.Attribute;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetAttributeByIdHandler : IQueryHandler<GetAttributeByIdQuery, AttributeDto>
    {
        private readonly IMapper mapper;
        private readonly IAttributeService attributeService;

        public GetAttributeByIdHandler(
            IMapper mapper,
            IAttributeService attributeService)
        {           
            this.mapper = mapper;
            this.attributeService = attributeService;
        }

        public Task<AttributeDto> Handle(GetAttributeByIdQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var attribute = attributeService.GetAttributeById(request.AttributeId);
            return Task.FromResult(mapper.Map<Attribute, AttributeDto>(attribute));
        }

        private static bool IsValidRequest(GetAttributeByIdQuery request)
        {
            return (request != null && request.AttributeId != 0);
        }
    }
}
