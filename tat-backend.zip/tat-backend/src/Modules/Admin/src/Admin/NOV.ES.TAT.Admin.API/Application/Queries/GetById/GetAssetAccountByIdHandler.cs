﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetAssetAccountByIdHandler : IQueryHandler<GetAssetAccountByIdQuery, AssetAccountDto>
    {
        private readonly IMapper mapper;
        private readonly IAssetAccountService assetAccountService;

        public GetAssetAccountByIdHandler(
            IMapper mapper,
            IAssetAccountService assetAccountService)
        {          
            this.mapper = mapper;
            this.assetAccountService = assetAccountService;
        }

        public Task<AssetAccountDto> Handle(GetAssetAccountByIdQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var assetAccount = assetAccountService.GetAssetAccountById(request.Id);
            var result = mapper.Map<AssetAccount, AssetAccountDto>(assetAccount);
            return Task.FromResult(result);
        }
        private static bool IsValidRequest(GetAssetAccountByIdQuery request)
        {
            return (request != null && request.Id != 0);
        }
    }
}