﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using NOV.ES.Framework.Core.Entities;

namespace NOV.ES.TAT.FrontEnd.Domain
{
    [Table("SystemDownMessage", Schema = "admin")]
    public class MaintenanceModel : BaseEntity<int>
    {
        [Required]
        [MaxLength(50)]
        public string MessageId { get; set; } 
        [MaxLength(250)]
        [Required]
        public string DownTimeReason { get; set; }
        [Required]
        public DateTime ScheduledOn { get; set; }
        [Required]
        public DateTime ExpectedResumeBy { get; set; }

    }
}