﻿namespace NOV.ES.TAT.BoomiWrapper.Domain.WriteModels
{
    public class GenerateItemBranchRequest : BoomiRequestBaseModel
    {
        public int BusinessUnit { get; set; }
        public string PartNumber { get; set; }
        public string Description1 { get; set; }
        public string SerialNumber { get; set; }
        public string Location { get; set; }
    }
}
