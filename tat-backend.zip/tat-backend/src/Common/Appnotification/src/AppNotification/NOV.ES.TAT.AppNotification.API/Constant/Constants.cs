﻿namespace NOV.ES.TAT.AppNotification.API.Constant
{
    public static class Constants
    {
        #region Pagination
        public const int DEFAULT_TOTAL_COUNT = 0;
        public const string ERR_VALUE_NULL_MSG = "Value can not be null or Empty";
        #endregion

        #region Authrization
        public const string MAINT_PKG_SLIP = "MAINT_PKG_SLIP";
        public const string ADD = "Add";
        public const string EDIT = "Edit";
        public const string DELETE = "Delete";
        public const string Features_Toggle_Unauthorized_Error = "Features flag of Feature:{0} is OFF for User";
        public const string MIX_AUTH_SCHEME = "Bearer, InternalIdentity";
        public const string IDENTITY_AUTH_SCHEME = "InternalIdentity";

        #endregion
    }
}
