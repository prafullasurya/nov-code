﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.DomainService.Helper;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetLookupDataBaseQuery : IQuery<PagedResult<LookupData>>
    {
        public Paging PagingParameters { get; private set; }
        public FilterData FilterData { get; private set; }
        public string SearchText { get; set; }
        public bool IncludeInActive { get; set; }
        public string SearchColumn { get; set; } = string.Empty;
        public GetLookupDataBaseQuery(Paging pagingParameters, FilterData filterData,
            string searchText, bool includeInActive)
        {
            this.PagingParameters = pagingParameters;
            this.FilterData = filterData;
            this.SearchText = searchText;
            this.IncludeInActive = includeInActive;           
        }
        public GetLookupDataBaseQuery(Paging pagingParameters, FilterData filterData,
           string searchText, string searchColum,bool includeInActive)
        {
            this.PagingParameters = pagingParameters;
            this.FilterData = filterData;
            this.SearchText = searchText;
            this.IncludeInActive = includeInActive;
            this.SearchColumn = searchColum;
        }
    }
}
