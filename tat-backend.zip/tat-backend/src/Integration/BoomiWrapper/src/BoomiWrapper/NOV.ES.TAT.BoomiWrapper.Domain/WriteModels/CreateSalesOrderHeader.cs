﻿namespace NOV.ES.TAT.BoomiWrapper.Domain.WriteModels
{ 
    public class CreateSalesOrderHeader
    {
        public int BusinessUnit { get; set; }
        public string SalesOrderdocumentCompany { get; set; }
        public string CurrencyCodeTo { get; set; }

        public int CustomerPO { get; set; }
        public DateTime DateCancel { get; set; }
        public DateTime dateOrdered { get; set; }
        public DateTime dateRequested { get; set; }
        public int deliverToEntityId { get; set; }
        public string holdOrderCode { get; set; }

        public string orderedBy { get; set; }
        public string rateExchange { get; set; }
        public int shipToEntityId { get; set; }
        public int soldToEntityId { get; set; }
        public decimal adjustmentBasis { get; set; }
        public string headerComment { get; set; }
        public string alphaSpecData10 { get; set; }
        public string countryDescription { get; set; }

        public DateTime dateUpdated { get; set; }
        public string description11 { get; set; }
        public string descriptionSecondary { get; set; }
        public string eMSString { get; set; }
        public string everestEventPoint01 { get; set; }
        public string fieldTextDesctionXRef { get; set; }
        public string WellSite { get; set; }
        public string futureUserCFR10 { get; set; }
        public string futureUserCFR15 { get; set; }
        public string futureUserCFR16 { get; set; }
        public string fieldTicket { get; set; }
        public string rigName { get; set; }
        public string nameAlpha { get; set; }
        public string priorityProcessing { get; set; }
        public string serviceTypeDescription { get; set; }
        public int contractNumber { get; set; }
        public string wellType { get; set; }
        public int rigID { get; set; }
        public string deliveryInstruction2 { get; set; }
        public Guid wellID { get; set; }
        public int accountNumber { get; set; }
        public int afeNo { get; set; }
        public string attentionToDept { get; set; }
        public int contractNum { get; set; }
        public string customerLocation { get; set; }
        public DateTime serviceStartDate { get; set; }
        public int poNumber { get; set; }
        public string propertyCC { get; set; }
        public string requisitionerName { get; set; }
        public int ticketNumber { get; set; }
        public string adjustmentScheduleCode { get; set; }
        public int carrierEntityId { get; set; }
        public string creditCardAccountNumber { get; set; }
        public string customerPriceGroupCode { get; set; }
        public DateTime dateExpiration { get; set; }
        public string deliveryInstruction1 { get; set; }
        public string freightHandlingCode { get; set; }
        public string paymentInstrumentCode { get; set; }
        public string paymentTermsCode { get; set; }
        public string percentDiscountTrade { get; set; }
        public string printMessageCode { get; set; }
        public string taxExplanationCode { get; set; }
        public string taxRateAreaCode { get; set; }
        public string cCallPickShipPackUBE { get; set; }
        public string programmeId { get; set; }
        public string genericString1_DL01 { get; set; }
        public string genericString1_DL02 { get; set; }
        public string OrderTakenBy { get; set; }

        public int SalesOrderDocumentNumber { get; set; }

        public string SalesOrderdocumentOriginalTypeCode { get; set; }

        public string RouteCode { get; set; }

        public string stopCode { get; set; }

        public string SzWSSJobNumberReference { get; set; }

        public string ZoneNumber { get; set; }

        public string ShipToContactAlphaName { get; set; }

        public string UserReservedCode { get; set; }

        public DateTime UserReservedDate { get; set; }

        public string UserReservedAmount { get; set; }

        public string UserReservedReference { get; set; }

        public string ActionType { get; set; }

        public string ProcessingVersion { get; set; }

        public int JdeSalesOrderDocumentNumber { get; set; }

        public string SalesOrderdocumentTypeCode { get; set; }

        public string TargetERP { get; set; }

        public List<CreateSalesOrderHeaderSalesCommisionInfo> CreateSalesOrderHeaderSalesCommisionInfos { get; set; }

    }
}

