﻿namespace NOV.ES.TAT.Common.JwtTokenUtil
{
    public interface IJwtTokenService
    {
        Task<string?> GetClientCredentialTokenAsync(string issuerUrl,
            string clientId,
            string clientSecret,
            string scope,
            bool isSslEnabled = false
            );
    }
}
