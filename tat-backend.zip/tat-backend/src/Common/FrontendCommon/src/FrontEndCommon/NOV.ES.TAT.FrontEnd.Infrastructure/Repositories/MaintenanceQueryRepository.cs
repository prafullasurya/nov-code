﻿using Microsoft.EntityFrameworkCore;
using NOV.ES.Framework.Core.Data;
using NOV.ES.Framework.Core.Data.Repository;
using NOV.ES.TAT.FrontEnd.Domain;
using NOV.ES.TAT.FrontEnd.Infrastructure;
using System.Linq.Expressions;

namespace NOV.ES.TAT.FrontEnd.Infrastructure
{
    public class MaintenanceQueryRepository :
           GenericReadRepository<MaintenanceModel>,
           IMaintenanceQueryRepository
    {
        public readonly MaintenanceDBContext dbContext;
        public MaintenanceQueryRepository(MaintenanceDBContext context)
            : base(context)
        {
            dbContext = context;
        }
        public MaintenanceModel GetMaintenanceQueryRepository()
        {
            MaintenanceModel getMaintenanceQueryRepository = null;
            try
            {
                var detailFilter = PredicateBuilder.True<MaintenanceModel>();
                // getMaintenanceQueryRepository = dbContext.MaintenanceModels.AsQueryable().Where(detailFilter).OrderBy(x => x.Id).FirstOrDefault();
                //  getMaintenanceQueryRepository = dbContext.SystemDownMessageView.FirstOrDefault();
                //  var filter = PredicateBuilder.Create<MaintenanceModel>(x => x.IsActive);
                //  return getMaintenanceQueryRepository.Get(detailFilter, null, null).FirstOrDefault();
            }
            catch (Exception)
            {
                throw;
            }
            return getMaintenanceQueryRepository;
        }
    }
}