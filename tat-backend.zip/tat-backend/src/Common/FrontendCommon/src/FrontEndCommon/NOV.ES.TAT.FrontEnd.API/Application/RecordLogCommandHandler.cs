﻿using Newtonsoft.Json;
using NOV.ES.Framework.Core.CQRS.Commands;

namespace NOV.ES.TAT.FrontEnd.API.Application
{
    public class RecordLogCommandHandler :
        ICommandHandler<RecordLogCommand, bool>
    {
        private readonly ILogger<RecordLogCommandHandler> logger;

        public RecordLogCommandHandler(ILogger<RecordLogCommandHandler> logger)
        {
            this.logger = logger;
        }
        public Task<bool> Handle(RecordLogCommand request, CancellationToken cancellationToken)
        {
            if (request == null || request.ErrorModel == null)
                return Task.FromResult(false);

            var errorObject = JsonConvert.SerializeObject(request.ErrorModel);

            if (request.ErrorModel !=null && request.ErrorModel.Priority?.ToLower() == "error")
            {
                logger.LogError($"Exception from UI client: {errorObject}");
            }
            else
            {
                logger.LogInformation($"Information from UI client: {errorObject}");
            }

            return Task.FromResult(true);
        }
    }
}
