/*
 * This RemoteEntryModule is imported here to allow TS to find the Module during
 * compilation, allowing it to be included in the built bundle. This is required
 * for the Module Federation Plugin to expose the Module correctly.
 * */
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { NxWelcomeComponent } from './nx-welcome.component';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { Sample1Component } from './pages/sample1/sample1.component';
import { Sample2Component } from './pages/sample2/sample2.component';
import { Sample3Component } from './pages/sample3/sample3.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { PrimeNgModule} from '@tat/core';
import { ProductService } from './models/productservice';
import { ConfirmationService, MessageService } from 'primeng/api';
import { PagesListComponent } from './pages/pages-list/pages-list.component';

import { ProductServiceDemo } from '@tat/core/data-access-lookup';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { HttpClientInMemoryWebApiModule } from 'angular-in-memory-web-api';
import { DataService } from './models/data.services';
import { TranslateDemoComponent } from './components/translate-demo/translate-demo.component';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { ExampleAppFeatureProductModule } from '@tat/example-app/feature-product';
import { CustomerTransferSlipComponent } from './pages/customer-transfer-slip/customer-transfer-slip.component';
import { CustomerSalesInfoComponent } from './pages/customer-sales-info/customer-sales-info.component';
import { AddTatItemComponent } from './pages/add-tat-item/add-tat-item.component';
import { RigWellSiteInfoComponent } from './pages/rig-well-site-info/rig-well-site-info.component';
import { DatabindingExampleComponent } from './components/databinding-example/databinding-example.component';
import { ShippingInfoComponent } from './pages/shipping-info/shipping-info.component';
import { EditCustomerTransferInfoComponent } from './pages/edit-customer-transfer-info/edit-customer-transfer-info.component';
import { CtsRigWellSiteInfoComponent } from './pages/cts-rig-well-site-info/cts-rig-well-site-info.component';
import { CtsShippingInfoComponent } from './pages/cts-shipping-info/cts-shipping-info.component';
import { CtsTatItemComponent } from './pages/cts-tat-item/cts-tat-item.component';
import { CtsLineItemDetailsComponent } from './pages/cts-line-item-details/cts-line-item-details.component';

import { FtsListingComponent } from './pages/fts-listing/fts-listing.component';
import { FtsMiscellaneousComponent } from './pages/fts-miscellaneous/fts-miscellaneous.component';
import { FinancialTransferCompletedComponent } from './pages/financial-transfer-completed/financial-transfer-completed.component';
import { FtsAddTatItemsComponent } from './pages/fts-add-tat-items/fts-add-tat-items.component';

import { nftListingComponent } from './pages/nft-listing/nft-listing.component';
import { nftHeaderDetailsComponent } from './pages/nft-header-details/nft-header-details.component';
import { nftTatItemComponent } from './pages/nft-tat-item/nft-tat-item.component';
import { nftLineItemDetailsComponent } from './pages/nft-line-item-details/nft-line-item-details.component';
import { nftEditAssemblyComponent } from './pages/nft-edit-assembly/nft-edit-assembly.component';
import { nftEditAComponentComponent } from './pages/nft-edit-component/nft-edit-component.component';
import { nftCompletedComponent } from './pages/nft-completed/nft-completed.component';
import { ftsFromToolDetailsComponent } from './pages/fts-from-tool-details/fts-from-tool-details.component';
import { phase3DialogPopupComponent } from './pages/phase3-dialog-popup/phase3-dialog-popup.component';
import { ItemsEventsComponent } from './pages/phase3-item/items-events/items-events.component';
import { LocationChangeListingComponent } from './pages/location-change-listing/location-change-listing.component';
import { LocationChangeComponent } from './pages/location-change/location-change.component';
import { LocationChangeCompletedComponent } from './pages/location-change-completed/location-change-completed.component';
import { IntransitAcceptanceListingComponent } from './pages/intransit-acceptance-listing/intransit-acceptance-listing.component';
import { AddIntransitAcceptanceComponent } from './pages/add-intransit-acceptance/add-intransit-acceptance.component';
import { AddIntransitSelectItemsComponent } from './pages/add-intransit-select-items/add-intransit-select-items.component';
import { TabMenuModule } from 'primeng/tabmenu';
import { ItemsMainScreenEditComponent } from './pages/phase3-item/items-main-screen-edit/items-main-screen-edit.component';
import { ItemsBasicComponent } from './pages/phase3-item/items-basic/items-basic.component';
import { ItemsDescriptionComponent } from './pages/phase3-item/items-description-comments/items-description-comments.component';
import { ItemsAttributesEditComponent } from './pages/phase3-item/items-attributes-edit/tems-attributes-edit.component';
import { ItemsAttributesNonEditComponent } from './pages/phase3-item/items-attributes-non-edit/items-attributes-non-edit.component';
import { ItemsMfgInfoComponent } from './pages/phase3-item/items-mfg-info/items-mfg-info.component';
import { ItemsTempImportInfoComponent } from './pages/phase3-item/items-temp-import-info/items-temp-import-info.component';
import { IntransitItemComponent } from './pages/intransit-item/intransit-item.component';
import { ItemsMainScreenComponent } from './pages/phase3-item/items-main-screen/items-main-screen.component';
import { ItemsHeaderComponent } from './pages/phase3-item/items-header/tems-header.component';
import { ItemsServiceInfoComponent } from './pages/phase3-item/items-service-info/items-service-info.component';
import { ItemsFinanceComponent } from './pages/phase3-item/items-finance/items-finance.component';
import { IntransitItemsCompletedComponent } from './pages/intransit-items-completed/intransit-items-completed.component';
import { UnderMaintenanceComponent } from './pages/under-maintenance/under-maintenance.component';
import { UsageListingPageComponent } from './pages/phase3-usage/usage-listing-page/usage-listing-page.component';
import { UsageListingSearchComponent } from './pages/phase3-usage/usage-listing-search/usage-listing-search.component';
import { UsageListingFilterChipsComponent } from './pages/phase3-usage/usage-listing-filter-chips/usage-listing-filter-chips.component';
import { UsageListingAdvanceSearchComponent } from './pages/phase3-usage/usage-listing-advance-search/usage-listing-advance-search.component';
import { UsageListComponent } from './pages/phase3-usage/usage-list/usage-list.component';
import { UsageHeaderComponent } from './pages/phase3-usage/usage-header/usage-header.component';
import { UsageBasicScreenComponent } from './pages/phase3-usage/usage-basic-screen/usage-basic-screen.component';
import { UsageItemScreenComponent } from './pages/phase3-usage/usage-item-screen/usage-item-screen.component';
import { UsageBillingScreenComponent } from './pages/phase3-usage/usage-billing-screen/usage-billing-screen.component';
import { UsageServiceScreenComponent } from './pages/phase3-usage/usage-service-screen/usage-service-screen.component';
import { UsageCommentScreenComponent } from './pages/phase3-usage/usage-comment-screen/usage-comment-screen.component';
import { UsageProductAnalysisComponent } from './pages/phase3-usage/usage-product-analysis/usage-product-analysis.component';
import { UsageWellsiteOldComponent } from './pages/phase3-usage/usage-wellsite-old/usage-wellsite-old.component';
import { UsageWellsiteComponent } from './pages/phase3-usage/usage-wellsite/usage-wellsite.component';
import { AddUsageComponent } from './pages/phase3-usage/add-usage/add-usage.component';
import { AddAttachmentComponent } from './pages/add-attachment/add-attachment/add-attachment.component';
import { ItemListingPageComponent } from './pages/phase3-item/item-listing-page/item-listing-page.component';
import { ItemReturnListingPageComponent } from './pages/item-return/item-return-listing-page/item-return-listing-page.component';
import { ItemReturnListingSearchComponent } from './pages/item-return/item-return-listing-search/item-return-listing-search.component';
import { ItemReturnListComponent } from './pages/item-return/item-return-list/item-return-list.component';
import { ItemReturnFilterChipsComponent } from './pages/item-return/item-return-filter-chips/item-return-filter-chips.component';
import { ItemReturnInfoComponent } from './pages/item-return/item-return-info/item-return-info.component';
import { CustomerReturnInfoComponent } from './pages/item-return/customer-return-info/customer-return-info.component';
import { CustomerReturLineItemDetailsComponent } from './pages/item-return/customer-return-line-item-details/customer-return-line-item-details.component';
import { CustomerReturnSlipHeaderComponent } from './pages/item-return/customer-return-slip-header/customer-return-slip-header.component';
import { CustomerReturnTatItemComponent } from './pages/item-return/customer-return-add-tat-item/customer-return-add-tat-item.component';
import { CustomerReturnAddInventoryComponent } from './pages/item-return/customer-return-add-inventory/customer-return-add-inventory.component';
import { CustomerReturnMiscDetailsComponent } from './pages/item-return/customer-return-misc-details/customer-return-misc-details.component';
import { CustomerReturnInventoryItemComponent } from './pages/item-return/customer-return-inventory-item/customer-return-inventory-item.component';
import { CustomerReturnMiscInfoComponent } from './pages/item-return/customer-return-misc-info-open/customer-return-misc-info-open.component';
import { CustomerReturnAddToolReturnSlipComponent } from './pages/item-return/customer-return-add-tool-return-slip/customer-return-add-tool-return-slip.component';
import { ReturnSlipSingleItemAssemblyComponent } from './pages/item-return/return-slip-single-item-assembly/return-slip-single-item-assembly.component';
import { ReturnSlipSingleItemComponent } from './pages/item-return/return-slip-single-item-component/return-slip-single-item-component.component';
import { CustomerReturnInfoCompletedComponent } from './pages/item-return/customer-return-info-completed/customer-return-info-completed.component';
import { CustomerReturLineItemDetailsCompletedComponent } from './pages/item-return/customer-return-line-item-details-completed/customer-return-line-item-details-completed.component';
import { ReturnSlipSingleItemAssemblyCompletedComponent } from './pages/item-return/return-slip-single-item-assembly-completed/return-slip-single-item-assembly-completed.component';
import { ReturnSlipSingleItemCompletedComponent } from './pages/item-return/return-slip-single-item-component-completed/return-slip-single-item-component-completed.component';
import { CustomerReturnMiscInfoCompletedComponent } from './pages/item-return/customer-return-misc-info-completed/customer-return-misc-info-completed.component';
import { CustomerReturnInventoryItemCompletedComponent } from './pages/item-return/customer-return-inventory-item-completed/customer-return-inventory-item-completed.component';
import { ActiveUsageAttachComponent } from './pages/attach-detach-active-usage/active-usage-attach/active-usage-attach.component';
import { ActiveUsageDetachComponent } from './pages/attach-detach-active-usage/active-usage-detach/active-usage-detach.component';
import { AdminHeaderComponent } from './pages/admin-screen/admin-header/admin-header.component';
import { LandingScreenComponent } from './pages/admin-screen/landing-screen/landing-screen.component';
import { AdminEventDetailsComponent } from './pages/admin-screen/admin-event-details/admin-event-details.component';
export function HttpLoaderFactory(http: HttpClient):TranslateHttpLoader {
  return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}


@NgModule({
  declarations: [AppComponent, NxWelcomeComponent,Sample1Component,Sample2Component,
    Sample3Component,
    PagesListComponent,
    TranslateDemoComponent,
    CustomerTransferSlipComponent,
    CustomerSalesInfoComponent,
    AddTatItemComponent,
    RigWellSiteInfoComponent,
    DatabindingExampleComponent,
    ShippingInfoComponent,
    EditCustomerTransferInfoComponent,
    CtsRigWellSiteInfoComponent,
    CtsShippingInfoComponent,
    CtsTatItemComponent,
    CtsLineItemDetailsComponent,
    FtsListingComponent,
    FtsMiscellaneousComponent,
    FinancialTransferCompletedComponent,
    FtsAddTatItemsComponent,
    nftListingComponent,
    nftHeaderDetailsComponent,
    nftTatItemComponent,
    nftLineItemDetailsComponent,
    nftEditAssemblyComponent,
    nftEditAComponentComponent,
    nftCompletedComponent,
    ftsFromToolDetailsComponent,
    phase3DialogPopupComponent,
    ItemListingPageComponent,
    ItemsEventsComponent,
    LocationChangeListingComponent,
    LocationChangeComponent,
    LocationChangeCompletedComponent,
    // IntransitScceptanceListingComponent,
    AddIntransitAcceptanceComponent,
    IntransitItemsCompletedComponent,
    ItemsMainScreenComponent,
    ItemsMainScreenEditComponent,
    ItemsBasicComponent,
    ItemsDescriptionComponent,
    ItemsAttributesEditComponent,
    ItemsAttributesNonEditComponent,
    ItemsMfgInfoComponent,
    ItemsTempImportInfoComponent,
    ItemsHeaderComponent,
    IntransitAcceptanceListingComponent,
    AddIntransitAcceptanceComponent,
    AddIntransitSelectItemsComponent,
    IntransitItemComponent,
    ItemsServiceInfoComponent,
    ItemsFinanceComponent,
    UnderMaintenanceComponent,
    UsageListingPageComponent,
    UsageListingSearchComponent,
    UsageListingFilterChipsComponent,
    UsageListingAdvanceSearchComponent,
    UsageListComponent,
    UsageHeaderComponent,
    UsageBasicScreenComponent,
    UsageItemScreenComponent,
    UsageBillingScreenComponent,
    UsageServiceScreenComponent,
    UsageCommentScreenComponent,
    UsageProductAnalysisComponent,
    UsageWellsiteOldComponent,
    UsageWellsiteComponent,
    AddUsageComponent,
    AddAttachmentComponent,
    ItemReturnListingPageComponent,
    ItemReturnListingSearchComponent,
    ItemReturnListComponent,
    ItemReturnFilterChipsComponent,
    ItemReturnInfoComponent,
    CustomerReturnInfoComponent,
    CustomerReturLineItemDetailsComponent,
    CustomerReturnSlipHeaderComponent,
    CustomerReturnTatItemComponent,
    CustomerReturnAddInventoryComponent,
    CustomerReturnMiscDetailsComponent,
    CustomerReturnInventoryItemComponent,
    CustomerReturnMiscInfoComponent,
    CustomerReturnAddToolReturnSlipComponent,
    ReturnSlipSingleItemAssemblyComponent,
    ReturnSlipSingleItemComponent,
    CustomerReturnInfoCompletedComponent,
    CustomerReturLineItemDetailsCompletedComponent,
    ReturnSlipSingleItemAssemblyCompletedComponent,
    ReturnSlipSingleItemCompletedComponent,
    CustomerReturnMiscInfoCompletedComponent,
    CustomerReturnInventoryItemCompletedComponent,
    ActiveUsageAttachComponent,
    ActiveUsageDetachComponent,
    AdminHeaderComponent,
    LandingScreenComponent,
    AdminEventDetailsComponent



    
],
  imports: [
    PrimeNgModule,
    FormsModule,
    HttpClientModule,
    ExampleAppFeatureProductModule,
    TabMenuModule,
    TranslateModule.forRoot({
      defaultLanguage: 'en-US',
      loader: {
          provide: TranslateLoader,
          useFactory: HttpLoaderFactory,
          deps: [HttpClient]
      }
  }),
    HttpClientInMemoryWebApiModule.forRoot(DataService),
    BrowserAnimationsModule,
    RouterModule.forRoot([
      {
        path: '',
        loadChildren: () => import('./remote-entry/entry.module').then((m) => m.RemoteEntryModule),
      },

    ], { initialNavigation: 'enabledBlocking' }),
  ],
  providers: [ProductService, MessageService, ConfirmationService,ProductServiceDemo],
  bootstrap: [AppComponent],
})
export class AppModule {}
