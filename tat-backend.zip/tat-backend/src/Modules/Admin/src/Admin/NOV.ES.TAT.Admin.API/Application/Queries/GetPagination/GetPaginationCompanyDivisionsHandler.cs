﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.API.Helper;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetPaginationCompanyDivisionsHandler
           : IQueryHandler<GetPaginationCompanyDivisionsQuery, PagedResult<CompanyDivisionDto>>
    {
        private readonly IMapper mapper;
        private readonly ICompanyDivisionService companyDivisionService;
        private readonly IHttpContextAccessor httpContextAccessor;

        public GetPaginationCompanyDivisionsHandler(
            IMapper mapper
            ,ICompanyDivisionService companyDivisionService
            , IHttpContextAccessor httpContextAccessor)
        {
            this.mapper = mapper;
            this.companyDivisionService = companyDivisionService;
            this.httpContextAccessor = httpContextAccessor;
        }

        public Task<PagedResult<CompanyDivisionDto>> Handle(GetPaginationCompanyDivisionsQuery request,
          CancellationToken cancellationToken)
        {
            var companyDivisions = companyDivisionService.GetCompanyDivisions(request.PagingParameters);
            var result = mapper.Map<PagedResult<CompanyDivision>, PagedResult<CompanyDivisionDto>>(companyDivisions);
            PagingHelper.AddPagingMetadata<CompanyDivisionDto>(result, httpContextAccessor);
            return Task.FromResult(result);
        }
    }
}