import { Component, OnInit } from '@angular/core';
import { ConfirmationService, MessageService } from 'primeng/api';


@Component({
  selector: 'usage-billing-screen',
  templateUrl: './usage-billing-screen.component.html',
  styleUrls: ['./usage-billing-screen.component.scss']
})
export class UsageBillingScreenComponent {
  
}
