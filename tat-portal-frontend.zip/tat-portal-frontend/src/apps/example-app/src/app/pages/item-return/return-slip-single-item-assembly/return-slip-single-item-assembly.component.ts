import { Component} from '@angular/core';

interface City {
  name: string,
  code: string
}
@Component({
  selector: 'return-slip-single-item-assembly',
  templateUrl: './return-slip-single-item-assembly.component.html',
  styleUrls: ['./return-slip-single-item-assembly.component.scss']
})
export class ReturnSlipSingleItemAssemblyComponent {
  
  


}
