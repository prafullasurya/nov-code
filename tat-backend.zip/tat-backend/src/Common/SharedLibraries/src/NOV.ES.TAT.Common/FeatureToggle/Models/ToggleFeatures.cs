﻿namespace NOV.ES.TAT.Common.FeatureToggle.Models
{
    public class ToggleFeatures
    {
        public List<ToggleFeature> toggleFeatures_ { get; set; }
    }
}
