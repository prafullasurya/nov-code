﻿using NOV.ES.Framework.Core.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace NOV.ES.TAT.BoomiWrapper.Domain.ReadModel
{
    public class FieldTransferSlipDetail : BaseEntity<int>
    {
        public int? FieldTransferSlipId { get; set; }
        public string BottomConnJointTypeDesc { get; set; }
        public int? BottomConnJointTypeId { get; set; }
        public string BottomConnTypeDesc { get; set; }
        public int? BottomConnTypeId { get; set; }
        public string Comments { get; set; }
        public string Currency { get; set; }
        public int? CustomStatusId { get; set; }
        public string CustomStatusName { get; set; }
        public string ErpDocNumber { get; set; }
        public string ErpDocType { get; set; }
        public int ErpDocTypeId { get; set; }
        public string ErpLocation { get; set; }
        public string ErpLocationZone { get; set; }
        public string ErpLotStatus { get; set; }
        public string ErrorMessage { get; set; }
        public string FieldTicket { get; set; }
        public string FinancialCcCode { get; set; }
        public int FinancialBuId { get; set; }
        public string FinancialCcName { get; set; }
        public string FinancialCompanyCode { get; set; }
        public int? FinancialCompanyId { get; set; }
        public string FinancialCompanyName { get; set; }
        public int? IntendedUseId { get; set; }
        public string IntendedUse { get; set; }
        public int? FromUsageId { get; set; }
        public string FromUsageNumber { get; set; }
        public string HTS { get; set; }        
        public Int16? IsCompleted { get; set; }
        public bool? IsDisplayOnPrint { get; set; }
        public bool? IsUsedOnFromUsage { get; set; }
        public string ItemDescription { get; set; }
        public int? ItemId { get; set; }
        public string ItemName { get; set; }
        public string ItemSerialNumber { get; set; }
        public string ItemType { get; set; }
        public decimal? ItemValue { get; set; }
        public bool? LastActionCompleted { get; set; }
        public int? LastErpSoftCommitmentId { get; set; }
        public string LeasingType { get; set; }
        public int? LeasingTypeId { get; set; }
        public string LineType { get; set; }
        public string Lobe { get; set; }
        public int? LobeId { get; set; }
        public string NewPartDescription { get; set; }
        public string NewPartNumber { get; set; }
        public string OscilaltingValvePlateSize { get; set; }
        public int? OscilaltingValvePlateSizeId { get; set; }
        public string PartDescription { get; set; }
        public string PartDescription2 { get; set; }
        public string PartNumber { get; set; }
        public string PartType { get; set; }
        public decimal? QuantityMiscReceipt { get; set; }
        public decimal? QuantityShipped { get; set; }
        public string RotorHeatNumber { get; set; }
        public double? RotorOD { get; set; }
        public int SequenceNumber { get; set; }
        public string Series { get; set; }
        public int? SizeId { get; set; }
        public string SizeValue { get; set; }
        public string Stage { get; set; }
        public int? StageId { get; set; }
        public string StationaryValvePlateSize { get; set; }
        public int? StationaryValvePlateSizeId { get; set; }
        public string StatorHeatNumber { get; set; }
        public double StatorID { get; set; }
        public string SubItemType { get; set; }
        public string TopConnJointTypeDesc { get; set; }
        public int? TopConnJointTypeId { get; set; }
        public string TopConnTypeDesc { get; set; }
        public int? TopConnTypeId { get; set; }
        public int? ToUsageId { get; set; }
        public string ToUsageNumber { get; set; }
        public string UOM { get; set; }
        public decimal Weight { get; set; }
        public string SVA { get; set; }
        public string OVA { get; set; }
        public string RotorComponentId { get; set; }
        public string StatorComponentId { get; set; }
        public string BladeGeometry { get; set; }
        public string BladeSize { get; set; }
        public string BitType { get; set; }
        public int? ItemClassId { get; set; }
        public virtual FieldTransferSlip FieldTransferSlip { get; set; }
    }
}
