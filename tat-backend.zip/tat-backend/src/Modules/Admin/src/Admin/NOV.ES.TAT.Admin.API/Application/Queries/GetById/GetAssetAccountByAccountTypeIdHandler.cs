﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetAssetAccountByAccountTypeIdHandler : IQueryHandler<GetAssetAccountByAccountTypeIdQuery, IEnumerable<AssetAccountDto>>
    {
        
        private readonly IMapper mapper;
        private readonly IAssetAccountService assetAccountService;

        public GetAssetAccountByAccountTypeIdHandler(
            IMapper mapper,
            IAssetAccountService assetAccountService)
        {           
            this.mapper = mapper;
            this.assetAccountService = assetAccountService;
        }

        public Task<IEnumerable<AssetAccountDto>> Handle(GetAssetAccountByAccountTypeIdQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var assetAccounts = assetAccountService.GetAssetAccountsByAccountTypeId(request.AccountTypeId);
            var result = mapper.Map< IEnumerable<AssetAccount>, IEnumerable<AssetAccountDto>>(assetAccounts);
            return Task.FromResult(result);
        }
        private static bool IsValidRequest(GetAssetAccountByAccountTypeIdQuery request)
        {
            return (request != null && request.AccountTypeId != 0);
        }
    }
}