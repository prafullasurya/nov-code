﻿using AutoMapper;
using Newtonsoft.Json;
using NOV.ES.Framework.Core.Messaging.IntegrationEvents;
using NOV.ES.Framework.Core.Sagas;
using NOV.ES.TAT.BoomiWrapper.API.Application.IntegrationEvents.PublishEvents;
using NOV.ES.TAT.BoomiWrapper.Domain;
using NOV.ES.TAT.BoomiWrapper.Domain.WriteModels;
using NOV.ES.TAT.BoomiWrapper.DomainService;
using NOV.ES.TAT.BoomiWrapper.DomainService.RequestModel;
using NOV.ES.TAT.BoomiWrapper.DomainService.ResponseModel;

namespace NOV.ES.TAT.BoomiWrapper.API.Application.IntegrationEvents.SubscribedEvents
{
    public class GenerateInventoryTransferHandler
        : IIntegrationEventHandler<GenerateInventoryTransfer>
    {
        private readonly ILogger<GenerateInventoryTransferHandler> logger;
        private readonly IBoomiWrapperService boomiWrapperService;
        private readonly IIntegrationEventBus integrationEventBus;
        private readonly IMapper mapper;

        public GenerateInventoryTransferHandler(
            ILogger<GenerateInventoryTransferHandler> logger,
            IBoomiWrapperService boomiWrapperService,
            IIntegrationEventBus integrationEventBus,
            IMapper mapper)
        {
            this.logger = logger;
            this.boomiWrapperService = boomiWrapperService;
            this.integrationEventBus = integrationEventBus;
            this.mapper = mapper;
        }

        public Task Handle(GenerateInventoryTransfer @event)
        {
            logger.LogInformation("----- Consuming Event: Generate Inventory Transfer Integration Event");
            logger.LogInformation("----- CorelationId is {id}", @event.CorelationId);
            logger.LogInformation("----- Event Detail is {info}", @event.JsonStringData);

            BoomiRequestResponse boomiRequestResponse;
            //1.Generate request for boomi 
            InventoryTransferRequest inventoryTransferRequest = GenerateRequestPayload(@event.CorelationId, @event.ActionBy, @event.JsonStringData, out boomiRequestResponse);

            //2.Record request in database
            boomiWrapperService.RecordRequestPayload(boomiRequestResponse);

            //3. Boomi CallInventoryTransfer
            InventoryTransferResponse inventoryTransferResponse = boomiWrapperService.InventoryTransfer(inventoryTransferRequest).Result;

            //4. Record Response
            boomiRequestResponse.Status = BoomiResponseType.Success.ToString();
            boomiRequestResponse.ResponseStatus = inventoryTransferResponse.Success;
            boomiRequestResponse.RequestDateTime = DateTime.UtcNow;
            boomiRequestResponse.ResponseBody = JsonConvert.SerializeObject(inventoryTransferResponse);
            if (inventoryTransferResponse.Errors != null && inventoryTransferResponse.Errors.Any())
            {
                boomiRequestResponse.ErrorMessage = JsonConvert.SerializeObject(inventoryTransferResponse.Errors);
                boomiRequestResponse.Status = BoomiResponseType.Failed.ToString();
            }

            boomiWrapperService.RecordResponse(boomiRequestResponse);

            //5.Generate response for publish event
            var result = GenerateResponseForPublishEvent(inventoryTransferResponse);

            //6.publish event
            GeneratedInventoryTransfer success =
            new(
                boomiRequestResponse.RequestId.ToString(),
                @event.CorelationId,
                JsonConvert.SerializeObject(result),
                DateTime.UtcNow,
                SagaEventExecutionResult.Success,
                @event.ActionBy
                );

            logger.LogInformation("Publish Generated Inventory Transfer event  - GeneratedInventoryTransfer.");
            integrationEventBus.Publish(success);

            return Task.CompletedTask;

        }

        private InventoryTransferRequest GenerateRequestPayload(Guid corelationId, string actionBy, string jsonStringData, out BoomiRequestResponse boomiRequestResponse)
        {
            var generateInventoryTransferRequest = JsonConvert.DeserializeObject<GenerateInventoryTransferRequest>(jsonStringData);

            var inventoryTransferRequest = mapper.Map<GenerateInventoryTransferRequest, InventoryTransferRequest>(generateInventoryTransferRequest);

            boomiRequestResponse = new BoomiRequestResponse()
            {
                RequestId = generateInventoryTransferRequest.RequestId,
                CorelationId = corelationId,
                EventId = generateInventoryTransferRequest.EventId,
                KeyName = generateInventoryTransferRequest.KeyName,
                KeyValue = generateInventoryTransferRequest.KeyValue,
                RequestDateTime = DateTime.UtcNow,
                RequestStatus = BoomiResponseType.Success.ToString(),
                RequestBody = JsonConvert.SerializeObject(inventoryTransferRequest),
                RequestURL = "inInventory/InventoryTransfer",
                RequestMethod = "InventoryTransfer",
                HttpVerb = "Post",
                ActionBy = actionBy
            };

            return inventoryTransferRequest;
        }

        private static int GenerateResponseForPublishEvent(InventoryTransferResponse inventoryTransferResponse)
        {
            return Convert.ToInt32(inventoryTransferResponse.JDEDocNumber);
        }
    }
}

