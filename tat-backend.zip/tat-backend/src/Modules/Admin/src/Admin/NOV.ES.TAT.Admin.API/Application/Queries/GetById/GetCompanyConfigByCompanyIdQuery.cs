﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetCompanyConfigByCompanyIdQuery : IQuery<CompanyConfigDto>
    {
        public int CompanyId { get; private set; }

        public GetCompanyConfigByCompanyIdQuery(int companyId)
        {
            this.CompanyId = companyId;
        }
    }
}