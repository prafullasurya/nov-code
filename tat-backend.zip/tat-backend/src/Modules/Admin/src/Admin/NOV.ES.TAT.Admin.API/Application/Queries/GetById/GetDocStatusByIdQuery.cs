﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;


namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetDocStatusByIdQuery : IQuery<DocStatusDto>
    {
        public int DocStatusId { get; private set; }
        public GetDocStatusByIdQuery(int divisionId)
        {
            this.DocStatusId = divisionId;
        }
    }
}
