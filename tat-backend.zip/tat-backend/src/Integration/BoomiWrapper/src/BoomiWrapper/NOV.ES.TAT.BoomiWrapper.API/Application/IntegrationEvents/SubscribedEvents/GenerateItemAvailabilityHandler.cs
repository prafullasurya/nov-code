﻿using Newtonsoft.Json;
using NOV.ES.Framework.Core.Messaging.IntegrationEvents;
using NOV.ES.Framework.Core.Sagas;
using NOV.ES.TAT.BoomiWrapper.API.Application.IntegrationEvents.PublishEvents;
using NOV.ES.TAT.BoomiWrapper.Domain;
using NOV.ES.TAT.BoomiWrapper.Domain.WriteModels;
using NOV.ES.TAT.BoomiWrapper.DomainService;
using NOV.ES.TAT.BoomiWrapper.DomainService.RequestModel;
using NOV.ES.TAT.BoomiWrapper.DomainService.ResponseModel;
using AutoMapper;

namespace NOV.ES.TAT.BoomiWrapper.API.Application.IntegrationEvents.SubscribedEvents
{
    public class GenerateItemAvailabilityHandler
        : IIntegrationEventHandler<GenerateItemAvailability>
    {
        private ILogger<GenerateItemAvailabilityHandler> logger;
        private readonly IBoomiWrapperService boomiWrapperService;
        private readonly IIntegrationEventBus integrationEventBus;
        private readonly IMapper mapper;

        public GenerateItemAvailabilityHandler(
            ILogger<GenerateItemAvailabilityHandler> logger,
            IBoomiWrapperService boomiWrapperService,
            IIntegrationEventBus integrationEventBus,
            IMapper mapper)
        {
            this.logger = logger;
            this.boomiWrapperService = boomiWrapperService;
            this.integrationEventBus = integrationEventBus;
            this.mapper = mapper;
        }

        public Task Handle(GenerateItemAvailability @event)
        {
            logger.LogInformation("----- Consuming Event: Generate Item Availability Integration Event");
            logger.LogInformation("----- CorelationId is {id}", @event.CorelationId);
            logger.LogInformation("----- Event Detail is {info}", @event.JsonStringData);

            BoomiRequestResponse boomiRequestResponse;
            //1.Generate request for boomi 
            ItemAvailabilityRequest itemAvailabilityRequest = GenerateRequestPayload(@event.CorelationId, @event.ActionBy, @event.JsonStringData, out boomiRequestResponse);

            //2.Record request in database
            boomiWrapperService.RecordRequestPayload(boomiRequestResponse);

            //3. Boomi Call
            ItemAvailabilityResponse itemAvailabilityResponse = boomiWrapperService.GetItemAvailability(itemAvailabilityRequest).Result;

            //4. Record Response
            boomiRequestResponse.Status = BoomiResponseType.Success.ToString();
            boomiRequestResponse.ResponseStatus = itemAvailabilityResponse.Success;
            boomiRequestResponse.RequestDateTime = DateTime.UtcNow;
            boomiRequestResponse.ResponseBody = JsonConvert.SerializeObject(itemAvailabilityResponse);
            if (itemAvailabilityResponse.Errors != null && itemAvailabilityResponse.Errors.Any())
            {
                boomiRequestResponse.ErrorMessage = JsonConvert.SerializeObject(itemAvailabilityResponse.Errors);
                boomiRequestResponse.Status = BoomiResponseType.Failed.ToString();
            }

            boomiWrapperService.RecordResponse(boomiRequestResponse);

            //5.Generate response for publish event
            var result = GenerateResponseForPublishEvent(itemAvailabilityResponse);

            //6.publish event
            GeneratedItemAvailability success =
            new(
                boomiRequestResponse.RequestId.ToString(),
                @event.CorelationId,
                JsonConvert.SerializeObject(result),
                DateTime.UtcNow,
                SagaEventExecutionResult.Success,
                @event.ActionBy
                );

            logger.LogInformation("Publish Generated Item Availability event  - GeneratedItemAvailability.");
            integrationEventBus.Publish(success);

            return Task.CompletedTask;

        }

        private ItemAvailabilityRequest GenerateRequestPayload(Guid corelationId, string actionBy, string jsonStringData, out BoomiRequestResponse boomiRequestResponse)
        {
            var generateItemAvailabilityRequest = JsonConvert.DeserializeObject<GenerateItemAvailabilityRequest>(jsonStringData);

            var itemAvailabilityRequest = mapper.Map<GenerateItemAvailabilityRequest, ItemAvailabilityRequest>(generateItemAvailabilityRequest);
            boomiRequestResponse = new BoomiRequestResponse()
            {
                RequestId = generateItemAvailabilityRequest.RequestId,
                CorelationId = corelationId,
                EventId = generateItemAvailabilityRequest.EventId,
                KeyName = generateItemAvailabilityRequest.KeyName,
                KeyValue = generateItemAvailabilityRequest.KeyValue,
                RequestDateTime = DateTime.UtcNow,
                RequestStatus = BoomiResponseType.Success.ToString(),
                RequestBody = JsonConvert.SerializeObject(itemAvailabilityRequest),
                RequestURL = "inItem/ItemAvailability",
                RequestMethod = "ItemAvailability",
                HttpVerb = "Post",
                ActionBy = actionBy
            };

            return itemAvailabilityRequest;
        }

        private static int GenerateResponseForPublishEvent(ItemAvailabilityResponse itemAvailabilityResponse)
        {
            return Convert.ToInt32(itemAvailabilityResponse.Success);
        }
    }
}

