import { Component} from '@angular/core';

interface City {
  name: string,
  code: string
}
@Component({
  selector: 'customer-return-misc-info-completed',
  templateUrl: './customer-return-misc-info-completed.component.html',
  styleUrls: ['./customer-return-misc-info-completed.component.scss']
})
export class CustomerReturnMiscInfoCompletedComponent {
  
  


}
