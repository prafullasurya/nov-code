import { Component, OnInit } from '@angular/core';
import { ConfirmationService, MessageService } from 'primeng/api';
import { Product } from '../../../models/product';
import { ProductService } from '../../../models/productservice';


interface City {
  name: string,
  code: string
}
@Component({
  selector: 'items-service-info',
  templateUrl: './items-service-info.component.html',
  styleUrls: ['./items-service-info.component.scss']
})
export class ItemsServiceInfoComponent {
  displayAttachItem: boolean;
  displayAttachItemConflict: boolean;
  displayAttachItemSingle: boolean;
  displayDetachItem: boolean;
  displaySeriveCostList: boolean;

  showAttachItem() {
    this.displayAttachItem = true;
  }
  showConfilictItem() {
    this.displayAttachItemConflict = true;
    this.displayAttachItem = false;
  }
  showAttachItemSingle() {
    this.displayAttachItemSingle = true;
  }
  showDetachItemSingle() {
    this.displayDetachItem = true;
  }
  showServiceCostList() {
    this.displaySeriveCostList = true;
  }
  // activeIndex1: number = 0;

  // activeIndex2: number = 0;

  // scrollableTabs: any[] = Array.from({ length: 50 }, (_, i) => ({ title: `Tab ${i + 1}`, content: `Tab ${i + 1} Content` }));

}
