import { ComponentFixture, TestBed } from '@angular/core/testing';

import { nftLineItemDetailsComponent } from './nft-line-item-details.component';

describe('nftLineItemDetailsComponent', () => {
  let component: nftLineItemDetailsComponent;
  let fixture: ComponentFixture<nftLineItemDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ nftLineItemDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(nftLineItemDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
