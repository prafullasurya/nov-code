﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetUserPreferenceByModuleQuery : IQuery<IEnumerable<UserPreferenceDto>>
    {
        public int ModuleId { get; private set; }

        public GetUserPreferenceByModuleQuery(int moduleId)
        {
            this.ModuleId = moduleId;
        }
    }
}