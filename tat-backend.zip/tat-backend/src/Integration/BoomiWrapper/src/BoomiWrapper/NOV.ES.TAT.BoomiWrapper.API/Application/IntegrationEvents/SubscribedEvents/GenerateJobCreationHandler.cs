﻿using AutoMapper;
using Newtonsoft.Json;
using NOV.ES.Framework.Core.Messaging.IntegrationEvents;
using NOV.ES.Framework.Core.Sagas;
using NOV.ES.TAT.BoomiWrapper.API.Application.IntegrationEvents.PublishEvents;
using NOV.ES.TAT.BoomiWrapper.Domain;
using NOV.ES.TAT.BoomiWrapper.Domain.WriteModels;
using NOV.ES.TAT.BoomiWrapper.DomainService;
using NOV.ES.TAT.BoomiWrapper.DomainService.RequestModel;
using NOV.ES.TAT.BoomiWrapper.DomainService.ResponseModel;

namespace NOV.ES.TAT.BoomiWrapper.API.Application.IntegrationEvents.SubscribedEvents
{
    public class GenerateJobCreationHandler
        : IIntegrationEventHandler<GenerateJobCreation>
    {
        private readonly ILogger<GenerateJobCreationHandler> logger;
        private readonly IBoomiWrapperService boomiWrapperService;
        private readonly IIntegrationEventBus integrationEventBus;
        private readonly IMapper mapper;

        public GenerateJobCreationHandler(
            ILogger<GenerateJobCreationHandler> logger,
            IBoomiWrapperService boomiWrapperService,
            IIntegrationEventBus integrationEventBus,
            IMapper mapper)
        {
            this.logger = logger;
            this.boomiWrapperService = boomiWrapperService;
            this.integrationEventBus = integrationEventBus;
            this.mapper = mapper;
        }

        public Task Handle(GenerateJobCreation @event)
        {
            logger.LogInformation("----- Consuming Event: Generate Job Creation Integration Event");
            logger.LogInformation("----- CorelationId is {id}", @event.CorelationId);
            logger.LogInformation("----- Event Detail is {info}", @event.JsonStringData);

            BoomiRequestResponse boomiRequestResponse;
            //1.Generate request for boomi 
            JobCreationRequest jobCreationRequest = GenerateRequestPayload(@event.CorelationId, @event.ActionBy, @event.JsonStringData, out boomiRequestResponse);

            //2.Record request in database
            boomiWrapperService.RecordRequestPayload(boomiRequestResponse);

            //3. Boomi Call
            JobCreationResponse jobCreationResponse = boomiWrapperService.CreateJob(jobCreationRequest).Result;

            //4. Record Response
            boomiRequestResponse.Status = BoomiResponseType.Success.ToString();
            boomiRequestResponse.ResponseStatus = jobCreationResponse.Success;
            boomiRequestResponse.RequestDateTime = DateTime.UtcNow;
            boomiRequestResponse.ResponseBody = JsonConvert.SerializeObject(jobCreationResponse);
            if (jobCreationResponse.Errors != null && jobCreationResponse.Errors.Any())
            {
                boomiRequestResponse.ErrorMessage = JsonConvert.SerializeObject(jobCreationResponse.Errors);
                boomiRequestResponse.Status = BoomiResponseType.Failed.ToString();
            }

            boomiWrapperService.RecordResponse(boomiRequestResponse);

            //5.Generate response for publish event
            var result = GenerateResponseForPublishEvent(jobCreationResponse);

            //6.publish event
            GeneratedJobCreation success =
            new(
                boomiRequestResponse.RequestId.ToString(),
                @event.CorelationId,
                JsonConvert.SerializeObject(result),
                DateTime.UtcNow,
                SagaEventExecutionResult.Success,
                @event.ActionBy
                );

            logger.LogInformation("Publish Generated Job Creation event  - GenerateJobCreation.");
            integrationEventBus.Publish(success);

            return Task.CompletedTask;

        }

        private JobCreationRequest GenerateRequestPayload(Guid corelationId, string actionBy, string jsonStringData, out BoomiRequestResponse boomiRequestResponse)
        {
            var generateJobCreationRequest = JsonConvert.DeserializeObject<GenerateJobCreationRequest>(jsonStringData);

            var jobCreationRequest = mapper.Map<GenerateJobCreationRequest, JobCreationRequest>(generateJobCreationRequest);
            boomiRequestResponse = new BoomiRequestResponse()
            {
                RequestId = generateJobCreationRequest.RequestId,
                CorelationId = corelationId,
                EventId = generateJobCreationRequest.EventId,
                KeyName = generateJobCreationRequest.KeyName,
                KeyValue = generateJobCreationRequest.KeyValue,
                RequestDateTime = DateTime.UtcNow,
                RequestStatus = BoomiResponseType.Success.ToString(),
                RequestBody = JsonConvert.SerializeObject(jobCreationRequest),
                RequestURL = "injob/jobcreation",
                RequestMethod = "jobcreation",
                HttpVerb = "Post",
                ActionBy = actionBy
            };

            return jobCreationRequest;
        }

        private static int GenerateResponseForPublishEvent(JobCreationResponse jobCreationResponse)
        {
            return Convert.ToInt32(jobCreationResponse.JobNumber);
        }
    }
}

