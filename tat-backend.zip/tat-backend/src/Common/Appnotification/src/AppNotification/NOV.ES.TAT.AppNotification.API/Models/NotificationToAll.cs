﻿namespace NOV.ES.TAT.AppNotification.API.Models
{
    public enum MessageType
    {
        SystemShuttingDown = 0,
        MaintenanceActivityCompleted = 1,
        Broadcast = 2
    }

    public class NotificationToAll
    {
        public int Id { get; set; }
        public MessageType MessageType { get; set; }
        public string MessageId { get; set; }
        public string Title { get; set; }
        public string Detail { get; set; }
        public DateTime ScheduleStartDate { get; set; }
        public DateTime? ScheduleEndDate { get; set; }

        public NotificationToAll()
        {
        }

        public NotificationToAll(int id, MessageType messageType, string messageId, 
            string title, string detail, 
            DateTime scheduleStartDate, DateTime scheduleEndDate)
        {
            Id = id;
            MessageType = messageType;
            MessageId = messageId;
            Title = title;
            Detail = detail;
            ScheduleStartDate = scheduleStartDate;
            ScheduleEndDate = scheduleEndDate;
        }
    }
}
