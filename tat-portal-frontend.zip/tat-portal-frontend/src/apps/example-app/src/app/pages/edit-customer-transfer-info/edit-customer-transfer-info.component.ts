import { AfterViewInit, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { MenuItem, TreeNode } from 'primeng/api';
import { ThemeService } from '../../services/theme.service';
import { NodeService } from './nodeservice';
import { timer } from 'rxjs';


interface City {
  name: string,
  code: string
}

@Component({
  selector: 'tat-portal-frontend-edit-customer-transfer-info',
  templateUrl: './edit-customer-transfer-info.component.html',
  styleUrls: ['./edit-customer-transfer-info.component.scss']
})
export class EditCustomerTransferInfoComponent implements OnInit {
  files1: TreeNode[];
  cities: City[];
  selectedCity: City;
  date3: Date;
  items: MenuItem[];
  ChangeSequenceDisplay: boolean;
  completeCustomerTransferSlipDisplay: boolean;
  productService: any;
  products: any;
  
  files: TreeNode[];
  selectedFiles: TreeNode;
 
  
  constructor(private themeService : ThemeService, private nodeService: NodeService) {     
    this.cities = [
      {name: 'New York', code: 'NY'},
      {name: 'Rome', code: 'RM'},
      {name: 'London', code: 'LDN'},
      {name: 'Istanbul', code: 'IST'},
      {name: 'Paris', code: 'PRS'}
    ];
    this.selectedCity=this.cities[1];
  }
  
  ngOnInit(): void {
    this.nodeService.getFiles().then(files => this.files1 = files);
     throw new Error('Method not implemented.');
     this.productService.getProductsWithOrdersSmall().then((data: any) => this.products = data);
  
      
  }

  ChangeSequenceDialog() {
    this.ChangeSequenceDisplay = true;
  }

  completeCustomerTransferSlipDialog() {
    this.completeCustomerTransferSlipDisplay = true;
  }

  changeTheme(theme: string) {
    this.themeService.switchTheme(theme);
  }
  
  drawLine()
  {
    var tree = document.getElementsByClassName("triview");
    console.log(tree);
    var d =document.getElementsByClassName("p-highlight");       
    var x1 = d[0].getBoundingClientRect();        
    
    var d1= document.getElementById("headingName");
    var x2 = d1.getBoundingClientRect();

    var wpof = window.pageYOffset;    
    var dix1 = 0;
    var diy1 = 0;
    if(window.screen.height > 720)
    {
     dix1 = Math.round(x1.width- x1.left)/2 + 0.5 ;
     diy1 = Math.round(x1.top-x1.width)-5;  //-5
    }
    else
    {
      dix1 = Math.round(x1.width- x1.left)/2 + 6  ;
     diy1 = Math.round(x1.top-x1.width) - 5;  
    }
    var diy1New    
    if(diy1 < 0) 
    {
      diy1New= diy1 + wpof;      
    }
    else
    {
      diy1New = diy1+wpof;           
    }
    var dix2 = Math.round(x2.left +(x2.width/2));    
    var position = d[0].ariaPosInSet;
    var diy2;
    if(parseInt(position) == 1)
    {
      diy2= Math.round(8- parseInt(position)) + 2;
    }
    if(parseInt(position) == 2)
    {
      diy2= Math.round(8- parseInt(position)) + 2;
    }
    if(parseInt(position) ==3)
    {
      if(window.screen.height > 720)
      { diy2= Math.round(8- parseInt(position)) + 2;}
      else{
       diy2= Math.round(8- parseInt(position)) + 1.5;}
    }
    else if(parseInt(position) >=4  && parseInt(position) <=5)
    {
     
      if(window.screen.height > 720)
      { diy2= Math.round(8- parseInt(position)) + 1.5;}
      else
      {
        diy2= Math.round(8- parseInt(position)) + 1;
      }
    }
    else if(parseInt(position) > 5)
    {
      if(window.screen.height > 720)
      {
        diy2= Math.round(8- parseInt(position)) + 1 ;
      }
      else
      {
        diy2= Math.round(8- parseInt(position)) + 0.5 ;
      }
     
    }        
    var dx2= (dix2-dix1);       
     var crossline = document.getElementById('Crossline');
     crossline.setAttributeNS(null, 'x1', dix1.toString()+'%');
     crossline.setAttributeNS(null, 'y1', diy1New.toString());
     crossline.setAttributeNS(null, 'x2', dx2.toString());
     crossline.setAttributeNS(null, 'y2', diy2.toString()+'%');    
     crossline.setAttributeNS(null,'stroke','#06CEE4');
    
  }
  nodeSelected(value:any){     
    setTimeout(() => {     
      this.drawLine();     
    }, 50);
        
  } 
  
  
}
  
