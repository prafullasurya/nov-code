﻿namespace NOV.ES.TAT.Common.Appnotification.Models
{
    public class EventEntry
    {
        public int Id { get; set; }
        public EventProgress EventProgress { get; set; }

        public EventEntry(int id, EventProgress eventProgress)
        {
            Id = id;
            EventProgress = eventProgress;
        }
    }
}
