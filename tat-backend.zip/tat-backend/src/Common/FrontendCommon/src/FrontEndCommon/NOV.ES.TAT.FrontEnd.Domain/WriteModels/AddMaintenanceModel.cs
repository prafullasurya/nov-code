﻿using NOV.ES.Framework.Core.Entities;

namespace NOV.ES.TAT.FrontEnd.Domain.WriteModels
{    
    public class AddMaintenanceModel 
    {
        public string MessageId { get; set; }
        public string DownTimeReason { get; set; }
        public DateTime ExpectedResumeBy { get; set; }
        public DateTime ScheduledOn { get; set; }
    }
}
