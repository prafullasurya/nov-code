import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UsageWellsiteComponent } from './usage-wellsite.component';

describe('UsageWellsiteComponent', () => {
  let component: UsageWellsiteComponent;
  let fixture: ComponentFixture<UsageWellsiteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UsageWellsiteComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UsageWellsiteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
function beforeEach(arg0: () => void) {
  throw new Error('Function not implemented.');
}

