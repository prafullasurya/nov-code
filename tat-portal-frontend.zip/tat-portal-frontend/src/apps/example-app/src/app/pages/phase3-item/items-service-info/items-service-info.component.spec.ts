import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ItemsServiceInfoComponent } from './items-service-info.component';

describe('ItemsServiceInfoComponent', () => {
  let component: ItemsServiceInfoComponent;
  let fixture: ComponentFixture<ItemsServiceInfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ItemsServiceInfoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ItemsServiceInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
function beforeEach(arg0: () => void) {
  throw new Error('Function not implemented.');
}

