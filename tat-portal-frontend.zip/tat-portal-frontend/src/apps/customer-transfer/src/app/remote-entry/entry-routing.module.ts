import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {
  AddCtsHeaderComponent,
  AddEditCtsRigwellSiteinfoComponent,
  AddEditCtsSealseinfoComponent,
  AddEditCtsShipinginfoComponent,
  AddTatItemsComponent,
  CompleteAssemblyDetailsComponent,
  CompleteInventoryItemDetailsComponent,
  CompleteMiscComponent,
  CompleteRigWellsiteInfoComponent,
  CompleteSalesInfoComponent,
  CompleteShippingInfoComponent,
  CustomerTransferSlipComponent,
  EditCtsHeaderComponent,
  UserPreferenceDetailsComponent,
  UserPreferenceDetailsCtsComponent,
  CtsSnapshotComponent,
  NovJobComponent,
  NovJobDetailsComponent,
  NovJobExportToExcelComponent,
  CompleteLineItemsComponent,
  EditReadonlySalesInfoComponent,
  EditReadonlyRigWellsiteInfoComponent,
  EditReadonlyShippingInfoComponent,
  InventoryItemDetailsErrorComponent,
  FailedErpItemsBatchComponent,
  AddCustomerTransferSlipComponent,
  AddCustomerTransferSlipOpenComponent,
  EditInventoryItemDetailsComponent,
  RigInfoCompleteComponent,
  CtsTransferComponent,
  CtsTableGridComponent,
  RigInfoOpenComponent,
  AddItemExistingheaderComponent,
  RigInfoComponent,
  FieldTransferJobOpenComponent,
  CustomerDeliveryJobOpenComponent,
  SalesOrderJobOpenComponent,
  UsageJobOpenComponent,
  JobCompleteComponent,
  BasicInfoOpenComponent,
} from '@tat/customer-transfer/feature-customer-transfer';
import {
  AssemblyComponent,
  AssemblyDetailsComponent,
  HistoryBasicCpsComponent,
  InventoryItemsComponent,
  LineItemsComponent,
  MiscComponent,
  MiscIdentifierComponent,
} from '@tat/items/feature-items-search';

import { AuthenticationGuard } from '@tat/shared/util-authentication';

import {
  CtsHeaderProgressComponent,
  CtsSnapshotEventComponent,
} from '@tat/customer-transfer/feature-customer-transfer';

import { RemoteEntryComponent } from './entry.component';
import { PendingChangesGuard } from '@tat/items/data-access-items';
import {
  BasicinfoComponent,
  JobHeaderComponent,
  JobsCdslipComponent,
  JobsComponent,
  JobsFtslipComponent,
  JobsReturnComponent,
  JobsSalesOrderComponent,
  JobsUsageComponent,
} from '@tat/jobs/feature-jobs-search';

import { FieldTransferSlipsComponent } from 'libs/field-transfer/feature-field-transfer/src/lib/containers/field-tranfer-slips/field-transfer-slips/field-transfer-slips.component';

import { AddFieldTransferSlipComponent } from 'libs/field-transfer/feature-field-transfer/src/lib/manage-field-transfer-slip/components/add-field-transfer-slip/add-field-transfer-slip.component';
import { TatFtsRigInfoOpenComponent } from 'libs/field-transfer/feature-field-transfer/src/lib/manage-field-transfer-slip/components/tat-fts-rig-info-open/tat-fts-rig-info-open.component';
import { FtsRigInfoCompleteComponent } from 'libs/field-transfer/feature-field-transfer/src/lib/manage-field-transfer-slip/components/fts-rig-info-complete/fts-rig-info-complete.component';
import { EditFtsHeaderComponent } from 'libs/field-transfer/feature-field-transfer/src/lib/manage-field-transfer-slip/containers/edit-fts-header/edit-fts-header.component';
import { EditFtsReadonlyShippingInfoComponent } from 'libs/field-transfer/feature-field-transfer/src/lib/manage-field-transfer-slip/containers/edit-fts-readonly-shipping-info/edit-fts-readonly-shipping-info.component';
import { EditFtsReadonlyRigWellsiteInfoComponent } from 'libs/field-transfer/feature-field-transfer/src/lib/manage-field-transfer-slip/containers/edit-fts-readonly-rig-wellsite-info/edit-fts-readonly-rig-wellsite-info.component';
import { ReadonlyFtsCustomerRigInfoComponent } from 'libs/field-transfer/feature-field-transfer/src/lib/manage-field-transfer-slip/components/readonly-fts-customer-rig-info/readonly-fts-customer-rig-info.component';
import { ReadonlyFtsShippingInfoComponent } from 'libs/field-transfer/feature-field-transfer/src/lib/manage-field-transfer-slip/components/readonly-fts-shipping-info/readonly-fts-shipping-info.component';
import { ReadonlyFtsInventoryItemDetailsComponent } from 'libs/field-transfer/feature-field-transfer/src/lib/manage-field-transfer-slip/components/readonly-fts-inventory-item-details/readonly-fts-inventory-item-details.component';
import { ReadonlyFtsAssemblyDetailsComponent } from 'libs/field-transfer/feature-field-transfer/src/lib/manage-field-transfer-slip/components/readonly-fts-assembly-details/readonly-fts-assembly-details.component';
import { ReadonlyFtsMiscComponent } from 'libs/field-transfer/feature-field-transfer/src/lib/manage-field-transfer-slip/components/readonly-fts-misc/readonly-fts-misc.component';
import { ReadonlyFtsLineItemsComponent } from 'libs/field-transfer/feature-field-transfer/src/lib/manage-field-transfer-slip/components/readonly-fts-line-items/readonly-fts-line-items.component';
import { FtsFailedErpItemsBatchComponent } from 'libs/field-transfer/feature-field-transfer/src/lib/manage-field-transfer-slip/components/fts-failed-erp-items-batch/fts-failed-erp-items-batch.component';
import {
  FtsAssemblyComponent,
  FtsAssemblyDetailsComponent,
  FtsInventoryItemsComponent,
  FtsLineItemsComponent,
  FtsMiscComponent,
} from 'libs/items/feature-fts-items-search/src';
import { FtsSnapshotEventComponent } from 'libs/field-transfer/feature-field-transfer/src/lib/manage-field-transfer-slip/containers/fts-snapshot-event/fts-snapshot-event.component';
import { AddEditFtsRigwellSiteinfoComponent } from 'libs/field-transfer/feature-field-transfer/src/lib/manage-field-transfer-slip/components/add-edit-fts-rigwell-siteinfo/add-edit-fts-rigwell-siteinfo.component';
import { AddFtsHeaderComponent } from 'libs/field-transfer/feature-field-transfer/src/lib/manage-field-transfer-slip/containers/add-fts-header/add-fts-header.component';
import { AddEditFtsShipinginfoComponent } from 'libs/field-transfer/feature-field-transfer/src/lib/manage-field-transfer-slip/components/add-edit-fts-shipinginfo/add-edit-fts-shipinginfo.component';
import { FtsHeaderCompleteProgressComponent } from 'libs/field-transfer/feature-field-transfer/src/lib/manage-field-transfer-slip/containers/fts-header-complete-progress/fts-header-complete-progress.component';
import { AddFtsTatItemsComponent } from 'libs/field-transfer/feature-field-transfer/src/lib/manage-field-transfer-slip/containers/add-fts-tat-items/add-fts-tat-items.component';
import { EditFtsInventoryItemDetailsComponent } from 'libs/field-transfer/feature-field-transfer/src/lib/manage-field-transfer-slip/components/edit-fts-inventory-item-details/edit-fts-inventory-item-details.component';
import { AddFtsItemExistingheaderComponent } from 'libs/field-transfer/feature-field-transfer/src/lib/manage-field-transfer-slip/containers/add-fts-item-existingheader/add-fts-item-existingheader.component';
import { FtsErrorComponent } from 'libs/items/feature-fts-items-search/src/lib/containers/fts-error/fts-error.component';
const routes: Routes = [
  {
    path: '',
    component: RemoteEntryComponent,
    children: [
      {
        path: 'slips',
        component: CustomerTransferSlipComponent,
        canActivate: [AuthenticationGuard],
      },
      {
        path: 'fieldtransfers',
        component: FieldTransferSlipsComponent,
        canActivate: [AuthenticationGuard],
      },
      {
        path: 'CtsSnapshot/:id',
        component: CtsSnapshotEventComponent,
        canActivate: [AuthenticationGuard],
      },
      {
        path: 'SnapShotEvent/:id',
        component: FtsSnapshotEventComponent,
        canActivate: [AuthenticationGuard],
      },
      {
        path: 'SnapShotEvent/:id',
        component: FtsSnapshotEventComponent,
        canActivate: [AuthenticationGuard],
      },
      {
        path: 'NovJob',
        component: NovJobComponent,
        canActivate: [AuthenticationGuard],
      },
      {
        path: 'additemtoheader',
        component: AddItemExistingheaderComponent,
        canActivate: [AuthenticationGuard],
      },
      {
        path: 'ftsadditemtoheader',
        component: AddFtsItemExistingheaderComponent,
        canActivate: [AuthenticationGuard],
      },
      {
        path: 'NovJobDetails',
        component: NovJobDetailsComponent,
        canActivate: [AuthenticationGuard],
      },
      {
        path: 'RigInfoComplete',
        component: RigInfoCompleteComponent,
        canActivate: [AuthenticationGuard],
      },
      {
        path: 'RigInfoOpen',
        component: RigInfoOpenComponent,
        canActivate: [AuthenticationGuard],
      },
      {
        path: 'RigInfo',
        component: RigInfoComponent,
        canActivate: [AuthenticationGuard],
      },
      {
        path: 'BasicInfoOpen',
        component: BasicInfoOpenComponent,
        canActivate: [AuthenticationGuard],
      },
      {
        path: 'CtsTransfer',
        component: CtsTransferComponent,
        canActivate: [AuthenticationGuard],
      },
      {
        path: 'CtsTableGrid',
        component: CtsTableGridComponent,
        canActivate: [AuthenticationGuard],
      },
      {
        path: 'FieldTransferJobOpen',
        component: FieldTransferJobOpenComponent,
        canActivate: [AuthenticationGuard],
      },
      {
        path: 'CustomerDeliveryJobOpen',
        component: CustomerDeliveryJobOpenComponent,
        canActivate: [AuthenticationGuard],
      },
      {
        path: 'NovJobExportToExcel',
        component: NovJobExportToExcelComponent,
        canActivate: [AuthenticationGuard],
      },
      {
        path: 'UsageJobOpen',
        component: UsageJobOpenComponent,
        canActivate: [AuthenticationGuard],
      },
      {
        path: ' SalesOrderJobOpen',
        component: SalesOrderJobOpenComponent,
        canActivate: [AuthenticationGuard],
      },
      {
        path: 'JobComplete',
        component: JobCompleteComponent,
        canActivate: [AuthenticationGuard],
      },

      {
        path: 'AddCustomerTransferSlip',
        component: AddCtsHeaderComponent,
        children: [
          {
            path: 'CustomerSalesInfo',
            component: AddEditCtsSealseinfoComponent,
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'RigWellSiteInfo',
            component: AddEditCtsRigwellSiteinfoComponent,
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'ShippingInfo',
            component: AddEditCtsShipinginfoComponent,
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'CtsHeaderCompleteProgress',
            component: CtsHeaderProgressComponent,
            canActivate: [AuthenticationGuard],
          },
        ],
        canActivate: [AuthenticationGuard],
      },

      //Field Transfer
      {
        path: 'AddFieldTransferSlip',
        component: AddFtsHeaderComponent,
        canActivate: [AuthenticationGuard],
        children: [
          {
            path: 'CustomerRigInfo',
            component: AddEditFtsRigwellSiteinfoComponent,
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'ShippingInfo',
            component: AddEditFtsShipinginfoComponent,
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'FtsHeaderCompleteProgress',
            component: FtsHeaderCompleteProgressComponent,
            canActivate: [AuthenticationGuard],
          },
        ],
      },
      {
        path: 'FtsRigInfoComplete',
        component: FtsRigInfoCompleteComponent,
        canActivate: [AuthenticationGuard],
      },
      {
        path: 'FtsRigInfoOpen',
        component: TatFtsRigInfoOpenComponent,
        canActivate: [AuthenticationGuard],
      },
      {
        path: 'EditFieldTransfer',
        component: EditFtsHeaderComponent,
        children: [
          {
            path: 'RigWellSiteInfo',
            component: EditFtsReadonlyRigWellsiteInfoComponent,
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'ShippingInfo',
            component: EditFtsReadonlyShippingInfoComponent,
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'fts-line-items',
            component: FtsLineItemsComponent,
            children: [
              {
                path: ':id',
                component: FtsLineItemsComponent,
                canActivate: [AuthenticationGuard],
              },
            ],
            canActivate: [AuthenticationGuard],
          },

          {
            path: 'RigWellSiteInfo',
            component: ReadonlyFtsCustomerRigInfoComponent,
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'shippingInfo',
            component: ReadonlyFtsShippingInfoComponent,
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'CompleteInventoryItemDetails',
            component: ReadonlyFtsInventoryItemDetailsComponent,
            children: [
              {
                path: ':id',
                component: CompleteInventoryItemDetailsComponent,
                canActivate: [AuthenticationGuard],
              },
            ],
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'assembly-details',
            component: FtsAssemblyDetailsComponent,
            canDeactivate: [PendingChangesGuard],
            children: [
              {
                path: ':id',
                component: FtsAssemblyDetailsComponent,
                canActivate: [AuthenticationGuard],
                canDeactivate: [PendingChangesGuard],
              },
            ],
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'CompleteAssemblyDetails',
            component: ReadonlyFtsAssemblyDetailsComponent,
            children: [
              {
                path: ':id',
                component: CompleteAssemblyDetailsComponent,
                canActivate: [AuthenticationGuard],
              },
            ],
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'CompleteMisc',
            component: ReadonlyFtsMiscComponent,
            children: [
              {
                path: ':id',
                component: CompleteMiscComponent,
                canActivate: [AuthenticationGuard],
              },
            ],
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'LineItemsComponent',
            component: ReadonlyFtsLineItemsComponent,
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'edit-inventory-item',
            component: EditFtsInventoryItemDetailsComponent,
            canDeactivate: [PendingChangesGuard],
            children: [
              {
                path: ':id',
                component: EditFtsInventoryItemDetailsComponent,
                canActivate: [AuthenticationGuard],
                canDeactivate: [PendingChangesGuard],
              },
            ],
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'inventory-items',
            component: FtsInventoryItemsComponent,
            canDeactivate: [PendingChangesGuard],
            children: [
              {
                path: ':id',
                component: FtsInventoryItemsComponent,
                canActivate: [AuthenticationGuard],
                canDeactivate: [PendingChangesGuard],
              },
            ],
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'fts-line-items',
            component: FtsLineItemsComponent,
            children: [
              {
                path: ':id',
                component: FtsLineItemsComponent,
                canActivate: [AuthenticationGuard],
              },
            ],
            canActivate: [AuthenticationGuard],
          },

          {
            path: 'fts-line-items',
            component: FtsLineItemsComponent,
            children: [
              {
                path: ':id',
                component: FtsLineItemsComponent,
                canActivate: [AuthenticationGuard],
              },
            ],
            canActivate: [AuthenticationGuard],
          },

          {
            path: 'line-items',
            component: LineItemsComponent,
            children: [
              {
                path: ':id',
                component: LineItemsComponent,
                canActivate: [AuthenticationGuard],
              },
            ],
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'misc',
            component: FtsMiscComponent,
            canDeactivate: [PendingChangesGuard],
            children: [
              {
                path: ':id',
                component: FtsMiscComponent,
                canActivate: [AuthenticationGuard],
                canDeactivate: [PendingChangesGuard],
              },
            ],
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'LineItem-Error',
            component: FtsErrorComponent,
            canDeactivate: [PendingChangesGuard],
            children: [
              {
                path: ':id',
                component: FtsErrorComponent,
                canActivate: [AuthenticationGuard],
                canDeactivate: [PendingChangesGuard],
              },
            ],
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'tat-items',
            component: AddFtsTatItemsComponent,
            children: [
              {
                path: 'assembly',
                component: FtsAssemblyComponent,
                canActivate: [AuthenticationGuard],
              },
              {
                path: 'misc',
                component: MiscComponent,
                canActivate: [AuthenticationGuard],
                canDeactivate: [PendingChangesGuard],
              },
            ],
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'inventory-item',
            component: InventoryItemsComponent,
            canDeactivate: [PendingChangesGuard],
            children: [
              {
                path: ':id',
                component: InventoryItemsComponent,
                canActivate: [AuthenticationGuard],
                canDeactivate: [PendingChangesGuard],
              },
            ],
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'assembly-details',
            component: FtsAssemblyDetailsComponent,
            canDeactivate: [PendingChangesGuard],
            children: [
              {
                path: ':id',
                component: FtsAssemblyDetailsComponent,
                canActivate: [AuthenticationGuard],
                canDeactivate: [PendingChangesGuard],
              },
            ],
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'misc-identifier',
            component: MiscIdentifierComponent,
            canDeactivate: [PendingChangesGuard],
            children: [
              {
                path: ':id',
                component: MiscIdentifierComponent,
                canActivate: [AuthenticationGuard],
                canDeactivate: [PendingChangesGuard],
              },
            ],
            canActivate: [AuthenticationGuard],
          },
          // {
          //   path: 'UserPreferenceDetails',
          //   component: UserPreferenceDetailsComponent,
          //   canActivate: [AuthenticationGuard]
          // },
          // {
          //   path: 'UserPreferenceDetailsCts',
          //   component: UserPreferenceDetailsCtsComponent,
          //   canActivate: [AuthenticationGuard]
          // },
          // {
          //   path: 'AddCustomerTransferSlip',
          //   component:AddCustomerTransferSlipComponent,
          //   canActivate: [AuthenticationGuard]
          // },
          // {
          //   path: 'AddCustomerTransferSlipOpen',
          //   component:AddCustomerTransferSlipOpenComponent,
          //   canActivate: [AuthenticationGuard]
          // },
        ],
        canActivate: [AuthenticationGuard],
      },
      {
        path: 'EditCustomerTransferSlip',
        component: EditCtsHeaderComponent,
        children: [
          {
            path: 'CustomerSalesInfo',
            component: EditReadonlySalesInfoComponent,
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'RigWellSiteInfo',
            component: EditReadonlyRigWellsiteInfoComponent,
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'ShippingInfo',
            component: EditReadonlyShippingInfoComponent,
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'CompleteCustomerSalesInfo',
            component: CompleteSalesInfoComponent,
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'CompleteSalesInfo',
            component: CompleteRigWellsiteInfoComponent,
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'CompleteShippingInfo',
            component: CompleteShippingInfoComponent,
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'UserPreferenceDetails',
            component: UserPreferenceDetailsComponent,
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'UserPreferenceDetailsCts',
            component: UserPreferenceDetailsCtsComponent,
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'AddCustomerTransferSlip',
            component: AddCustomerTransferSlipComponent,
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'AddCustomerTransferSlipOpen',
            component: AddCustomerTransferSlipOpenComponent,
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'line-items',
            component: LineItemsComponent,
            children: [
              {
                path: ':id',
                component: LineItemsComponent,
                canActivate: [AuthenticationGuard],
              },
            ],
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'misc',
            component: MiscComponent,
            canActivate: [AuthenticationGuard],
            canDeactivate: [PendingChangesGuard],
          },
          {
            path: 'tat-items',
            component: AddTatItemsComponent,
            children: [
              {
                path: 'assembly',
                component: AssemblyComponent,
                canActivate: [AuthenticationGuard],
              }
            ],
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'edit-inventory-item',
            component: EditInventoryItemDetailsComponent,
            canDeactivate: [PendingChangesGuard],
            children: [
              {
                path: ':id',
                component: EditInventoryItemDetailsComponent,
                canActivate: [AuthenticationGuard],
                canDeactivate: [PendingChangesGuard],
              },
            ],
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'CompleteInventoryItemDetails',
            component: CompleteInventoryItemDetailsComponent,
            children: [
              {
                path: ':id',
                component: CompleteInventoryItemDetailsComponent,
                canActivate: [AuthenticationGuard],
              },
            ],
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'InventoryItemDetailsError',
            component: InventoryItemDetailsErrorComponent,
            canActivate: [AuthenticationGuard],
          },
          // {
          //   path: 'FailedErpItemsBatch',
          //   component: FailedErpItemsBatchComponent,
          // },

          {
            path: 'FailedErpItemsBatch',
            component: FailedErpItemsBatchComponent,
            children: [
              {
                path: ':id',
                component: FailedErpItemsBatchComponent,
                canActivate: [AuthenticationGuard],
              },
            ],
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'CompleteAssemblyDetails',
            component: CompleteAssemblyDetailsComponent,
            children: [
              {
                path: ':id',
                component: CompleteAssemblyDetailsComponent,
                canActivate: [AuthenticationGuard],
              },
            ],
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'CompleteMisc',
            component: CompleteMiscComponent,
            children: [
              {
                path: ':id',
                component: CompleteMiscComponent,
                canActivate: [AuthenticationGuard],
              },
            ],
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'CompleteLineItemsComponent',
            component: CompleteLineItemsComponent,
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'inventory-items',
            component: InventoryItemsComponent,
            canDeactivate: [PendingChangesGuard],
            children: [
              {
                path: ':id',
                component: InventoryItemsComponent,
                canActivate: [AuthenticationGuard],
                canDeactivate: [PendingChangesGuard],
              },
            ],
            canActivate: [AuthenticationGuard],
          },
          // {
          //   path: 'inventory-items',
          //   component: InventoryItemsComponent,
          //   canActivate: [AuthenticationGuard]
          // },
          {
            path: 'assembly-details',
            component: AssemblyDetailsComponent,
            canDeactivate: [PendingChangesGuard],
            children: [
              {
                path: ':id',
                component: AssemblyDetailsComponent,
                canActivate: [AuthenticationGuard],
                canDeactivate: [PendingChangesGuard],
              },
            ],
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'misc-identifier',
            component: MiscIdentifierComponent,
            canDeactivate: [PendingChangesGuard],
            children: [
              {
                path: ':id',
                component: MiscIdentifierComponent,
                canActivate: [AuthenticationGuard],
                canDeactivate: [PendingChangesGuard],
              },
            ],
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'history-basic-cps',
            component: HistoryBasicCpsComponent,
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'UserPreferenceDetailsCts',
            component: UserPreferenceDetailsCtsComponent,
            canActivate: [AuthenticationGuard],
          },
        ],
        canActivate: [AuthenticationGuard],
      },
      {
        path: 'jobs',
        component: JobsComponent,
        canActivate: [AuthenticationGuard],
      },
      {
        path: 'job/:id',
        component: JobHeaderComponent,
        canActivate: [AuthenticationGuard],
        children: [
          {
            path: 'basicinfo',
            component: BasicinfoComponent,
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'cd-slip',
            component: JobsCdslipComponent,
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'ft-slip',
            component: JobsFtslipComponent,
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'return',
            component: JobsReturnComponent,
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'usage',
            component: JobsUsageComponent,
            canActivate: [AuthenticationGuard],
          },
          {
            path: 'sales-order',
            component: JobsSalesOrderComponent,
            canActivate: [AuthenticationGuard],
          },
        ],
      },
    ],
    canActivate: [AuthenticationGuard],
  },
];

@NgModule({
  imports: [CommonModule, RouterModule.forChild(routes)],
  declarations: [],
  exports: [RouterModule],
  providers: [PendingChangesGuard],
})
export class RemoteEntryRoutingModule {}
