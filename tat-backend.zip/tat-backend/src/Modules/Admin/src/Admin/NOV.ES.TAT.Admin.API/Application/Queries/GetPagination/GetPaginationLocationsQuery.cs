﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Admin.API.DTOs;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetPaginationLocationsQuery : IQuery<PagedResult<LocationDto>>
    {
        public Paging PagingParameters { get; private set; }

        public GetPaginationLocationsQuery(Paging pagingParameters)
        {
            this.PagingParameters = pagingParameters;
        }
    }
    
}
