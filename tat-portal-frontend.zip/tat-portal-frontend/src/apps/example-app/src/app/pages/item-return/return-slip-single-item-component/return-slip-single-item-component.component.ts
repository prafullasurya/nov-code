import { Component} from '@angular/core';

interface City {
  name: string,
  code: string
}
@Component({
  selector: 'return-slip-single-item-component',
  templateUrl: './return-slip-single-item-component.component.html',
  styleUrls: ['./return-slip-single-item-component.component.scss']
})
export class ReturnSlipSingleItemComponent {
  
  


}
