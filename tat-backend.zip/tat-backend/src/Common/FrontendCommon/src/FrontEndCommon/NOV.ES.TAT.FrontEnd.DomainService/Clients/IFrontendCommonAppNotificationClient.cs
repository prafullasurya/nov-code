﻿using NOV.ES.TAT.FrontEnd.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NOV.ES.TAT.FrontEnd.DomainService.Clients
{
    public interface IFrontendCommonAppNotificationClient
    {
        Task BroadcastSystemShutingdownMessageAsync(MaintenanceModel maintenanceModel);   
    }
}
