﻿using NOV.ES.TAT.BoomiWrapper.Domain;

namespace NOV.ES.TAT.BoomiWrapper.DomainService
{
    public interface IErpItemsBatchService
    {
        int CreateErpItemsBatch(ErpItemsBatch erpItemsBatch);
        void Update(ErpItemsBatch erpItemsBatch);
    }
}
