import { Component, OnInit } from '@angular/core';
import {SelectItem} from 'primeng/api';
import { Product } from '../../models/product';

interface City {
  name: string,
  code: string,
  namelist: string
}

@Component({
  selector: 'tat-portal-frontend-cts-tat-item',
  templateUrl: './cts-tat-item.component.html',
  styleUrls: ['./cts-tat-item.component.scss']
})

export class CtsTatItemComponent implements OnInit {

  cities: City[];
  selectedCountry: string;
  countries: any[];
  items: SelectItem[];
  item: string;
  products1: Product[];
  products: Product[];
  completeCustomerTransferSlipDisplay: boolean;
  primengConfig: any;
  selectedCity: City;
  
    ngOnInit() {
      this.primengConfig.ripple = true;
    }
  
    completeCustomerTransferSlipDialog() {
      this.completeCustomerTransferSlipDisplay = true;
    }
  }