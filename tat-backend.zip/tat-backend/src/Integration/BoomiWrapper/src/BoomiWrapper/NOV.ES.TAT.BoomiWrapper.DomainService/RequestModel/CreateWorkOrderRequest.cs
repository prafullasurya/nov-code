﻿using Newtonsoft.Json;
using NOV.ES.TAT.BoomiWrapper.Domain.WriteModels;

namespace NOV.ES.TAT.BoomiWrapper.DomainService.RequestModel
{
    public class CreateWorkOrderRequest : BoomiRequestBaseModel
    {
        [JsonProperty("activeYN")]
        public string ActiveYN { get; set; }  //Y
        [JsonProperty("addressNumber")]
        public string AddressNumber { get; set; } //customerIdString
        [JsonProperty("addressNumberShipTo")]
        public string AddressNumberShipTo { get; set; } //Same as above
        [JsonProperty("businessUnit")]
        public string BusinessUnit { get; set; }//BusinessUnitcode
        [JsonProperty("CMode")]
        public string CMode { get; set; } // mode
        [JsonProperty("CMode2")]
        public string CMode2 { get; set; }  // Empty
        [JsonProperty("charFutureUse1")]
        public string CharFutureUse1 { get; set; }
        [JsonProperty("company")]
        public string Company { get; set; } //company code
        [JsonProperty("dateExpired")]
        public string DateExpired { get; set; } //empty
        [JsonProperty("dateRequested")]
        public string DateRequested { get; set; } //empty
        [JsonProperty("dateStart")]
        public string DateStart { get; set; }//empty
        [JsonProperty("dateUpdated")]
        public string DateUpdated { get; set; }//empty
        [JsonProperty("Description")]
        public string Description { get; set; } //toolDesc name
        [JsonProperty("description02")]
        public string Description02 { get; set; } //empty
        [JsonProperty("documentOrderNo")]
        public string DocumentOrderNo { get; set; } //jdeWorkOrder
        [JsonProperty("ediSuccessfullyProcess")]
        public string EdiSuccessfullyProcess { get; set; } //empty
        [JsonProperty("jobNumber")]
        public string JobNumber { get; set; } //oUsage.JDEJobNumber
        [JsonProperty("ItemNumber")]
        public string ItemNumber { get; set; } // part no or empty
        [JsonProperty("ParentWONumber")]
        public string ParentWONumber { get; set; } //empty
        [JsonProperty("orderType")]
        public string OrderType { get; set; } //jdeWorkOrderType  SV UV 
        [JsonProperty("programID")]
        public string ProgramID { get; set; }//empty
        [JsonProperty("reference")]
        public string Reference { get; set; }//oProductType.Tatsrp1
        [JsonProperty("reference2")]
        public string Reference2 { get; set; } //oToolClass.TATSRP4
        [JsonProperty("serialNumber")]
        public string SerialNumber { get; set; }//Toolserial no
        [JsonProperty("statusCodeWO")]
        public string StatusCodeWO { get; set; }//empty
        [JsonProperty("subledgerGL")]
        public string SubledgerGL { get; set; } //usageFileNumberInput
        [JsonProperty("CostCenter_MMCU")]
        public string CostCenterMMCU { get; set; }//retaning   BU
        [JsonProperty("timeLastUpdated")]
        public string TimeLastUpdated { get; set; } //date time now 
        [JsonProperty("userID")]
        public string UserID { get; set; } //last updated userId + " via TAT"
        [JsonProperty("workStationID")]
        public string WorkStationID { get; set; } //empty

    }
}
