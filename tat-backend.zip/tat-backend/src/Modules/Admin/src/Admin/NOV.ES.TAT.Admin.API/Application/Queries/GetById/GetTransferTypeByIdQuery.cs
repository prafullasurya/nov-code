﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;

namespace NOV.ES.TAT.Admin.API.Application.Queries.GetById
{
    public class GetTransferTypeByIdQuery : IQuery<TransferTypeDto>
    {
        public int Id { get; private set; }

        public GetTransferTypeByIdQuery(int id)
        {
            this.Id = id;
        }
    }
}
