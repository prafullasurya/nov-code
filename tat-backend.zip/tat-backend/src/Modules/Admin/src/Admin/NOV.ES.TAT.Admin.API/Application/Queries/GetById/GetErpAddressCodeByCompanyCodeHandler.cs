﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetErpAddressCodeByCompanyCodeHandler : IQueryHandler<GetErpAddressCodeByCompanyCodeQuery, IEnumerable<ErpAddressCodeDto>>
    {
        private readonly IMapper mapper;
        private readonly IErpAddressCodeService erpAddressCodeService;

        public GetErpAddressCodeByCompanyCodeHandler(
            IMapper mapper,
            IErpAddressCodeService erpAddressCodeService)
        {
            this.mapper = mapper;
            this.erpAddressCodeService = erpAddressCodeService;
        }

        public Task<IEnumerable<ErpAddressCodeDto>> Handle(GetErpAddressCodeByCompanyCodeQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var erpAddressCode = erpAddressCodeService.GetErpAddressCodeByCompanyCode(request.CompanyCode);
            var result = mapper.Map<IEnumerable<ErpAddressCode>, IEnumerable<ErpAddressCodeDto>>(erpAddressCode);
            return Task.FromResult(result);
        }
        private static bool IsValidRequest(GetErpAddressCodeByCompanyCodeQuery request)
        {
            return (request != null && !string.IsNullOrEmpty(request.CompanyCode));
        }
    }
}