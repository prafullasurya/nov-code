import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerReturLineItemDetailsCompletedComponent } from './customer-return-line-item-details-completed.component';

describe('CustomerReturnSlipComponent', () => {
  let component: CustomerReturLineItemDetailsCompletedComponent;
  let fixture: ComponentFixture<CustomerReturLineItemDetailsCompletedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerReturLineItemDetailsCompletedComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerReturLineItemDetailsCompletedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
