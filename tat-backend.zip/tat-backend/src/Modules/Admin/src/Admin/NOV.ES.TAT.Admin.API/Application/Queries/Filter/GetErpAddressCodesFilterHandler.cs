﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetErpAddressCodesFilterHandler : IQueryHandler<GetErpAddressCodesFilterQuery, IEnumerable<string>>
    {       
        private readonly IErpAddressCodeService erpAddressCodeService;

        public GetErpAddressCodesFilterHandler(            
            IErpAddressCodeService erpAddressCodeService)
        {                        
            this.erpAddressCodeService = erpAddressCodeService;
        }
        public Task<IEnumerable<string>> Handle(GetErpAddressCodesFilterQuery request, CancellationToken cancellationToken)
        {
            return Task.FromResult(erpAddressCodeService.GetErpAbCodes(request.FilterData).AsEnumerable());
        }
    }
}

