import { Component, OnInit } from '@angular/core';
import { ConfirmationService, MessageService } from 'primeng/api';


interface City {
  name: string,
  code: string
}
@Component({
  selector: 'usage-wellsite-old',
  templateUrl: './usage-wellsite-old.component.html',
  styleUrls: ['./usage-wellsite-old.component.scss']
})
export class UsageWellsiteOldComponent {
  
  // activeIndex1: number = 0;

  // activeIndex2: number = 0;

  // scrollableTabs: any[] = Array.from({ length: 50 }, (_, i) => ({ title: `Tab ${i + 1}`, content: `Tab ${i + 1} Content` }));

}
