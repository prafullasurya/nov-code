﻿namespace NOV.ES.TAT.BoomiWrapper.DomainService.ResponseModel
{
    public class JobCreationResponse
    {
        public string Success { get; set; }
        public string JobNumber { get; set; }
        public string OrderType { get; set; }
        public string CustomerName { get; set; }
        public string Customer { get; set; }
        public string SendingBUName { get; set; }
        public string SendingBU { get; set; }
        public string RevenueBuName { get; set; }
        public string RevenueBU { get; set; }
        public string ContactName { get; set; }
        public string ContactNumber { get; set; }
        public string CustomerPO { get; set; }
        public string RentalAgreement { get; set; }
        public string Description { get; set; }
        public string Description2 { get; set; }
        public string PlannedStartDate { get; set; }
        public string PlannedEndDate { get; set; }
        public string DescrActualStartDateiption2 { get; set; }
        public string ActualEndDate { get; set; }
        public string Rig { get; set; }
        public List<ErpError> Errors { get; set; }
    }
}
