import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ItemsBasicComponent } from './items-basic.component';

describe('ItemsBasicComponent', () => {
  let component: ItemsBasicComponent;
  let fixture: ComponentFixture<ItemsBasicComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ItemsBasicComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ItemsBasicComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
function beforeEach(arg0: () => void) {
  throw new Error('Function not implemented.');
}

