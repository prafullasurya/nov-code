import { ComponentFixture, TestBed } from '@angular/core/testing';

import { nftTatItemComponent } from './nft-tat-item.component';

describe('nftTatItemComponent', () => {
  let component: nftTatItemComponent;
  let fixture: ComponentFixture<nftTatItemComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ nftTatItemComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(nftTatItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
