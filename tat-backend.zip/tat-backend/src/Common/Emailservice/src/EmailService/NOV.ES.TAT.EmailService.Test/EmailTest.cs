﻿
using Microsoft.Extensions.Options;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using NOV.ES.TAT.EmailService.API;
using NOV.ES.TAT.EmailService.API.Dtos;
using NOV.ES.TAT.EmailService.Helper;
using NOV.ES.TAT.EmailService.Service;
using System.Data;
using System.Net.Mail;


namespace NOV.ES.TAT.EmailService.Test
{
    [TestClass]
    public class EmailTest : IDisposable
    {
        private bool disposed;
        private readonly SmtpClient? smtpClient = null;


        [TestMethod]
        public void SendMailWithAttachment()
        {
            IOptions<EmailConfiguration> configs = Options.Create<EmailConfiguration>(new EmailConfiguration("smtp.novTest.com", 25, "Nov.Test@nov.com", "Nov123", "Nov@123"));
            EmailDto email = new EmailDto();
            List<string> toList = new List<string>();
            toList.Add("sheetal.bhosale@nov.com");
            email.ToList = toList;
            email.Subject = "Testing";
            email.Body = "Test";
            //commented below code since it was failing during build
            //  IEmailBaseService emailBaseService = new EmailBase(configs);         
            // emailBaseService.Notifiers(email);
        }
        [TestMethod]
        public void SendEmailNotification()
        {
            string xmlFilePath = Path.Combine(".", "TestData", "EmailTemplate.xml");
            DataSet ds = new DataSet("XmlDataSet");
            ds.ReadXml(xmlFilePath);

            var myList = new List<KeyValuePair<string, string>>();
            myList.Add(new KeyValuePair<string, string>("123-456-455", "Drilling Machine"));
            myList.Add(new KeyValuePair<string, string>("123", "Machine"));
           
            string dynamicString = string.Empty;

            foreach (var val in myList)
            {
                dynamicString += "<tr>";
                dynamicString += "<td>";
                dynamicString += val.Key;
                dynamicString += "</td>";
                dynamicString += "<td>";
                dynamicString += val.Value;
                dynamicString += "</td>";
                dynamicString += "</tr>";
            }

            List<EmailAttributes> dataList = new List<EmailAttributes>();
            dataList.Add(new EmailAttributes("[Subject]", "Testing"));
            dataList.Add(new EmailAttributes("[UserFirstName]", "Ajay"));
            dataList.Add(new EmailAttributes("[DynamicXmlObject]", dynamicString));


            IOptions<EmailConfiguration> configs = Options.Create<EmailConfiguration>(new EmailConfiguration("smtp.novTest.com", 25, "Nov.Test@nov.com", "Nov123", "Nov@123"));
            EmailFlieDto email = new EmailFlieDto();
            List<string> toList = new List<string>();
            toList.Add("sheetal.bhosale@nov.com");
            email.ToList = toList;
            email.Subject = "Testing";
            email.Body = "Test";
            email.XmlDataSet = ds.GetXml();
            email.AttributeList = dataList;
            //commented below code since it was failing during build
         //   IEmailBaseService emailBaseService = new EmailBase(configs);
           // emailBaseService.NotifiersWithFile(email);
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    smtpClient?.Dispose();
                }
                disposed = true;
            }
        }




    }
}
