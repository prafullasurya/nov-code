﻿using NOV.ES.TAT.BoomiWrapper.Domain;

namespace NOV.ES.TAT.BoomiWrapper.DomainService
{
    public interface IErpSoftCommitmentLogService
    {
        void CreateErpSoftCommitmentLog(ErpSoftCommitmentLog erpSoftCommitmentLog);
        void Update(string erpDocNumber, string erpDocType, string errorMessage, string lastUpdateBy, int latestBatchId);
    }
}
