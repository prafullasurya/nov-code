﻿namespace NOV.ES.TAT.BoomiWrapper.DomainService.ResponseModel
{
    public class CreateWorkOrderResponse
    {
        public string Success { get; set; }
        public string BussinessUnit { get; set; }
        public string Company { get; set; }
        public string Description { get; set; }
        public string DocumentOrderNo { get; set; }
        public string ItemNumberShort { get; set; }
        public string ItemNumber { get; set; }
        public string ParentWONumber { get; set; }
        public string AddressNumberShipTo { get; set; }
        public string OrderType { get; set; }
        public string SerialNumber { get; set; }
        public string TimeLastUpdated { get; set; }
        public string EdiSuccessfullyProcess { get; set; }
        public string FlagProcessed { get; set; }
        public string UserID { get; set; }
        public string WorkStationID { get; set; }
        public List<ErpError> Errors { get; set; }
    }
}
