import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ItemListingPageComponent } from './item-listing-page.component';

describe('ItemListingPageComponent', () => {
  let component: ItemListingPageComponent;
  let fixture: ComponentFixture<ItemListingPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ItemListingPageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ItemListingPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
function beforeEach(arg0: () => void) {
  throw new Error('Function not implemented.');
}

