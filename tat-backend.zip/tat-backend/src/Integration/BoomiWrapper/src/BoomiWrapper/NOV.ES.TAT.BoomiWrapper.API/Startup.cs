﻿using Elastic.Apm.NetCoreAll;
using HealthChecks.UI.Client;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using NOV.ES.Framework.Core.Messaging.IntegrationEvents;
using NOV.ES.TAT.BoomiWrapper.API.Application.IntegrationEvents.SubscribedEvents;
using Serilog;
using Serilog.Enrichers;
using Serilog.Exceptions;
using Serilog.Exceptions.Core;
using Serilog.Exceptions.EntityFrameworkCore.Destructurers;
using Serilog.Sinks.Elasticsearch;

namespace NOV.ES.TAT.BoomiWrapper.API
{
    public class Startup
    {
        public IConfiguration Configuration { get; }
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
            Log.Logger = GetElasticLogger();
        }
        public virtual void ConfigureServices(IServiceCollection services)
        {
            services
            .AddCustomMvc()
            .AddHttpContextAccessor()
            .AddHealthChecks(Configuration)
            .AddCustomDbContext(Configuration)
            .AddCustomSwagger(Configuration)
            .RegistorMediatR()
            .AddAutoMapper()
            .AddDomainCoreDependecy()
            .AddPolly(Configuration)
            .AddIntegrationEventBus()
            .AddRabbitMq(Configuration);
        }
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILoggerFactory loggerFactory)
        {
            var pathBase = Configuration["PATH_BASE"];
            if (!string.IsNullOrEmpty(pathBase))
            {
                loggerFactory.CreateLogger<Startup>().LogDebug("Using PATH BASE '{pathBase}'", pathBase);
                app.UsePathBase(pathBase);
            }
            app.UseSwagger()
                .UseSwaggerUI(c =>
                {
                    c.SwaggerEndpoint($"{ (!string.IsNullOrEmpty(pathBase) ? pathBase : string.Empty) }/swagger/v1/swagger.json", "BoomiWrapper V1");
                });
            app.UseAllElasticApm(Configuration);
            app.UseRouting();
            app.UseCors("CorsPolicy");
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapDefaultControllerRoute();
                endpoints.MapControllers();
                endpoints.MapHealthChecks("/hc", new HealthCheckOptions()
                {
                    Predicate = _ => true,
                    ResponseWriter = UIResponseWriter.WriteHealthCheckUIResponse
                });
                endpoints.MapHealthChecks("/liveness", new HealthCheckOptions
                {
                    Predicate = r => r.Name.Contains("self")
                });
            });
            ConfigureEventBus(app);
        }
        private Serilog.ILogger GetElasticLogger()
        {
            return new LoggerConfiguration()
            .MinimumLevel.Override("Microsoft.EntityFrameworkCore.Database.Command", Serilog.Events.LogEventLevel.Warning)
            .Enrich.WithProperty("Application", Program.AppName)
            .Enrich.FromLogContext()
            //.Enrich.WithExceptionDetails()
            .Enrich.WithExceptionDetails(new DestructuringOptionsBuilder()
            .WithDefaultDestructurers()
            .WithDestructurers(new[] { new DbUpdateExceptionDestructurer() }))
            .Enrich.With(new ThreadIdEnricher())
            .Enrich.WithMachineName()
            .WriteTo.Console()
            .WriteTo.Debug()
            .Enrich.WithProperty("Environment", $"{Configuration["ASPNETCORE_ENVIRONMENT"]}")
            .WriteTo.Elasticsearch(ConfigureElasticSink()).CreateLogger();
        }
        private ElasticsearchSinkOptions ConfigureElasticSink()
        {
            return new ElasticsearchSinkOptions(new Uri(Configuration["ElasticSearchUrl"]))
            {
                ModifyConnectionSettings = x => x.BasicAuthentication(Configuration["ElasticSearchUserName"], Configuration["ElasticSearchPassword"]),
                AutoRegisterTemplate = true,
                AutoRegisterTemplateVersion = AutoRegisterTemplateVersion.ESv6,
                IndexFormat = Configuration["ElasticSearchIndex"]
            };
        }
        private void ConfigureEventBus(IApplicationBuilder app)
        {
            var eventBus = app.ApplicationServices.GetRequiredService<IIntegrationEventBus>();
            eventBus.SubscribeWithoutStart<GenerateBatchNextNumber, GenerateBatchNextNumberHandler>();
            eventBus.SubscribeWithoutStart<ProcessAddInventoryItemsInErp, ProcessAddInventoryItemsInErpHandler>();
            eventBus.SubscribeWithoutStart<ProcessUpdateInventoryItemsInErp, ProcessUpdateInventoryItemsInErpHandler>();
            eventBus.SubscribeWithoutStart<ProcessDeleteInventoryItemsInErp, ProcessDeleteInventoryItemsInErpHandler>();
            eventBus.SubscribeWithoutStart<ResubmitErpItemToBoomi, ResubmitErpItemToBoomiHandler>();

            // Ready to consume events
            eventBus.StartBasicConsume();
        }
    }
}
