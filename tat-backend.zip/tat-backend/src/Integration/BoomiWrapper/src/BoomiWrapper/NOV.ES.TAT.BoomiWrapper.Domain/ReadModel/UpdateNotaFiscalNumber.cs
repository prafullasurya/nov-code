﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NOV.ES.TAT.BoomiWrapper.Domain.ReadModel
{    
        public class UpdateNotaFiscalNumber
        {
            public int CustomerTransferSlipId { get; set; }
            public int CustomerTransferNumber { get; set; }
            public string OtherDocNumber { get; set; }
            public string OtherDocInfo { get; set; }
            public string OrderType { get; set; }
    }
}
