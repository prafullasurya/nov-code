﻿using Newtonsoft.Json;
using NOV.ES.Framework.Core.Messaging.IntegrationEvents;
using NOV.ES.Framework.Core.Sagas;
using NOV.ES.TAT.BoomiWrapper.API.Application.IntegrationEvents.PublishEvents;
using NOV.ES.TAT.BoomiWrapper.Domain;
using NOV.ES.TAT.BoomiWrapper.Domain.WriteModels;
using NOV.ES.TAT.BoomiWrapper.DomainService;
using NOV.ES.TAT.BoomiWrapper.DomainService.RequestModel;
using NOV.ES.TAT.BoomiWrapper.DomainService.ResponseModel;
using AutoMapper;

namespace NOV.ES.TAT.BoomiWrapper.API.Application.IntegrationEvents.SubscribedEvents
{
    public class GenerateInsertEDIGLHandler
        : IIntegrationEventHandler<GenerateInsertEDIGL>
    {
        private ILogger<GenerateBatchNextNumberHandler> logger;
        private readonly IBoomiWrapperService boomiWrapperService;
        private readonly IIntegrationEventBus integrationEventBus;
        private readonly IMapper mapper;

        public GenerateInsertEDIGLHandler(
            ILogger<GenerateBatchNextNumberHandler> logger,
            IBoomiWrapperService boomiWrapperService,
            IIntegrationEventBus integrationEventBus,
            IMapper mapper)
        {
            this.logger = logger;
            this.boomiWrapperService = boomiWrapperService;
            this.integrationEventBus = integrationEventBus;
            this.mapper = mapper;
        }

        public Task Handle(GenerateInsertEDIGL @event)
        {
            logger.LogInformation("----- Consuming Event: Generate Insert EDIGL Integration Event");
            logger.LogInformation("----- CorelationId is {id}", @event.CorelationId);
            logger.LogInformation("----- Event Detail is {info}", @event.JsonStringData);

            BoomiRequestResponse boomiRequestResponse;
            //1.Generate request for boomi 
            InsertEDIGLRequest insertEDIGLRequest = GenerateRequestPayload(@event.CorelationId, @event.ActionBy, @event.JsonStringData, out boomiRequestResponse);

            //2.Record request in database
            boomiWrapperService.RecordRequestPayload(boomiRequestResponse);

            //3. Boomi Call
            InsertEDIGLResponse insertEDIGLResponse = boomiWrapperService.InsertEDIGL(insertEDIGLRequest).Result;

            //4. Record Response
            boomiRequestResponse.Status = BoomiResponseType.Success.ToString();
            boomiRequestResponse.ResponseStatus = insertEDIGLResponse.Success;
            boomiRequestResponse.RequestDateTime = DateTime.UtcNow;
            boomiRequestResponse.ResponseBody = JsonConvert.SerializeObject(insertEDIGLResponse);
            if (insertEDIGLResponse.Errors != null && insertEDIGLResponse.Errors.Any())
            {
                boomiRequestResponse.ErrorMessage = JsonConvert.SerializeObject(insertEDIGLResponse.Errors);
                boomiRequestResponse.Status = BoomiResponseType.Failed.ToString();
            }

            boomiWrapperService.RecordResponse(boomiRequestResponse);

            //5.Generate response for publish event
            var result = GenerateResponseForPublishEvent(insertEDIGLResponse);

            //6.publish event
            GeneratedInsertEDIGL success =
            new(
                boomiRequestResponse.RequestId.ToString(),
                @event.CorelationId,
                JsonConvert.SerializeObject(result), 
                DateTime.UtcNow,
                SagaEventExecutionResult.Success,
                @event.ActionBy
                );

            logger.LogInformation("Publish Generated Insert EDIGL event  - GeneratedInsertEDIGL.");
            integrationEventBus.Publish(success);

            return Task.CompletedTask;

        }

        private InsertEDIGLRequest GenerateRequestPayload(Guid corelationId, string actionBy, string jsonStringData, out BoomiRequestResponse boomiRequestResponse)
        {
            var generateInsertEDIGLRequest = JsonConvert.DeserializeObject<GenerateInsertEDIGLRequest>(jsonStringData);
            var insertEDIGLRequest = mapper.Map<GenerateInsertEDIGLRequest, InsertEDIGLRequest>(generateInsertEDIGLRequest);
            boomiRequestResponse = new BoomiRequestResponse()
            {
                RequestId = generateInsertEDIGLRequest.RequestId,
                CorelationId = corelationId,
                EventId = generateInsertEDIGLRequest.EventId,
                KeyName = generateInsertEDIGLRequest.KeyName,
                KeyValue = generateInsertEDIGLRequest.KeyValue,
                RequestDateTime = DateTime.UtcNow,
                RequestStatus = BoomiResponseType.Success.ToString(),
                RequestBody = JsonConvert.SerializeObject(insertEDIGLRequest),
                RequestURL = "inBatchNumber/InsertEDIGL",
                RequestMethod = "InsertEDIGL",
                HttpVerb = "Post",
                ActionBy = actionBy
            };
           
            return insertEDIGLRequest;
        }

        private static int GenerateResponseForPublishEvent(InsertEDIGLResponse insertEDIGLResponse)
        {
            return insertEDIGLResponse.Success == "1" ? 0 :1 ;
        }
    }
}

