﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NOV.ES.TAT.BoomiWrapper.Domain
{
    [Table("RemitoCompanyInterfaceMapping")]
    public class RemitoCompanyInterfaceMapping
    {
        public int Id { get; set; }
        [MaxLength(28)]
        public string Company { get; set; }
        [MaxLength(200)]
        public string InterfaceName { get; set; }
        [MaxLength(200)]
        public string LastUdatedBy { get; set; }
        public DateTime DateCreated { get; set; }
        public DateTime DateModified { get; set; }
    }
}
