﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetSystemStatusReasonBySystemStatusIdHandler : IQueryHandler<GetSystemStatusReasonBySystemStatusIdQuery, IEnumerable<SystemStatusReasonDto>>
    {
        private readonly IMapper mapper;
        private readonly ISystemStatusReasonService systemStatusReasonService;

        public GetSystemStatusReasonBySystemStatusIdHandler(
            IMapper mapper,
            ISystemStatusReasonService systemStatusReasonService)
        {
            this.mapper = mapper;
            this.systemStatusReasonService = systemStatusReasonService;
        }

        public Task<IEnumerable<SystemStatusReasonDto>> Handle(GetSystemStatusReasonBySystemStatusIdQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var systemStatusReasons = systemStatusReasonService.GetSystemStatusReasonsBySystemStatusId(request.SystemStatusId);
            var result = mapper.Map<IEnumerable<SystemStatusReason>, IEnumerable<SystemStatusReasonDto>>(systemStatusReasons);
            return Task.FromResult(result);
        }
        private static bool IsValidRequest(GetSystemStatusReasonBySystemStatusIdQuery request)
        {
            return (request != null);
        }
    }
}