﻿using Newtonsoft.Json;
using NOV.ES.Framework.Core.Messaging.IntegrationEvents;
using NOV.ES.Framework.Core.Sagas;
using NOV.ES.TAT.BoomiWrapper.API.Application.IntegrationEvents.PublishEvents;
using NOV.ES.TAT.BoomiWrapper.Domain;
using NOV.ES.TAT.BoomiWrapper.Domain.WriteModels;
using NOV.ES.TAT.BoomiWrapper.DomainService;
using NOV.ES.TAT.BoomiWrapper.DomainService.RequestModel;
using NOV.ES.TAT.BoomiWrapper.DomainService.ResponseModel;
using AutoMapper;

namespace NOV.ES.TAT.BoomiWrapper.API.Application.IntegrationEvents.SubscribedEvents
{
    public class GenerateCreateSalesOrderHandler
        : IIntegrationEventHandler<GenerateCreateSalesOrder>
    {
        private ILogger<GenerateCreateSalesOrderHandler> logger;
        private readonly IBoomiWrapperService boomiWrapperService;
        private readonly IIntegrationEventBus integrationEventBus;
        private readonly IMapper mapper;

        public GenerateCreateSalesOrderHandler(
            ILogger<GenerateCreateSalesOrderHandler> logger,
            IBoomiWrapperService boomiWrapperService,
            IIntegrationEventBus integrationEventBus,
            IMapper mapper)
        {
            this.logger = logger;
            this.boomiWrapperService = boomiWrapperService;
            this.integrationEventBus = integrationEventBus;
            this.mapper = mapper;
        }

        public Task Handle(GenerateCreateSalesOrder @event)
        {
            logger.LogInformation("----- Consuming Event: Generate Sales Order Integration Event");
            logger.LogInformation("----- CorelationId is {id}", @event.CorelationId);
            logger.LogInformation("----- Event Detail is {info}", @event.JsonStringData);

            /*BoomiRequestResponse boomiRequestResponse;
            //1.Generate request for boomi 
            CreateSalesOrderRequest createSalesOrderRequest = GenerateRequestPayload(@event.CorelationId, @event.ActionBy, @event.JsonStringData, out boomiRequestResponse);

            //2.Record request in database
            boomiWrapperService.RecordRequestPayload(boomiRequestResponse);

            //3. Boomi Call
            CreateSalesOrderResponse createSalesOrderResponse = boomiWrapperService.CreateSalesOrder(createSalesOrderRequest).Result;

            //4. Record Response
            boomiRequestResponse.Status = BoomiResponseType.Success.ToString();
            boomiRequestResponse.ResponseStatus = createSalesOrderResponse.Success;
            boomiRequestResponse.RequestDateTime = DateTime.UtcNow;
            boomiRequestResponse.ResponseBody = JsonConvert.SerializeObject(createSalesOrderResponse);
            if (createSalesOrderResponse.Errors != null && createSalesOrderResponse.Errors.Any())
            {
                boomiRequestResponse.ErrorMessage = JsonConvert.SerializeObject(createSalesOrderResponse.Errors);
                boomiRequestResponse.Status = BoomiResponseType.Failed.ToString();
            }

            boomiWrapperService.RecordResponse(boomiRequestResponse);

            //5.Generate response for publish event
            var result = GenerateResponseForPublishEvent(createSalesOrderResponse);

            //6.publish event
            GeneratedCreateSalesOrder success =
            new(
                boomiRequestResponse.RequestId,
                @event.CorelationId,
                JsonConvert.SerializeObject(result),
                DateTime.UtcNow,
                SagaEventExecutionResult.Success,
                @event.ActionBy
                );
           
            logger.LogInformation("Publish Generated Sales Order event  - GeneratedCreateSalesOrder.");
            integrationEventBus.Publish(success);
            */

            return Task.CompletedTask;

        }

        /*private CreateSalesOrderRequest GenerateRequestPayload(Guid corelationId, string actionBy, string jsonStringData, out BoomiRequestResponse boomiRequestResponse)
        {
            var generateCreateSalesOrderRequest = JsonConvert.DeserializeObject<GenerateCreateSalesOrderRequest>(jsonStringData);

            var createSalesOrderRequest = mapper.Map<GenerateCreateSalesOrderRequest, CreateSalesOrderRequest>(generateCreateSalesOrderRequest);
            boomiRequestResponse = new BoomiRequestResponse()
            {
                RequestId = generateCreateSalesOrderRequest.RequestId,
                CorelationId = corelationId,
                EventId = generateCreateSalesOrderRequest.EventId,
                KeyName = generateCreateSalesOrderRequest.KeyName,
                KeyValue = generateCreateSalesOrderRequest.KeyValue,
                RequestDateTime = DateTime.UtcNow,
                RequestStatus = BoomiResponseType.Success.ToString(),
                RequestBody = JsonConvert.SerializeObject(createSalesOrderRequest),
                RequestURL = "inSalesOrder/createsalesorder",
                RequestMethod = "createsalesorder",
                HttpVerb = "Post",
                ActionBy = actionBy
            };

            return createSalesOrderRequest;
        }*/

        private static int GenerateResponseForPublishEvent(CreateSalesOrderResponse createSalesOrderResponse)
        {
            return Convert.ToInt32(createSalesOrderResponse.OrderNumber);
        }
    }
}

