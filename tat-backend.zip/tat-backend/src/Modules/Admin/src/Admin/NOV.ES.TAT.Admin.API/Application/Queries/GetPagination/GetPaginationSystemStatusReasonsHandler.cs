﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.DomainService;
using NOV.ES.TAT.Admin.API.Helper;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetPaginationSystemStatusReasonsHandler : IQueryHandler<GetPaginationSystemStatusReasonsQuery, PagedResult<SystemStatusReasonDto>>
    {
        private readonly IMapper mapper;
        private readonly ISystemStatusReasonService systemStatusReasonService;
        private readonly IHttpContextAccessor httpContextAccessor;

        public GetPaginationSystemStatusReasonsHandler(
            IMapper mapper,
            ISystemStatusReasonService systemStatusReasonService,
            IHttpContextAccessor httpContextAccessor)
        {            
            this.mapper = mapper;
            this.systemStatusReasonService = systemStatusReasonService;
            this.httpContextAccessor = httpContextAccessor;
        }
        public Task<PagedResult<SystemStatusReasonDto>> Handle(GetPaginationSystemStatusReasonsQuery request,
            CancellationToken cancellationToken)
        {
            var systemStatusReasons = systemStatusReasonService.GetSystemStatusReasons(request.PagingParameters);
            var result = mapper.Map<PagedResult<SystemStatusReason>, PagedResult<SystemStatusReasonDto>>(systemStatusReasons);
            PagingHelper.AddPagingMetadata<SystemStatusReasonDto>(result, httpContextAccessor);
            return Task.FromResult(result);
        }
    }
}
