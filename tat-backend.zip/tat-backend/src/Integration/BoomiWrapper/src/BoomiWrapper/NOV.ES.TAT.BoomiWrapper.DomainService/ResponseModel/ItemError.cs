﻿namespace NOV.ES.TAT.BoomiWrapper.DomainService.ResponseModel
{
    public class ItemError
    {
        public string Error { get; set; }
    }
}
