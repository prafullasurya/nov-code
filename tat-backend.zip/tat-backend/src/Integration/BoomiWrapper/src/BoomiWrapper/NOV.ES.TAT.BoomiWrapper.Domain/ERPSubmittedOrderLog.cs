﻿using NOV.ES.Framework.Core.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NOV.ES.TAT.BoomiWrapper.Domain
{
    [Table("ERPSubmittedOrderLog")]
    public class ERPSubmittedOrderLog : BaseEntity<long>
    {
        public int OrderId { get; set; }
        public string OrderSource { get; set; }
        public bool IsOrderCompleted { get; set; }
    }
}
