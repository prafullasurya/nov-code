﻿namespace NOV.ES.TAT.BoomiWrapper.DomainService.ResponseModel
{
    public class BatchNextNumberResponse
    {
        public string Success { get; set; }
        public string ERPBatchNumber { get; set; }
        public List<ErpError> Errors { get; set; }
    }
}
