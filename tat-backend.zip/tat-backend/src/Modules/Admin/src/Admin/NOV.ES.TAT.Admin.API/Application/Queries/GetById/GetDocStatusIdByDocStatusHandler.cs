﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetDocStatusIdByDocStatusHandler : IQueryHandler<GetDocStatusIdByDocStatusQuery, int>
    {
        private readonly IDocStatusService docStatusService;

        public GetDocStatusIdByDocStatusHandler(IDocStatusService docStatusService)
        {
            this.docStatusService = docStatusService;
        }

        public Task<int> Handle(GetDocStatusIdByDocStatusQuery request, CancellationToken cancellationToken)
        {
            var docStatusId = docStatusService.GetDocStatusIdByDocStatus(request.DocStatus);
            return Task.FromResult(docStatusId);
        }
    }
}

