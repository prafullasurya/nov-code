import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { HttpUrlGenerator } from '@ngrx/data';


import { TreeNode } from 'primeng/api';

@Injectable({
  providedIn:'root'
})
export class NodeService {

    constructor(private http: HttpClient) { }        
    getFiles() {
      
      var paths = 'https://exampleapp.tatdev.nov.cloud/assets/files.json'            
      return this.http.get<any>(paths)
        .toPromise()
        .then(res => <TreeNode[]>res.data);
      }
  
      getLazyFiles() {
        var paths = 'https://exampleapp.tatdev.nov.cloud/assets/files.json'     
      return this.http.get<any>(paths)
        .toPromise()
        .then(res => <TreeNode[]>res.data);
      }
}