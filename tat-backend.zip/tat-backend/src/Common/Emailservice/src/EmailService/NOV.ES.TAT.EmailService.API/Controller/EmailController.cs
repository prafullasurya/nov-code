using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NOV.ES.TAT.Common.Exception;
using NOV.ES.TAT.EmailService.API.Dtos;
using System.Net;

namespace NOV.ES.TAT.EmailService.API
{
    [ApiController]
    [Route("api/[controller]")]
    public class EmailController : ControllerBase
    {

        private readonly IEmailBaseService emailBaseService;
        public EmailController(IEmailBaseService emailBaseService)
        {
            this.emailBaseService = emailBaseService;
        }

        /// <summary>
        /// This method returns service name.
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("ServiceName")]
        public IActionResult ServiceName()
        {
            return Ok("TAT Email Servie.");
        }


        /// <summary>
        /// This method creates RecordLog based on requested data.
        /// </summary>
        /// <param name = "RecordLog" > RecordLogCommand </ param >
        /// < returns > OK Result</returns>
        [HttpPost]
        [Route("SendMailWithAttachment")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(string), (int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public IActionResult SendMailWithAttachment([FromBody] EmailDto emailParam)
        {
            var result = emailBaseService.Notifiers(emailParam);
            return Ok(result.StatusCode);
        }

        [HttpPost]
        [Route("SendEmailNotification")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(string), (int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public IActionResult SendEmailNotification([FromBody] EmailFlieDto emailParam)
        {
            var result = emailBaseService.NotifiersWithFile(emailParam);
            return Ok(result.StatusCode);
        }
    }
}