﻿namespace NOV.ES.TAT.Common.Appnotification.Models
{
    public enum TaskStatus
    {
        NotStarted,
        Initiated,
        InProgress,
        Completed,
        Failed
    }
}
