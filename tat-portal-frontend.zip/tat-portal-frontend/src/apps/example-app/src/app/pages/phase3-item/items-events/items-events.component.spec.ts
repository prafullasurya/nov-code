import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ItemsEventsComponent } from './items-events.component';

describe('ItemsEventsComponent', () => {
  let component: ItemsEventsComponent;
  let fixture: ComponentFixture<ItemsEventsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ItemsEventsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ItemsEventsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
function beforeEach(arg0: () => void) {
  throw new Error('Function not implemented.');
}

