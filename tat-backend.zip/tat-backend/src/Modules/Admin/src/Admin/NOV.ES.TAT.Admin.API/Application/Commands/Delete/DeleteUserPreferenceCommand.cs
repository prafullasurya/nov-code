﻿using Microsoft.AspNetCore.Mvc;
using NOV.ES.Framework.Core.CQRS.Commands;

namespace NOV.ES.TAT.Admin.API.Application.Commands
{
    public class DeleteUserPreferenceCommand:ICommand<ContentResult>
    {
        public int Id { get; private set; }
        public DeleteUserPreferenceCommand(int id)
        {
            this.Id = id;
        }
    }
}
