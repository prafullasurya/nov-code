﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.DomainService;
using NOV.ES.TAT.Admin.API.Helper;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetPaginationLocationsHandler : IQueryHandler<GetPaginationLocationsQuery, PagedResult<LocationDto>>
    {
        private readonly IMapper mapper;
        private readonly ILocationService locationService;
        private readonly IHttpContextAccessor httpContextAccessor;

        public GetPaginationLocationsHandler(
            IMapper mapper,
            ILocationService locationService,
            IHttpContextAccessor httpContextAccessor)
        {
            this.mapper = mapper;
            this.locationService = locationService;
            this.httpContextAccessor = httpContextAccessor;
        }
        public Task<PagedResult<LocationDto>> Handle(GetPaginationLocationsQuery request,
            CancellationToken cancellationToken)
        {
            var locations = locationService.GetLocations(request.PagingParameters);
            var result = mapper.Map<PagedResult<Location>, PagedResult<LocationDto>>(locations);
            PagingHelper.AddPagingMetadata<LocationDto>(result,httpContextAccessor);
            return Task.FromResult(result);
        }
    }
}
