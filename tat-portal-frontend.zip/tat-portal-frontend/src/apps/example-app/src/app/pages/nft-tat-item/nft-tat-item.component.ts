import { Component} from '@angular/core';

interface City {
  name: string,
  code: string
}
@Component({
  selector: 'tat-portal-frontend-nft-tat-item',
  templateUrl: './nft-tat-item.component.html',
  styleUrls: ['./nft-tat-item.component.scss']
})
export class nftTatItemComponent {
  
  displayAddMiscReceiptItem: boolean;
  displayModal: boolean;
  displayCompleteFieldTransferSlip: boolean;
  displayonfirmAssemblyNft: boolean;
  displaySearchInventory: boolean;

  //Dialog
  showAddMiscReceiptItem() {
    this.displayAddMiscReceiptItem = true;//showAddMiscReceiptItem
  }

  //Data Validation Message
  showModalDialog() {
    this.displayModal = true;
  }

  showCompleteFieldTransferSlip() {
    this.displayCompleteFieldTransferSlip = true;
  }

  showConfirmAssemblyNftDialog() {
    this.displayonfirmAssemblyNft = true;
  } 

  showNftSearchinventoryDialog() {
    this.displaySearchInventory = true;
  } 


}
