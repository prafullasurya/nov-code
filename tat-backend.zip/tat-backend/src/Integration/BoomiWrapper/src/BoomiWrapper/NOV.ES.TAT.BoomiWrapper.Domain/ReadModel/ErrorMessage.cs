﻿using NOV.ES.TAT.BoomiWrapper.Domain.WriteModels;
namespace NOV.ES.TAT.BoomiWrapper.Domain.ReadModel
{
    public class ErrorMessage
    {
        public string PartNumber { get; set; }
        public int LineNumber { get; set; }
        public string Location { get; set; }
        public string ErrorMsg { get; set; }
        public string Resolution { get; set; }
    }
}
