﻿namespace NOV.ES.TAT.BoomiWrapper.DomainService.ResponseModel
{
    public class ItemAvailabilityResponseData
    {
        public string PartNumber { get; set; }
        public string Description { get; set; }
        public string BusinessUnit { get; set; }
        public string Location { get; set; }
        public string Zone { get; set; }
        public string LotNumber { get; set; }
        public string LotStatus { get; set; }
        public string HTS { get; set; }
        public string Cost { get; set; }
        public string ChPS { get; set; }
        public string DescriptionLine2 { get; set; }
        public string Quantity { get; set; }
    }
}
