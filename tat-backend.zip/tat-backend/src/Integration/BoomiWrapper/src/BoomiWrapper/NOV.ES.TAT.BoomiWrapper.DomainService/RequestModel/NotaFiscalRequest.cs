﻿using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace NOV.ES.TAT.BoomiWrapper.DomainService.RequestModel
{
    public class NotaFiscalRequest: BaseRequestModel
    {
        public double? NotaFiscalNumber { get; set; }
        public string NotaFiscalSeries { get; set; }
        public double? NextNumberRange { get; set; }
        public string DocumentType { get; set; }
       
         [JsonProperty("UKID")]
        public double? UKID { get; set; }
        [JsonProperty("SourceERP")]
        public string SourceErp { get; set; }
        [JsonProperty("SourceERPEnv")]
        public string SourceErpEnv { get; set; }
        public string lastUpdatedBy { get; set; }

    }
}
