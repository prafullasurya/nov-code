﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.API.Helper;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetSystemStatusesLookupDataHandler : IQueryHandler<GetSystemStatusesLookupDataQuery, PagedResult<LookupData>>
    {
        private readonly ISystemStatusService systemStatusService;
        private readonly IMapper mapper;
        private readonly IHttpContextAccessor httpContextAccessor;
        public GetSystemStatusesLookupDataHandler(ISystemStatusService systemStatusService
            , IMapper mapper
            , IHttpContextAccessor httpContextAccessor)
        {
            this.systemStatusService = systemStatusService;
            this.mapper = mapper;
            this.httpContextAccessor = httpContextAccessor;
        }
        public Task<PagedResult<LookupData>> Handle(GetSystemStatusesLookupDataQuery request, CancellationToken cancellationToken)
        {
            var result = systemStatusService.GetSystemStatuses(request.PagingParameters, request.FilterData, request.SearchText, request.IncludeInActive);
            var pagedResult = mapper.Map<PagedResult<SystemStatus>, PagedResult<LookupData>>(result);
            PagingHelper.AddPagingMetadata(pagedResult, httpContextAccessor);
            return Task.FromResult(pagedResult);
        }
    }
}
