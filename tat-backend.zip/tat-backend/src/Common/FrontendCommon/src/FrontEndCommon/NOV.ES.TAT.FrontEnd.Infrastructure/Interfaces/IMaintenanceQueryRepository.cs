﻿using NOV.ES.TAT.FrontEnd.Domain;
using NOV.ES.Framework.Core.Data.Repository;

namespace NOV.ES.TAT.FrontEnd.Infrastructure
{
    public interface IMaintenanceQueryRepository
        : IReadRepository<MaintenanceModel>
    {
        MaintenanceModel GetMaintenanceQueryRepository();
    }
}
