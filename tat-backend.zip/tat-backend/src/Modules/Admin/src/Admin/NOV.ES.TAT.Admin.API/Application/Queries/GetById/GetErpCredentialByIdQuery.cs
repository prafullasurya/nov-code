﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetErpCredentialByIdQuery : IQuery<ErpCredentialDto>
    {
        public int Id { get; private set; }

        public GetErpCredentialByIdQuery(int id)
        {
            this.Id = id;
        }
    }
}