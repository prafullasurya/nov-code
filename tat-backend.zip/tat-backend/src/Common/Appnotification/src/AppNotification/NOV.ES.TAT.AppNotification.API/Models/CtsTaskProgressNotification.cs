﻿namespace NOV.ES.TAT.AppNotification.API.Models
{
    public enum TaskStatus
    {
        NotStarted,
        Initiated,
        InProgress,
        Completed,
        Failed
    }
    public class CtsTaskProgressNotification
    {
        public string SlipId { get; set; }
        public string SlipNumber { get; set; }
        public string EventName { get; set; }
        public string TaskName { get; set; }
        public string TaskMessage { get; set; }
        public string ErrorMessage { get; set; }
        public DateTime TimeStampUtc { get; set; }
        public TaskStatus TaskStatus { get; set; }

        public CtsTaskProgressNotification(string id, string slipNumber, string eventName,
            string taskName, DateTime timeStampUtc, TaskStatus taskStatus,
            string taskMessage, string errorMessage = null)
        {
            SlipId = id;
            SlipNumber = slipNumber;
            this.EventName = eventName;
            this.TaskName = taskName;
            this.TimeStampUtc = timeStampUtc;
            this.TaskStatus = taskStatus;
            this.TaskMessage = taskMessage;
            this.ErrorMessage = errorMessage;
        }

    }
}
