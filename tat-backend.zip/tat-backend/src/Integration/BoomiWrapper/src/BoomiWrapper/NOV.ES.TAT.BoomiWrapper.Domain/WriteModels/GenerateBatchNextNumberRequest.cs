﻿namespace NOV.ES.TAT.BoomiWrapper.Domain.WriteModels
{
    public class GenerateBatchNextNumberRequest : BoomiRequestBaseModel
    {
    }
}
