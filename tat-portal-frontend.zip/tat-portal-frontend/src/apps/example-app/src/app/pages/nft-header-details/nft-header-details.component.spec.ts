import { ComponentFixture, TestBed } from '@angular/core/testing';

import { nftHeaderDetailsComponent } from './nft-header-details.component';

describe('nftHeaderDetailsComponent', () => {
  let component: nftHeaderDetailsComponent;
  let fixture: ComponentFixture<nftHeaderDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ nftHeaderDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(nftHeaderDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
