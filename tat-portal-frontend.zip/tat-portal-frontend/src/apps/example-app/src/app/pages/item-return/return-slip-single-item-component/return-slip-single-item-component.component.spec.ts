import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReturnSlipSingleItemComponent } from './return-slip-single-item-component.component';

describe('ReturnSlipSingleItemComponent', () => {
  let component: ReturnSlipSingleItemComponent;
  let fixture: ComponentFixture<ReturnSlipSingleItemComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReturnSlipSingleItemComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReturnSlipSingleItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
