﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetCompanyErpInfoByIdHandler : IQueryHandler<GetCompanyErpInfoByIdQuery, CompanyErpInfoDto>
    {
        private readonly IMapper mapper;
        private readonly ICompanyErpInfoService companyErpInfoService;

        public GetCompanyErpInfoByIdHandler(
            IMapper mapper,
            ICompanyErpInfoService companyErpInfoService)
        {
            this.mapper = mapper;
            this.companyErpInfoService = companyErpInfoService;
        }

        public Task<CompanyErpInfoDto> Handle(GetCompanyErpInfoByIdQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var companyErpInfo = companyErpInfoService.GetCompanyErpInfoById(request.Id);
            var result = mapper.Map<CompanyErpInfo, CompanyErpInfoDto>(companyErpInfo);
            return Task.FromResult(result);
        }
        private static bool IsValidRequest(GetCompanyErpInfoByIdQuery request)
        {
            return (request != null && request.Id != 0);
        }
    }
}