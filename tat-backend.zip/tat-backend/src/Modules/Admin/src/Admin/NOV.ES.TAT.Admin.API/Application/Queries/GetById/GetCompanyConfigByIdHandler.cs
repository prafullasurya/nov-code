﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetCompanyConfigByIdHandler : IQueryHandler<GetCompanyConfigByIdQuery, CompanyConfigDto>
    {
        private readonly IMapper mapper;
        private readonly ICompanyConfigService companyConfigService;

        public GetCompanyConfigByIdHandler(
            IMapper mapper,
            ICompanyConfigService companyConfigService)
        {
            this.mapper = mapper;
            this.companyConfigService = companyConfigService;
        }

        public Task<CompanyConfigDto> Handle(GetCompanyConfigByIdQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var companyConfig = companyConfigService.GetCompanyConfigById(request.Id);
            var result = mapper.Map<CompanyConfig, CompanyConfigDto>(companyConfig);
            return Task.FromResult(result);
        }
        private static bool IsValidRequest(GetCompanyConfigByIdQuery request)
        {
            return (request != null && request.Id != 0);
        }
    }
}