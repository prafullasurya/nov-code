﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetErpCredentialByIdHandler : IQueryHandler<GetErpCredentialByIdQuery, ErpCredentialDto>
    {
        private readonly IMapper mapper;
        private readonly IErpCredentialService erpCredentialService;

        public GetErpCredentialByIdHandler(
            IMapper mapper,
            IErpCredentialService erpCredentialService)
        {
            this.mapper = mapper;
            this.erpCredentialService = erpCredentialService;
        }

        public Task<ErpCredentialDto> Handle(GetErpCredentialByIdQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var erpCredential = erpCredentialService.GetErpCredentialById(request.Id);
            var result = mapper.Map<ErpCredential, ErpCredentialDto>(erpCredential);
            return Task.FromResult(result);
        }
        private static bool IsValidRequest(GetErpCredentialByIdQuery request)
        {
            return (request != null && request.Id != 0);
        }
    }
}