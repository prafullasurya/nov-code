import { Component } from '@angular/core';

@Component({
  selector: 'usage-listing-filter-chips',
  templateUrl: './usage-listing-filter-chips.component.html',
  styleUrls: ['./usage-listing-filter-chips.component.scss'],
})
export class UsageListingFilterChipsComponent {
  
}
