﻿namespace NOV.ES.TAT.BoomiWrapper.Domain.WriteModels
{
    public class GenerateItemMasterRequest : BoomiRequestBaseModel
    {
        public string PartNumber { get; set; }
    }
}
