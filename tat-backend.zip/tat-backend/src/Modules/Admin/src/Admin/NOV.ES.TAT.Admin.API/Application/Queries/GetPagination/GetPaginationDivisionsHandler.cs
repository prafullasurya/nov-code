﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetPaginationDivisionsHandler : IQueryHandler<GetPaginationDivisionsQuery, PagedResult<DivisionDto>>
    {
        private readonly IMapper mapper;
        private readonly IDivisionService divisionService;
        private readonly IHttpContextAccessor httpContextAccessor;

        public GetPaginationDivisionsHandler(
            IMapper mapper,
            IDivisionService divisionService,
            IHttpContextAccessor httpContextAccessor)
        {
            this.mapper = mapper;
            this.divisionService = divisionService;
            this.httpContextAccessor = httpContextAccessor;
        }
        public Task<PagedResult<DivisionDto>> Handle(GetPaginationDivisionsQuery request,
            CancellationToken cancellationToken)
        {
            var division = divisionService.GetDivisions(request.PagingParameters);
            var result = mapper.Map<PagedResult<Division>, PagedResult<DivisionDto>>(division);
            if (result.Paging != null)
            {
                httpContextAccessor.HttpContext.Response.Headers.Add("X-Paging-PageCount", result.TotalNumberOfPages.ToString());
                httpContextAccessor.HttpContext.Response.Headers.Add("X-Paging-TotalRecordCount", result.TotalNumberOfItems.ToString());
                httpContextAccessor.HttpContext.Response.Headers.Add("X-Paging-PageIndex", result.Paging.PageIndex.ToString());
                httpContextAccessor.HttpContext.Response.Headers.Add("X-Paging-PageSize", result.Paging.PageSize.ToString());
            }
            return Task.FromResult(result);
        }
    }
}
