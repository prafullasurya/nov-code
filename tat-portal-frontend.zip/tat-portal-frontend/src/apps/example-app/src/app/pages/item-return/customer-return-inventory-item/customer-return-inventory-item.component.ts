import { Component} from '@angular/core';

interface City {
  name: string,
  code: string
}
@Component({
  selector: 'customer-return-inventory-item',
  templateUrl: './customer-return-inventory-item.component.html',
  styleUrls: ['./customer-return-inventory-item.component.scss']
})
export class CustomerReturnInventoryItemComponent {


}
