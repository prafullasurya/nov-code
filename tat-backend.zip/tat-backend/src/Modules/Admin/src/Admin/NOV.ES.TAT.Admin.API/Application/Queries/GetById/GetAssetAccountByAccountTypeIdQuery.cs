﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetAssetAccountByAccountTypeIdQuery : IQuery<IEnumerable<AssetAccountDto>>
    {
        public int? AccountTypeId { get; private set; }

        public GetAssetAccountByAccountTypeIdQuery(int? accountTypeId)
        {
            this.AccountTypeId = accountTypeId;
        }
    }
}