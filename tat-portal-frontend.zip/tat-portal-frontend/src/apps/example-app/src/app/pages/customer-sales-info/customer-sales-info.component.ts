import { Component, OnInit } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { ThemeService } from '../../services/theme.service';

interface City {
  name: string,
  code: string
}

@Component({
  selector: 'tat-portal-frontend-customer-sales-info',
  templateUrl: './customer-sales-info.component.html',
  styleUrls: ['./customer-sales-info.component.scss']
})
export class CustomerSalesInfoComponent implements OnInit {

  cities: City[];
  selectedCity: City;
  date3: Date;
  items: MenuItem[];
  
  constructor(private themeService : ThemeService) { 
    
    this.cities = [
      {name: 'New York', code: 'NY'},
      {name: 'Rome', code: 'RM'},
      {name: 'London', code: 'LDN'},
      {name: 'Istanbul', code: 'IST'},
      {name: 'Paris', code: 'PRS'}
    ];

    this.selectedCity=this.cities[1];
  }

  changeTheme(theme: string) {
    this.themeService.switchTheme(theme);
  }
  
  ngOnInit() {
    this.items = [
      {
        label: 'Tool',
      },
      {
        label: 'Components',
      },
      {
        label: 'Usages',
        //icon: 'pi pi-fw pi-calendar',
      },
      {
        label: 'Customer Transfer',
      },
      {
        label: 'Mass Production',
      },
      {
        label: 'Tools Groupin',
      },
      {
        label: 'Job',
      },
      {
        label: 'Billing',
      },
      {
        label: 'History',
      },
      {
        label: 'Requisition Order',
      },
      {
        label: 'Replacement',
      },
      {
        label: 'Table Crud',
      },
      {
        label: 'Grid with Sub Grid',
      },
      {
        label: 'Table Recored',
      },
      {
        label: 'Common Control',
      },
    ];
  }
}
