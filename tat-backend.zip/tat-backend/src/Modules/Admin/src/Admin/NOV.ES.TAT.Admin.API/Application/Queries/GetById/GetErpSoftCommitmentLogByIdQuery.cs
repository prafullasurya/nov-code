﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetErpSoftCommitmentLogByIdQuery : IQuery<ErpSoftCommitmentLogDto>
    {
        public int Id { get; private set; }

        public GetErpSoftCommitmentLogByIdQuery(int id)
        {
            this.Id = id;
        }
    }
}