﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NOV.ES.TAT.BoomiWrapper.DomainService.ResponseModel
{
    public class NotaFiscalResponse
    {
       public int Status { get; set; }
       public string ErrorMessage { get; set; }
    }
}
