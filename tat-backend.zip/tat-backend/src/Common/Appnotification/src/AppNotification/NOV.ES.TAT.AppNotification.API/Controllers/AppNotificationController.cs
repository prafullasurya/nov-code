using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using NOV.ES.TAT.AppNotification.API.Models;
using NOV.ES.TAT.AppNotification.API.SignalRHub;
using NOV.ES.TAT.Common.Appnotification.Models;

namespace NOV.ES.TAT.AppNotification.API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class AppNotificationController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        private readonly ILogger<AppNotificationController> logger;

        private readonly IHubContext<TATAppNotificationHub, ITATAppNotificationHub> hubContext;


        public AppNotificationController(ILogger<AppNotificationController> logger,
            IHubContext<TATAppNotificationHub, ITATAppNotificationHub> hubContext)
        {
            this.logger = logger;
            this.hubContext = hubContext;
        }

        /// <summary>
        /// This method returns service name.
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("ServiceName")]
        public IActionResult ServiceName()
        {
            return Ok("TAT App Notification Service.");
        }

        [HttpPost]
        [Route("notificationtoall")]
        public async Task<ActionResult> BroadcastNotificationToAll([FromBody] NotificationToAll data)
        {
            if (data != null)
            {
                await hubContext.Clients.All.SendNotificationToAll(data);
            }

            return Ok();
        }

        [HttpPost]
        [Route("ctsprogress")]
        public async Task<ActionResult> PostCtsProgress([FromBody] CtsTaskProgressNotification data)
        {
            if (data != null)
            {
                await hubContext.Clients.Group(data.SlipId.ToString().ToLower())
                        .BroadcastCtsTaskProgress(data);
            }

            return Ok();
        }

        [HttpPost]
        [Route("BroadcastNotaFiscal/{targetAudienceType}/{targetAudience}")]
        public async Task<ActionResult> BroadcastNotaFiscal(int targetAudienceType, string targetAudience,[FromBody] BroadcastNotaFiscalNotification data)
        {
            if (data != null)
            {
                await hubContext.Clients.Group(data.SlipId.ToString().ToLower())
                        .BroadcastNotaFiscal(data);
            }

            return Ok();
        }
    }
}