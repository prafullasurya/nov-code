import { Component, OnInit } from '@angular/core';
import { ConfirmationService, MessageService } from 'primeng/api';


interface City {
  name: string,
  code: string
}
@Component({
  selector: 'usage-wellsite',
  templateUrl: './usage-wellsite.component.html',
  styleUrls: ['./usage-wellsite.component.scss']
})
export class UsageWellsiteComponent {

  displayUsageDate: boolean;
  displayAddWellSite: boolean;
  displayEditWellSite: boolean;
  displayEditUsageWellSite: boolean;
  displayEditUsageWellSite2: boolean;
  displayEditUsageWellSite3: boolean;
  displayFieldAnalysisTable: boolean;
  displayWellSiteSelection: boolean;
  
  // activeIndex1: number = 0;

  // activeIndex2: number = 0;

  // scrollableTabs: any[] = Array.from({ length: 50 }, (_, i) => ({ title: `Tab ${i + 1}`, content: `Tab ${i + 1} Content` }));

  showUsageDate() {
    this.displayUsageDate =true;
  }
  showAddWellSite() {
    this.displayAddWellSite = true;
  }
  showEditWellSite() {
    this.displayEditWellSite = true;
  }
  showEditUsageWellSite() {
    this.displayEditUsageWellSite = true;
  }
  showEditUsageWellSite2() {
    this.displayEditUsageWellSite2 = true;
  }
  showEditUsageWellSite3() {
    this.displayEditUsageWellSite3 = true;
  }
  showFieldAnalysisTable() {
    this.displayFieldAnalysisTable = true;
  }
  showWellSiteSelection() {
    this.displayWellSiteSelection = true;
  }
}
