﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetAttributeSetupByIdHandler : IQueryHandler<GetAttributeSetupByIdQuery, AttributeSetupDto>
    {
        private readonly IMapper mapper;
        private readonly IAttributeSetupService attributeSetupService;

        public GetAttributeSetupByIdHandler(
            IMapper mapper,
            IAttributeSetupService attributeSetupService)
        {
            this.mapper = mapper;
            this.attributeSetupService = attributeSetupService;
        }

        public Task<AttributeSetupDto> Handle(GetAttributeSetupByIdQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var attributeSetup = attributeSetupService.GetAttributeSetupById(request.AttributeSetupId);
            return Task.FromResult(mapper.Map<AttributeSetup, AttributeSetupDto>(attributeSetup));
        }

        private static bool IsValidRequest(GetAttributeSetupByIdQuery request)
        {
            return (request != null && request.AttributeSetupId != 0);
        }
    }
}
