import { Component, OnInit } from '@angular/core';
import {MenuItem, SortEvent} from 'primeng/api';
import {SelectItem} from 'primeng/api';
import {SelectItemGroup} from 'primeng/api';
import { Product } from '../../models/product';
import { ProductService } from '../../models/productservice';

interface City {
  name: string,
  code: string,
  namelist: string
}
@Component({
  selector: 'tat-portal-frontend-cts-line-item-details',
  templateUrl: './cts-line-item-details.component.html',
  styleUrls: ['./cts-line-item-details.component.scss']
})
export class CtsLineItemDetailsComponent implements OnInit {


  cities: City[];
  selectedCountry: string;
  countries: any[];
  items: SelectItem[];
  item: string;
  products1: Product[];
  products: Product[];
  completeCustomerTransferSlipDisplay: boolean;
  primengConfig: any;
  selectedCity: City;
  
    ngOnInit(...args: []) {
      this.primengConfig.ripple = true;
    }
  
    completeCustomerTransferSlipDialog(...args: []) {
      this.completeCustomerTransferSlipDisplay = true;
    }
}
