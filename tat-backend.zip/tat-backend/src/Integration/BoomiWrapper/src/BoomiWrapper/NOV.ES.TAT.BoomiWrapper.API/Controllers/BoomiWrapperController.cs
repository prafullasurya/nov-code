﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using NOV.ES.TAT.BoomiWrapper.Domain;
using NOV.ES.TAT.BoomiWrapper.Domain.ReadModel;
using NOV.ES.TAT.BoomiWrapper.Domain.WriteModels;
using NOV.ES.TAT.BoomiWrapper.DomainService;
using NOV.ES.TAT.BoomiWrapper.DomainService.RequestModel;
using NOV.ES.TAT.BoomiWrapper.DomainService.ResponseModel;
using NOV.ES.TAT.Common.Exception;
using System.Net;
using System.Net.Mime;

namespace NOV.ES.TAT.BoomiWrapper.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BoomiWrapperController : ControllerBase
    {
        private readonly IBoomiWrapperService boomiWrapperService;
        private readonly ILogger<BoomiWrapperController> logger;
        private readonly IInventoryItemsService inventoryItemsService;
        public BoomiWrapperController(IBoomiWrapperService boomiWrapperService, ILogger<BoomiWrapperController> logger,IInventoryItemsService inventoryItemsService)
        {
            this.boomiWrapperService = boomiWrapperService;
            this.logger= logger;
            this.inventoryItemsService = inventoryItemsService;
        }

        /// <summary>
        /// This method returns service name.
        /// </summary>
        /// <returns>ServiceName</returns>
        [HttpGet]
        [Route("ServiceName")]
        public IActionResult ServiceName()
        {
            return Ok("Boomi Wrapper API.");
        }

        [HttpPost]
        [Route("BatchNextNumber")]
        [ProducesResponseType(typeof(BatchNextNumberResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public ActionResult<BatchNextNumberResponse> GetBatchNextNumber(GenerateBatchNextNumberRequest generateBatchNextNumberRequest)
        {
            return Ok(boomiWrapperService.GetBatchNextNumber(generateBatchNextNumberRequest).Result);
        }

        [HttpPost]
        [Route("Remito")]
        [ProducesResponseType(typeof(RemitoResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public ActionResult<RemitoResponse> GenerateRemito([FromBody] GenerateRemitoRequest generateRemitoRequest)
        {
            return Ok(boomiWrapperService.GenerateRemito(generateRemitoRequest).Result);
        }

        [HttpPost]
        [Route("CreateSalesOrder")]
        [ProducesResponseType(typeof(CreateSalesOrderResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public ActionResult<CreateSalesOrderResponse> CreateSalesOrder([FromBody] GenerateCreateSalesOrderRequest createSalesOrderRequest)
        {
            return Ok(boomiWrapperService.CreateSalesOrder(createSalesOrderRequest).Result);
        }

        [HttpPost]
        [Route("InsertEDIGL")]
        [ProducesResponseType(typeof(InsertEDIGLResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public ActionResult<InsertEDIGLResponse> InsertEDIGL(InsertEDIGLRequest insertEDIGLRequest)
        {
            return Ok(boomiWrapperService.InsertEDIGL(insertEDIGLRequest).Result);
        }

        [HttpPost]
        [Route("CreateJob")]
        [ProducesResponseType(typeof(JobCreationResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public ActionResult<JobCreationResponse> CreateJob(GenerateJobCreationRequest generateJobCreationRequest)
        {
            return Ok(boomiWrapperService.CreateJob(generateJobCreationRequest).Result);
        }

        [HttpPost]
        [Route("ItemAvailability")]
        [ProducesResponseType(typeof(ItemAvailabilityResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public ActionResult<ItemAvailabilityResponse> GetItemAvailability(ItemAvailabilityRequest itemAvailabilityRequest)
        {
            return Ok(boomiWrapperService.GetItemAvailability(itemAvailabilityRequest).Result);
        }

        [HttpPost]
        [Route("GetSalesOrderStatus")]
        [ProducesResponseType(typeof(SalesOrderStatusResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public ActionResult<SalesOrderStatusResponse> GetSalesOrderStatus(SalesOrderStatusRequest salesOrderStatusRequest)
        {
            return Ok(boomiWrapperService.GetSalesOrderStatus(salesOrderStatusRequest).Result);
        }

        [HttpPost]
        [Route("GetExchangeRate")]
        [ProducesResponseType(typeof(ExchangeRateResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public ActionResult<ExchangeRateResponse> GetExchangeRate(ExchangeRateRequest exchangeRateRequest)
        {
            return Ok(boomiWrapperService.GetExchangeRate(exchangeRateRequest).Result);
        }


        [HttpPost]
        [Route("InventoryAdjustment")]
        [ProducesResponseType(typeof(InventoryAdjustmentResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public ActionResult<InventoryAdjustmentResponse> InventoryAdjustment(InventoryAdjustmentRequest inventoryAdjustmentRequest)
        {
            return Ok(boomiWrapperService.InventoryAdjustment(inventoryAdjustmentRequest).Result);
        }

        [HttpPost]
        [Route("InventoryTransfer")]
        [ProducesResponseType(typeof(InventoryTransferResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public ActionResult<InventoryTransferResponse> InventoryTranfer(GenerateInventoryTransferRequest generateInventoryTransferRequest)
        {
            return Ok(boomiWrapperService.InventoryTransfer(generateInventoryTransferRequest).Result);
        }

        [HttpPost]
        [Route("CreateWorkOrder")]
        [ProducesResponseType(typeof(CreateWorkOrderResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public ActionResult<CreateWorkOrderResponse> CreateWorkOrder(CreateWorkOrderRequest createWorkOrderRequest)
        {
            return Ok(boomiWrapperService.CreateWorkOrder(createWorkOrderRequest).Result);
        }

        [HttpPost]
        [Route("GetInventoryExtract")]
        [ProducesResponseType(typeof(GetInventoryExtractResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public ActionResult<GetInventoryExtractResponse> GetInventoryExtract(GetInventoryExtractRequest getInventoryExtractRequest)
        {
            return Ok(boomiWrapperService.GetInventoryExtract(getInventoryExtractRequest).Result);
        }

        [HttpGet]
        [Route("EventInfo/{eventId:long}")]
        [ProducesResponseType(typeof(IEnumerable<BoomiRequestResponse>), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IAsyncEnumerable<BoomiRequestResponse>>> GetEventInfo([FromRoute] long eventId)
        {
            List<BoomiRequestResponse> result;
            result = await boomiWrapperService.GetEventInfo(eventId);

            if (result == null || !result.Any())
            {
                result = new List<BoomiRequestResponse>();
            }
            return Ok(result);
        }


        [HttpPost]
        [Route("ItemBranch")]
        [ProducesResponseType(typeof(ItemBranchResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public ActionResult<ItemBranchResponse> GetItemBranch(ItemBranchRequest itemBranchRequest)
        {
            return Ok(boomiWrapperService.GetItemBranch(itemBranchRequest).Result);
        }

        [HttpPost]
        [Route("ItemMaster")]
        [ProducesResponseType(typeof(ItemMasterResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public ActionResult<ItemBranchResponse> GetItemMaster(ItemMasterRequest itemMasterRequest)
        {
            return Ok(boomiWrapperService.GetItemMaster(itemMasterRequest).Result);
        }

        [HttpPost]
        [Route("GetJDEInventory")]
        [ProducesResponseType(typeof(ItemMasterResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public ActionResult<ItemBranchResponse> GetJDEInventory(GetJdeInventoryRequest getJdeInventoryRequest)
        {
            return Ok(boomiWrapperService.GetJdeInventory(getJdeInventoryRequest).Result);
        }

        [HttpPost]
        [Route("InventoryValidation")]
        [ProducesResponseType(typeof(ValidateInventoryResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public ActionResult<ValidateInventoryResponse> ValidateInventory(ValidateInventoryRequest validateInventoryRequest)
        {
            return Ok(boomiWrapperService.ValidateInventory(validateInventoryRequest).Result);
        }

        /// <summary>
        /// To update the nota fiscal
        /// </summary>
        /// <param name="notaFiscal"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("UpdateNotaFiscal")]
        [ProducesResponseType(typeof(NotaFiscalResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> UpdateNotaFiscal(NotaFiscalRequest notaFiscal)
        {
            logger.LogInformation($"Method:Post, Api:NotaFiscalRequest, RequestTime:{DateTime.UtcNow} RequestBody: {JsonConvert.SerializeObject(notaFiscal)}");

            return await Task.FromResult(Ok(boomiWrapperService.UpdateNotfiscalInCDS(notaFiscal).Result));

        }

        [HttpPost]
        [Route("SaveTransferJDEItems")]
        [ProducesResponseType(typeof(InventoryTransferResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public ActionResult<InventoryTransferResponse> SaveTransferJDEItems(CustomerTransferSlip customerTransferSlip)
        {
            var inventoryItems = customerTransferSlip.CustomerTransferSlipDetails.Where(a =>
                        a.ItemType.Equals(ItemType.J.ToString()) && a.IsActive).OrderBy(x => x.UsageId).ToList();
            return Ok(boomiWrapperService.SaveTransferJDEItems(customerTransferSlip , inventoryItems));
        }

        [HttpPost]
        [Route("SaveAdjustmentJDEItems")]
        [ProducesResponseType(typeof(InventoryTransferResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public ActionResult<InventoryTransferResponse> SaveAdjustmentJDEItems(CustomerTransferSlip customerTransferSlip)
        {
            var inventoryItems = customerTransferSlip.CustomerTransferSlipDetails.Where(a =>
            a.ItemType.Equals(ItemType.J.ToString()) && a.IsActive).OrderBy(x => x.UsageId).ToList();
            return Ok(boomiWrapperService.SaveAdjustmentJDEItems(customerTransferSlip , inventoryItems));
        }

        [HttpPost]
        [Route("SaveAdjustmentNRJDEItems")]
        [ProducesResponseType(typeof(InventoryTransferResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public ActionResult<InventoryTransferResponse> SaveAdjustmentNRJDEItems(CustomerTransferSlip customerTransferSlip)
        {
            var inventoryItems = customerTransferSlip.CustomerTransferSlipDetails.Where(a =>
            a.ItemType.Equals(ItemType.J.ToString()) && a.IsActive).OrderBy(x => x.UsageId).ToList();
            return Ok(boomiWrapperService.SaveAdjustmentNRJDEItems(customerTransferSlip , inventoryItems));
        }

        [HttpPost]
        [Route("process/field-transfer/inventory/items")]
        [ProducesResponseType(typeof(FieldTransferSlip), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(object), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(FieldTransferSlip), (int)HttpStatusCode.InternalServerError)]
        public ActionResult ProcessFieldTransferInventoryItems(FieldTransferSlip fieldTransferSlip)
        {
            var result = inventoryItemsService.ProcessErpItemsForFieldTransfer(fieldTransferSlip);
            return new ContentResult(){ 
                Content = result.Item2 == HttpStatusCode.ExpectationFailed ? result.Item3 : JsonConvert.SerializeObject(result.Item1), 
                ContentType = result.Item2 == HttpStatusCode.ExpectationFailed ? MediaTypeNames.Text.Plain : MediaTypeNames.Application.Json,
                StatusCode = (int)result.Item2 
                };
        }

        [HttpPost]
        [Route("GetTransferMarkup")]
        [ProducesResponseType(typeof(GetTransferMarkupResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public ActionResult<GetTransferMarkupResponse> GetTransferMarkup(GetTransferMarkupRequest GetTransferMarkupRequest)
        {
            return Ok(boomiWrapperService.GetTransferMarkup(GetTransferMarkupRequest).Result);
        }

        /// <summary>
        /// To update the nota fiscal
        /// </summary>
        /// <param name="notaFiscal"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("NotaFiscalRefresh")]
        [ProducesResponseType(typeof(NotaFiscalResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> NotaFiscalRefresh(NotaFiscalRequest notaFiscal)
        {
            logger.LogInformation($"Method:Post, Api:NotaFiscalRefreshRequest, RequestTime:{DateTime.UtcNow} RequestBody: {JsonConvert.SerializeObject(notaFiscal)}");

            return await Task.FromResult(Ok(boomiWrapperService.UpdateNotafiscal(notaFiscal).Result));

        }
    }
}
