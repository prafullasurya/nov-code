﻿namespace NOV.ES.TAT.BoomiWrapper.DomainService.RequestModel
{
    public class SalesOrderStatusRequest: BaseRequestModel
    {
        public string SZUniqueOrderReferenceNumber { get; set; }
    }
}
