﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetLanguageByErpCodeHandler : IQueryHandler<GetLanguageByErpCodeQuery, LanguageDto>
    {
        private readonly IMapper mapper;
        private readonly ILanguageService languageService;

        public GetLanguageByErpCodeHandler(
            IMapper mapper,
            ILanguageService languageService)
        {
            this.mapper = mapper;
            this.languageService = languageService;
        }

        public Task<LanguageDto> Handle(GetLanguageByErpCodeQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var language = languageService.GetLanguageByErpCode(request.ErpLanguageCode);
            var result = mapper.Map<Language, LanguageDto>(language);
            return Task.FromResult(result);
        }
        private static bool IsValidRequest(GetLanguageByErpCodeQuery request)
        {
            return (request != null && request.ErpLanguageCode != string.Empty);
        }
    }
}