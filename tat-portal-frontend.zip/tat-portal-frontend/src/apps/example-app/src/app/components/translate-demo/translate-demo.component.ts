import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
@Component({
  selector: 'tat-portal-frontend-translate-demo',
  templateUrl: './translate-demo.component.html',
  styleUrls: ['./translate-demo.component.scss']
})
export class TranslateDemoComponent implements OnInit {
  title = 'angular-phrase-example';
  constructor(public translate: TranslateService) {
    //translateService.setDefaultLang('en');
    //translate.setDefaultLang('en-US.json');
  }

  ngOnInit(): void {
  }
  public selectLanguage(event: any) {
    this.translate.use(event.target.value);
  }

}
