import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { RemoteEntryComponent } from './entry.component';
import { CoreModule } from '@tat/core';
import { SharedUtilAuthenticationModule } from '@tat/shared/util-authentication';
import { SharedUtilErrorLoggingModule } from '@tat/shared/util-error-logging';
import { SharedFeatureHeaderModule } from '@tat/shared/feature-header';
import { UserDashboardComponent } from '../components/user-dashboard/user-dashboard.component'

@NgModule({
  declarations: [
    RemoteEntryComponent,
    UserDashboardComponent,
  ],
  imports: [
    CommonModule,
    CoreModule,
    RouterModule.forChild([
      {
        path: '',
        component: RemoteEntryComponent,
      },
    ]),

    SharedUtilAuthenticationModule,
    SharedUtilErrorLoggingModule,
    SharedFeatureHeaderModule,
  ],
  providers: [],
})
export class RemoteEntryModule {}
