﻿using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using NOV.ES.Framework.Core.Data;
using NOV.ES.TAT.BoomiWrapper.Domain;

namespace NOV.ES.TAT.BoomiWrapper.Infrastructure
{
    public class InterfaceDBContext : BaseContext
    {
        public InterfaceDBContext(DbContextOptions<InterfaceDBContext> dbContextOptions, IHttpContextAccessor httpContextAccessor)
            : base(dbContextOptions)
        {
            UserProvider = "tat.system@nov.com";

            if (httpContextAccessor != null && httpContextAccessor.HttpContext != null)
            {
                IIdentityService identityService = new IdentityService(httpContextAccessor);
                UserProvider = identityService.GetUserName();
            }
        }
        public virtual DbSet<BoomiRequestResponse> BoomiRequestResponses { get; set; }
        public virtual DbSet<ErpItemsBatch> ErpItemsBatches { get; set; }
        public virtual DbSet<ErpSoftCommitmentLog> ErpSoftCommitmentLogs { get; set; }
        public virtual DbSet<RemitoCompanyInterfaceMapping> RemitoCompanyInterfaceMappings { get; set; }
        public virtual DbSet<ERPSubmittedOrderLog> ERPSubmittedOrderLog { get; set; }

    }
}
