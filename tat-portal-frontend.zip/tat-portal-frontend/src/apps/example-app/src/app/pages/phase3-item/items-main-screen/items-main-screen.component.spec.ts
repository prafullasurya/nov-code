import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ItemsMainScreenComponent } from './items-main-screen.component';

describe('ItemsMainScreenComponent', () => {
  let component: ItemsMainScreenComponent;
  let fixture: ComponentFixture<ItemsMainScreenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ItemsMainScreenComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ItemsMainScreenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
function beforeEach(arg0: () => void) {
  throw new Error('Function not implemented.');
}

