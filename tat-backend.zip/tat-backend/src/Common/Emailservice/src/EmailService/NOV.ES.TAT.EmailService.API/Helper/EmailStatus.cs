﻿namespace NOV.ES.TAT.EmailService.Helper
{
    public class EmailStatus
    {
        public int StatusCode { get; set; }
        public string? Message { get; set; }
    }
}
