﻿namespace NOV.ES.TAT.BoomiWrapper.Domain.WriteModels
{
    public class BoomiRequestBaseModel
    {
        public Guid CorelationId { get; set; }
        public Guid RequestId { get; set; }
        public long? EventId { get; set; }
        public string KeyName { get; set; }
        public string KeyValue { get; set; }
        public string ActionBy { get; set; }
        public string ErpType { get; set; }
        public string erpUserId { get; set; }
        public string TargetERP { get; set; } = "JDE";
        public string Source { get; set; } = "TAT";
    }

    public enum BoomiResponseType
    {
        Failed,
        Success
    }
}
