import { Component } from '@angular/core';


@Component({
  selector: 'tat-portal-frontend-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {
  title = 'dashboard';
}
