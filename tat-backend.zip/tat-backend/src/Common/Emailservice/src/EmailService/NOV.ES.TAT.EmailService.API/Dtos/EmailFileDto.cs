﻿using NOV.ES.TAT.EmailService.Helper;
using System.Data;

namespace NOV.ES.TAT.EmailService.API.Dtos
{
    public class EmailFlieDto : EmailDto
    {       
        public string? XmlFilePath { get; set; }
        public string XmlDataSet { get; set; }
        public List<EmailAttributes> AttributeList { get; set; }

    }
}
