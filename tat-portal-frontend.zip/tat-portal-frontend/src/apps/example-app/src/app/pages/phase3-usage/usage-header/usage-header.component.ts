import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'usage-header',
  templateUrl: './usage-header.component.html',
  styleUrls: ['./usage-header.component.scss'],
})
export class UsageHeaderComponent {
  toggleMenu =true;
  
  toggleSideMenu(){
    if(!this.toggleMenu){
      document.getElementById("mySidenav").style.width = "330px";
    }else{
      document.getElementById("mySidenav").style.width = "75px";
    }
    this.toggleMenu = !this.toggleMenu;
  }
}
