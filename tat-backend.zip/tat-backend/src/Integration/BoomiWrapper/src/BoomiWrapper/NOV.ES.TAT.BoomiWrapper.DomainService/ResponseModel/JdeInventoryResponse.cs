﻿namespace NOV.ES.TAT.BoomiWrapper.DomainService.ResponseModel
{
    public class JdeInventoryResponse
    {
        public string Success { get; set; }
        public List<ErpError> Errors { get; set; }
        public List<JdeInventory> Data { get; set; }
    }

    public class JdeInventory
    {
        public string PartNumber { get; set; }
        public string BusinessUnit { get; set; }
        public string Location { get; set; }
        public string SerialNumber { get; set; }
        public string ReferenceNumber { get; set; }
        public string QuantityAvailable { get; set; }
    }
}
