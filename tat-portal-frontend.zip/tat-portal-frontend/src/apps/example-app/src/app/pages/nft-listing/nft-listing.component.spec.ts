import { ComponentFixture, TestBed } from '@angular/core/testing';

import { nftListingComponent } from './nft-listing.component';

describe('nftListingComponent', () => {
  let component: nftListingComponent;
  let fixture: ComponentFixture<nftListingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ nftListingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(nftListingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
function beforeEach(arg0: () => void) {
  throw new Error('Function not implemented.');
}

