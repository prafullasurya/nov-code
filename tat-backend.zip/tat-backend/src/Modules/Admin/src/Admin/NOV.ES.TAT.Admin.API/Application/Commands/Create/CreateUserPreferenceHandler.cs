﻿using AutoMapper;
using FluentValidation.Results;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using NOV.ES.Framework.Core.CQRS.Commands;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.API.Validators;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;
using System.Net;
using System.Net.Mime;

namespace NOV.ES.TAT.Admin.API.Application.Commands
{
    public class CreateUserPreferenceHandler : ICommandHandler<CreateUserPreferenceCommand, ContentResult>
    {
        private readonly IMapper mapper;
        private readonly IUserPreferenceService userPreferenceService;

        public CreateUserPreferenceHandler(
            IMapper mapper,
            IUserPreferenceService userPreferenceService)
        {            
            this.mapper = mapper;
            this.userPreferenceService = userPreferenceService;
        }
        public Task<ContentResult> Handle(CreateUserPreferenceCommand request, CancellationToken cancellationToken)
        {
            ContentResult contentResult = new()
            {
                ContentType = MediaTypeNames.Application.Json
            };

            ValidationResult validationResult = new UserPreferenceValidator().Validate(request);
            if (!validationResult.IsValid)
            {
                contentResult.Content = JsonConvert.SerializeObject(validationResult.Errors);
                contentResult.StatusCode = (int)HttpStatusCode.BadRequest;
                return Task.FromResult(contentResult);
            }
            if(userPreferenceService.IsFilterNameExist(request.UserPreferenceDto.FilterName, request.UserPreferenceDto.UserId, request.UserPreferenceDto.ModuleId))
            {
                contentResult.Content = JsonConvert.SerializeObject($"Search Name :{request.UserPreferenceDto.FilterName} already exists, please enter different Name");
                contentResult.StatusCode = (int)HttpStatusCode.BadRequest;
                return Task.FromResult(contentResult);
            }

            UserPreference userPreference = mapper.Map<UserPreferenceDto, UserPreference>(request.UserPreferenceDto);
            bool result = userPreferenceService.CreateUserPreference(userPreference);
            if (result)
                contentResult.StatusCode = (int)HttpStatusCode.OK;

            return Task.FromResult(contentResult);
        }
    }
}