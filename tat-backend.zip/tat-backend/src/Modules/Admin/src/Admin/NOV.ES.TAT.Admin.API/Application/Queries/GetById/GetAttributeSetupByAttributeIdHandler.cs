﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetAttributeSetupByAttributeIdHandler : IQueryHandler<GetAttributeSetupByAttributeIdQuery, AttributeSetupDto>
    {
        private readonly IMapper mapper;
        private readonly IAttributeSetupService attributeSetupService;

        public GetAttributeSetupByAttributeIdHandler(
            IMapper mapper,
            IAttributeSetupService attributeSetupService)
        {
            this.mapper = mapper;
            this.attributeSetupService = attributeSetupService;
        }

        public Task<AttributeSetupDto> Handle(GetAttributeSetupByAttributeIdQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var attributeSetup = attributeSetupService.GetAttributeSetupByAttributeId(request.AttributeId);
            return Task.FromResult(mapper.Map<AttributeSetup, AttributeSetupDto>(attributeSetup));
        }

        private static bool IsValidRequest(GetAttributeSetupByAttributeIdQuery request)
        {
            return (request != null && request.AttributeId != 0);
        }
    }
}
