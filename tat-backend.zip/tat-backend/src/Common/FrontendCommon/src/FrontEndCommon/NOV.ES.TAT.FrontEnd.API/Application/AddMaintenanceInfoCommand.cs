﻿using Microsoft.AspNetCore.Mvc;
using NOV.ES.Framework.Core.CQRS.Commands;
using NOV.ES.TAT.FrontEnd.Domain.WriteModels;

namespace NOV.ES.TAT.CustomerTransfer.EventSourcing.API.Application.Commands
{

    public class AddMaintenanceInfoCommand
    : AddMaintenanceModel, ICommand<ContentResult>
    {
        public AddMaintenanceInfoCommand()
        {
        }
    }
}
