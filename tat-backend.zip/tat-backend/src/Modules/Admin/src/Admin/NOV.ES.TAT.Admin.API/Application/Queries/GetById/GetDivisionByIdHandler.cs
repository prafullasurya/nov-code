﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetDivisionByIdQueryHandler : IQueryHandler<GetDivisionByIdQuery, DivisionDto>
    {
        private readonly IMapper mapper;
        private readonly IDivisionService divisionService;

        public GetDivisionByIdQueryHandler(
            IMapper mapper,
            IDivisionService divisionService)
        {
            this.mapper = mapper;
            this.divisionService = divisionService;
        }

        public Task<DivisionDto> Handle(GetDivisionByIdQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var division = divisionService.GetDivisionById(request.DivisionId);
            return Task.FromResult(mapper.Map<Division, DivisionDto>(division));
        }

        private static bool IsValidRequest(GetDivisionByIdQuery request)
        {
            return (request != null && request.DivisionId != 0);
        }
    }
}
