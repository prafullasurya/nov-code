﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetDefinedInputGroupSourceByIdQueryHandler : IQueryHandler<GetDefinedInputGroupSourceByIdQuery, DefinedInputGroupSourceDto>
    {
        private readonly IMapper mapper;
        private readonly IDefinedInputGroupSourceService definedInputGroupSourceService;

        public GetDefinedInputGroupSourceByIdQueryHandler(
            IMapper mapper,
            IDefinedInputGroupSourceService definedInputGroupSourceService)
        {
            this.mapper = mapper;
            this.definedInputGroupSourceService = definedInputGroupSourceService;
        }

        public Task<DefinedInputGroupSourceDto> Handle(GetDefinedInputGroupSourceByIdQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var definedInputGroupSource = definedInputGroupSourceService.GetDefinedInputGroupSourceById(request.DefinedInputGroupSourceId);
            return Task.FromResult(mapper.Map<DefinedInputGroupSource, DefinedInputGroupSourceDto>(definedInputGroupSource));
        }

        private static bool IsValidRequest(GetDefinedInputGroupSourceByIdQuery request)
        {
            return (request != null && request.DefinedInputGroupSourceId != 0);
        }
    }
}
