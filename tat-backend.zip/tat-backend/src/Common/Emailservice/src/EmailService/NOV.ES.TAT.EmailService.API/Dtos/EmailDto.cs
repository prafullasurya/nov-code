﻿using NOV.ES.TAT.EmailService.Helper;

namespace NOV.ES.TAT.EmailService.API.Dtos
{
    public class EmailDto
    {
        public List<string>? ToList { get; set; }
        public List<string>? CcList { get; set; }
        public List<string>? BccList { get; set; }
        public string? Subject { get; set; }
        public string? Body { get; set; }
        public string? FileName { get; set; }     
    }
}
