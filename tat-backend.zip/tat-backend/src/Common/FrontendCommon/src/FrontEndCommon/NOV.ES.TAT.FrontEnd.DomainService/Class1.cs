﻿namespace NOV.ES.TAT.FrontEnd.DomainService
{
    public class Class1
    {

    }
}