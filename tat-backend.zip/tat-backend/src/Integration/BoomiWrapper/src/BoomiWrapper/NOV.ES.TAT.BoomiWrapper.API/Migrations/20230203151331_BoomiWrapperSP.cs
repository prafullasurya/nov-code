﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace NOV.ES.TAT.BoomiWrapper.API.Migrations
{
    public partial class BoomiWrapperSP : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(
                @"CREATE OR ALTER  PROCEDURE [dbo].[uspCaptureERPSubmittedOrderLog] 
                                                     @OrderId INT
                                                    ,@OrderSource nvarchar(max)
                                                    ,@IsOrderCompleted int
					                                ,@IsActive int
					                                ,@DateCreated datetime2(7)
					                                ,@CreatedBy nvarchar(max)
                                                    AS
                                                    
                    INSERT INTO [dbo].[ERPSubmittedOrderLog]
                               ([OrderId]
                               ,[OrderSource]
                               ,[IsOrderCompleted]
                               ,[IsActive]
                               ,[DateCreated]
                               ,[CreatedBy])
                    VALUES
                           (@OrderId,
                           @OrderSource,
                           @IsOrderCompleted,
		                   @IsActive,
                           @DateCreated,
                           @CreatedBy
                           )

                    SELECT Id from [dbo].[ERPSubmittedOrderLog] where Id=SCOPE_IDENTITY() "
                );
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"DROP PROCEDURE [dbo].[uspCaptureERPSubmittedOrderLog];");
        }
    }
}
