import { Component, OnInit } from '@angular/core';
import { ConfirmationService, MessageService } from 'primeng/api';
import { Product } from '../../../models/product';
import { ProductService } from '../../../models/productservice';


interface City {
  name: string,
  code: string
}
@Component({
  selector: 'tems-header',
  templateUrl: './tems-header.component.html',
  styleUrls: ['./tems-header.component.scss']
})
export class ItemsHeaderComponent {
  toggleMenu =true;
  // activeIndex1: number = 0;

  // activeIndex2: number = 0;

  // scrollableTabs: any[] = Array.from({ length: 50 }, (_, i) => ({ title: `Tab ${i + 1}`, content: `Tab ${i + 1} Content` }));
  toggleSideMenu(){
    if(!this.toggleMenu){
      document.getElementById("mySidenav").style.width = "330px";
    }else{
      document.getElementById("mySidenav").style.width = "75px";
    }
    this.toggleMenu = !this.toggleMenu;
  }
}
