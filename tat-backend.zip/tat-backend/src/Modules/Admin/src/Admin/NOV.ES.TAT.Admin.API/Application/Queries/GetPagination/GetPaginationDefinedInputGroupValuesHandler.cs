﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.DomainService;
using NOV.ES.TAT.Admin.API.Helper;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetPaginationDefinedInputGroupValuesHandler : IQueryHandler<GetPaginationDefinedInputGroupValuesQuery, PagedResult<DefinedInputGroupValueDto>>
    {
        private readonly IMapper mapper;
        private readonly IDefinedInputGroupValueService definedInputGroupValueService;
        private readonly IHttpContextAccessor httpContextAccessor;

        public GetPaginationDefinedInputGroupValuesHandler(
            IMapper mapper,
            IDefinedInputGroupValueService definedInputGroupValueService,
            IHttpContextAccessor httpContextAccessor)
        {
            this.mapper = mapper;
            this.definedInputGroupValueService = definedInputGroupValueService;
            this.httpContextAccessor = httpContextAccessor;
        }
        public Task<PagedResult<DefinedInputGroupValueDto>> Handle(GetPaginationDefinedInputGroupValuesQuery request,
            CancellationToken cancellationToken)
        {
            var definedInputGroupValues = definedInputGroupValueService.GetDefinedInputGroupValues(request.PagingParameters);
            var result = mapper.Map<PagedResult<DefinedInputGroupValue>, PagedResult<DefinedInputGroupValueDto>>(definedInputGroupValues);
            PagingHelper.AddPagingMetadata<DefinedInputGroupValueDto>(result,httpContextAccessor);
            return Task.FromResult(result);
        }
    }
}
