﻿namespace NOV.ES.TAT.BoomiWrapper.DomainService.ResponseModel
{
    public class GetTransferMarkupResponse
    {
        public string Success { get; set; }
        public int factorValue { get; set; }
        public string SalesReportingCode2 { get; set; }
        public List<ErpError> Errors { get; set; }
    }
}
