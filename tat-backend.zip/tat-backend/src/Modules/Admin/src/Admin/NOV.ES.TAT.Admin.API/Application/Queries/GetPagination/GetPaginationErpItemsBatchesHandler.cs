﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.API.Helper;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetPaginationErpItemsBatchesHandler
           : IQueryHandler<GetPaginationErpItemsBatchesQuery, PagedResult<ErpItemsBatchDto>>
    {
        private readonly IMapper mapper;
        private readonly IErpItemsBatchService erpItemsBatchService;
        private readonly IHttpContextAccessor httpContextAccessor;

        public GetPaginationErpItemsBatchesHandler(
            IMapper mapper
            ,IErpItemsBatchService erpItemsBatchService
            , IHttpContextAccessor httpContextAccessor)
        {            
            this.mapper = mapper;
            this.erpItemsBatchService = erpItemsBatchService;
            this.httpContextAccessor = httpContextAccessor;
        }

        public Task<PagedResult<ErpItemsBatchDto>> Handle(GetPaginationErpItemsBatchesQuery request,
          CancellationToken cancellationToken)
        {
            var erpItemsBatches = erpItemsBatchService.GetErpItemsBatches(request.PagingParameters);
            var result = mapper.Map<PagedResult<ErpItemsBatch>, PagedResult<ErpItemsBatchDto>>(erpItemsBatches);
            PagingHelper.AddPagingMetadata<ErpItemsBatchDto>(result, httpContextAccessor);
            return Task.FromResult(result);
        }
    }
}