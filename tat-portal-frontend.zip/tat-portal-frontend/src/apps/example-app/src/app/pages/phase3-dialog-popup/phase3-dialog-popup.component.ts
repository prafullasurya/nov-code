import { Component, OnInit } from '@angular/core';
import { ConfirmationService, MessageService } from 'primeng/api';
import { Product } from '../../models/product';
import { ProductService } from '../../models/productservice';
import {FileUploadModule} from 'primeng/fileupload';
import {HttpClientModule} from '@angular/common/http';


interface City {
  name: string,
  code: string
}
@Component({
  selector: 'phase3-dialog-popup',
  templateUrl: './phase3-dialog-popup.component.html',
  styleUrls: ['./phase3-dialog-popup.component.scss']
})
export class phase3DialogPopupComponent {
  
  displayConfirmLihReversal: boolean;
  displayActiveDeactiveItem: boolean;
  displayItemDisposition: boolean;
  displayUndoItemDisposition: boolean;
  display2ActiveDeactiveItem: boolean;
  displayIntransitAcceptanceInfo: boolean;
  displayAddtoShipping: boolean;
  displayItemReturn: boolean;
  displayUndoReturn: boolean;
  displayCompleteRework: boolean;
  displayBypassService:boolean;
  displayCompleteFieldSevice: boolean;
  displayItemAttachmentDetails: boolean;
  displayOffRent: boolean;
  displayReserveDateSelection: boolean;
  displayServiceCostList: boolean;
  displayCapitalizeButton: boolean;
  displayActiveItem: boolean;
  displayUndoItemDispositiongrid: boolean;
  displayItemDispositiongrid: boolean;
  displayChangePartNumberGrid: boolean;
  displayDeactivateItem: boolean;
  displayInTransitAcceptance: boolean;
  displayAcceptFinancialResponsibility: boolean;
  displayReturnItem: boolean;
  displayBypassServiceGrid: boolean;
  displayCompleteService: boolean;
  displayCompletePreService: boolean;
  displayCompleteRefurbishment: boolean;
  displayCompleteFieldService: boolean;
  displayResumeService: boolean;
  displayResumePreService: boolean;
  displayResumeRefurbishment: boolean;
  displayResumeFieldServiceGrid: boolean;
  displayStartService: boolean;
  displayStartPreService: boolean;
  displayStartRefurbishment: boolean;
  displayStartFieldServiceGrid: boolean;
  displaySuspendService: boolean;
  displaySuspendPreService: boolean;
  displaySuspendRefurbishment: boolean;
  displaySuspendFieldServiceGrid: boolean;
  displayUndoCompleteService: boolean;
  displayUndoCompletePreService: boolean;
  displayUndoBypassService: boolean;
  displayUndoCompleteFieldService: boolean;
  displayUndoStartFieldServiceGrid: boolean;
  displayUndoStartRefurbishment: boolean;
  displayUndoStartPreService:boolean;
  displayUndoStartService:boolean;
  displayUsageLostInHole:boolean;
  displayCompleteItemRefubisment: boolean;
  displayConfirmSalesReversal: boolean;
  displayRemovefromSalesOrder: boolean;
  displayDeleteforItem: boolean;
  displayRemoveFromCustomerDeliverySlip: boolean;
  displayRemoveFromTransferSlip:boolean;
  displayUsageStartService: boolean;
  displayUsageSuspendService: boolean;
  displayUsageResumeService: boolean;
  displayUsageCompleteService: boolean;
  displayUsageUndoStartService: boolean;
  displayUsageUndoCompleteService: boolean;
  displayUsageStartFieldService: boolean;
  displayUsageSuspendFieldService: boolean;
  displayUsageResumeFieldService: boolean;
  displayusageUndoCompleteFieldService: boolean;
  displayUsageUndoStartFieldService: boolean;
  displayUsageCompleteFieldService: boolean;
  displayUndoCompleteRefurbishment: boolean;


  date14: Date;
  displayUndoCompleteItemRefubisment: boolean;
  

    // ngOnInit(): void {
    //   throw new Error('Method not implemented.');
    // }
    showConfirmLihReversal() {
      this.displayConfirmLihReversal = true;
    }
    showActiveDeactiveItem() {
      this.displayActiveDeactiveItem = true;
    }
    showItemDisposition() {
      this.displayItemDisposition =true;
    } 
    showUndoItemDisposition() {
      this.displayUndoItemDisposition =true;
    }
    show2ActiveDeactiveItem() {
      this.display2ActiveDeactiveItem = true;
    }
    showIntransitAcceptanceInfo() {
      this.displayIntransitAcceptanceInfo = true;
    }
    showAddtoShipping() {
      this.displayAddtoShipping = true;
    }
    showItemReturn() {
      this.displayItemReturn = true;
    }
    showUndoReturn() {
      this.displayUndoReturn = true;
    }
    showCompleteRework() {
      this.displayCompleteRework =true;
    }
    showBypassService() {
      this.displayBypassService = true;
    }
    showCompleteFieldSevice() {
      this.displayCompleteFieldSevice = true;
    }
    showItemAttachmentDetails() {
      this.displayItemAttachmentDetails = true;
    }
    showOffRent() {
      this.displayOffRent = true;
    }
    showReserveDateSelection() {
      this.displayReserveDateSelection = true;
    }
    showServiceCostList() {
      this.displayServiceCostList = true;
    }
    showCapitalizeButton() {
      this.displayCapitalizeButton = true;
    }
    showActiveItem() {
      this.displayActiveItem = true;
    }
    showUndoItemDispositionGrid() {
      this.displayUndoItemDispositiongrid =true;
    }
    showItemDispositionGrid() {
      this.displayItemDispositiongrid = true;
    }
    showChangePartNumber() {
      this.displayChangePartNumberGrid = true;
    }
    showBypassServiceGrid() {
      this.displayBypassServiceGrid = true;
    }
    showReturnItemGrid() {
      this.displayReturnItem = true;
    }
    showAcceptFinancialResponsibilityGrid() {
      this.displayAcceptFinancialResponsibility = true;
    }
    showInTransitAcceptanceGrid() {
      this.displayInTransitAcceptance = true;
    }
    showDeactivateItemGrid() {
      this.displayDeactivateItem = true;
    }
    showCompleteService() {
      this.displayCompleteService = true;
    }
    showCompletePreService() {
      this.displayCompletePreService = true;
    }
    showCompleteRefurbishment() {
      this.displayCompleteRefurbishment = true;
    } 
    showCompleteFieldService() {
      this.displayCompleteFieldService = true;
    }
    showResumeService() {
      this.displayResumeService = true;
    }
    showResumePreService() {
      this.displayResumePreService = true;
    }
    showResumeRefurbishment() {
      this.displayResumeRefurbishment = true;
    }
    showResumeFieldService() {
      this.displayResumeFieldServiceGrid = true;
    }
    showStartService() {
      this.displayStartService = true;
    }
    showStartPreService() {
      this.displayStartPreService = true;
    }
    showStartRefurbishment() {
      this.displayStartRefurbishment = true;
    }
    showStartFieldService() {
      this.displayStartFieldServiceGrid = true;
    }
    showSuspendService() {
      this.displaySuspendService = true;
    }
    showSuspendPreService() {
      this.displaySuspendPreService = true;
    }
    showSuspendRefurbishment() {
      this.displaySuspendRefurbishment = true;
    }
    showSuspendFieldService() {
      this.displaySuspendFieldServiceGrid = true;
    }
    showUndoCompleteService() {
      this.displayUndoCompleteService = true;
    }
    showUndoCompletePreService() {
      this.displayUndoCompletePreService = true;
    }
    showUndoBypassService() {
      this.displayUndoBypassService = true;
    }
    showUndoCompleteFieldService() {
      this.displayUndoCompleteFieldService = true;
    }
    showUndoComplateRefurbishment() {
      this.displayUndoCompleteRefurbishment = true;
    }
    showUndoStartService() {
      this.displayUndoStartService = true;
    }
    showUndoStartPreService() {
      this.displayUndoStartPreService = true;
    }
    showUndoStartRefurbishment() {
      this.displayUndoStartRefurbishment = true;
    }
    showUndoStartFieldService() {
      this.displayUndoStartFieldServiceGrid = true;
    }
    showUsageLostInHole() {
      this.displayUsageLostInHole =true;
    }
    showCompleteItemRefubismentDetails() {
      this.displayCompleteItemRefubisment =true;
    }
    showUndoCompleteItemRefubismentDetails() {
      this.displayUndoCompleteItemRefubisment =true;
    }
    showConfirmSalesReversal() {
      this.displayConfirmSalesReversal = true;
    }
    showRemovefromSalesOrder() {
      this.displayRemovefromSalesOrder = true;
    }
    showDeleteforItem() {
      this.displayDeleteforItem = true;
    }
    showRemoveFromCustomerDeliverySlip() {
      this.displayRemoveFromCustomerDeliverySlip = true;
    }
    showRemoveFromTransferSlip() {
      this.displayRemoveFromTransferSlip = true;
    }
    showUsageStartService() {
      this.displayUsageStartService = true;
    }
    showUsageSuspendService() {
      this.displayUsageSuspendService = true;
    }
    showUsageResumeService() {
      this.displayUsageResumeService = true;
    }
    showUsageCompleteService() {
      this.displayUsageCompleteService = true;
    }
    showUsageUndoStartService() {
      this.displayUsageUndoStartService = true;
    }
    showUsageUndoCompleteService() {      
      this.displayUsageUndoCompleteService = true;
    }
    showUsageStartFieldService() {
      this.displayUsageStartFieldService = true;
    }
    showUsageSuspendFieldService() {
      this.displayUsageSuspendFieldService = true;
    }
    showUsageResumeFieldService() {
      this.displayUsageResumeFieldService = true;
    }
    showUsageCompleteFieldService() {
      this.displayUsageCompleteFieldService =true;
    }
    showUsageUndoStartFieldService() {
      this.displayUsageUndoStartFieldService = true;
    }
    showUsageUndoCompleteFieldService() {
      this.displayusageUndoCompleteFieldService = true;
    }
    // uploadedFiles: any[] = [];
    
    // constructor(private messageService: MessageService) {}

    // onUpload(event: { files: any; }) {
    //     for(let file of event.files) {
    //         this.uploadedFiles.push(file);
    //     }
        
    //     this.messageService.add({severity: 'info', summary: 'Success', detail: 'File Uploaded'});
    // }
}
