namespace NOV.ES.TAT.BoomiWrapper.DomainService.RequestModel
{
    public class ValidateInventoryRequest: BaseRequestModel
    {
        public string[] Partnumbers { get; set; }
        public string CostCenter { get; set; }
    }
}
