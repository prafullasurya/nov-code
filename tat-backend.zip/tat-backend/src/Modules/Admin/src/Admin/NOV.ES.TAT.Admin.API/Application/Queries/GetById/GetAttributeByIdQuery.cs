﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetAttributeByIdQuery : IQuery<AttributeDto>
    {
        public int AttributeId { get; private set; }
        public GetAttributeByIdQuery(int attributeId)
        {
            this.AttributeId = attributeId;
        }
    }
}
