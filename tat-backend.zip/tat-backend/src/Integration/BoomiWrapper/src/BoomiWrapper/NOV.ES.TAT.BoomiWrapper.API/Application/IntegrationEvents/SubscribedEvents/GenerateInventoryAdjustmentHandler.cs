﻿using AutoMapper;
using Newtonsoft.Json;
using NOV.ES.Framework.Core.Messaging.IntegrationEvents;
using NOV.ES.Framework.Core.Sagas;
using NOV.ES.TAT.BoomiWrapper.API.Application.IntegrationEvents.PublishEvents;
using NOV.ES.TAT.BoomiWrapper.Domain;
using NOV.ES.TAT.BoomiWrapper.Domain.WriteModels;
using NOV.ES.TAT.BoomiWrapper.DomainService;
using NOV.ES.TAT.BoomiWrapper.DomainService.RequestModel;
using NOV.ES.TAT.BoomiWrapper.DomainService.ResponseModel;

namespace NOV.ES.TAT.BoomiWrapper.API.Application.IntegrationEvents.SubscribedEvents
{
    public class GenerateInventoryAdjustmentHandler
        : IIntegrationEventHandler<GenerateInventoryAdjustment>
    {
        private readonly ILogger<GenerateInventoryAdjustmentHandler> logger;
        private readonly IBoomiWrapperService boomiWrapperService;
        private readonly IIntegrationEventBus integrationEventBus;
        private readonly IMapper mapper;

        public GenerateInventoryAdjustmentHandler(
            ILogger<GenerateInventoryAdjustmentHandler> logger,
            IBoomiWrapperService boomiWrapperService,
            IIntegrationEventBus integrationEventBus,
            IMapper mapper)
        {
            this.logger = logger;
            this.boomiWrapperService = boomiWrapperService;
            this.integrationEventBus = integrationEventBus;
            this.mapper = mapper;
        }

        public Task Handle(GenerateInventoryAdjustment @event)
        {
            logger.LogInformation("----- Consuming Event: Generate Inventory Adjustment Integration Event");
            logger.LogInformation("----- CorelationId is {id}", @event.CorelationId);
            logger.LogInformation("----- Event Detail is {info}", @event.JsonStringData);

            BoomiRequestResponse boomiRequestResponse;
            //1.Generate request for boomi 
            InventoryAdjustmentRequest inventoryAdjustmentRequest = GenerateRequestPayload(@event.CorelationId, @event.ActionBy, @event.JsonStringData, out boomiRequestResponse);

            //2.Record request in database
            boomiWrapperService.RecordRequestPayload(boomiRequestResponse);

            //3. Boomi CallInventoryAdjustment
            InventoryAdjustmentResponse inventoryAdjustmentResponse = boomiWrapperService.InventoryAdjustment(inventoryAdjustmentRequest).Result;

            //4. Record Response
            boomiRequestResponse.Status = BoomiResponseType.Success.ToString();
            boomiRequestResponse.ResponseStatus = inventoryAdjustmentResponse.Success;
            boomiRequestResponse.RequestDateTime = DateTime.UtcNow;
            boomiRequestResponse.ResponseBody = JsonConvert.SerializeObject(inventoryAdjustmentResponse);
            if (inventoryAdjustmentResponse.Errors != null && inventoryAdjustmentResponse.Errors.Any())
            {
                boomiRequestResponse.ErrorMessage = JsonConvert.SerializeObject(inventoryAdjustmentResponse.Errors);
                boomiRequestResponse.Status = BoomiResponseType.Failed.ToString();
            }

            boomiWrapperService.RecordResponse(boomiRequestResponse);

            //5.Generate response for publish event
            var result = GenerateResponseForPublishEvent(inventoryAdjustmentResponse);

            //6.publish event
            GeneratedInventoryAdjustment success =
            new(
                boomiRequestResponse.RequestId.ToString(),
                @event.CorelationId,
                JsonConvert.SerializeObject(result),
                DateTime.UtcNow,
                SagaEventExecutionResult.Success,
                @event.ActionBy
                );

            logger.LogInformation("Publish Generated Inventory Adjustment event  - GeneratedInventoryAdjustment.");
            integrationEventBus.Publish(success);

            return Task.CompletedTask;

        }

        private InventoryAdjustmentRequest GenerateRequestPayload(Guid corelationId, string actionBy, string jsonStringData, out BoomiRequestResponse boomiRequestResponse)
        {
            var generateInventoryAdjustmentRequest = JsonConvert.DeserializeObject<GenerateInventoryAdjustmentRequest>(jsonStringData);

            var inventoryAdjustmentRequest = mapper.Map<GenerateInventoryAdjustmentRequest, InventoryAdjustmentRequest>(generateInventoryAdjustmentRequest);

            boomiRequestResponse = new BoomiRequestResponse()
            {
                RequestId = generateInventoryAdjustmentRequest.RequestId,
                CorelationId = corelationId,
                EventId = generateInventoryAdjustmentRequest.EventId,
                KeyName = generateInventoryAdjustmentRequest.KeyName,
                KeyValue = generateInventoryAdjustmentRequest.KeyValue,
                RequestDateTime = DateTime.UtcNow,
                RequestStatus = BoomiResponseType.Success.ToString(),
                RequestBody = JsonConvert.SerializeObject(inventoryAdjustmentRequest),
                RequestURL = "inInventory/InventoryAdjustment",
                RequestMethod = "InventoryAdjustment",
                HttpVerb = "Post",
                ActionBy = actionBy
            };

            return inventoryAdjustmentRequest;
        }

        private static int GenerateResponseForPublishEvent(InventoryAdjustmentResponse inventoryAdjustmentResponse)
        {
            return inventoryAdjustmentResponse.JDEDocNumber;
        }
    }
}

