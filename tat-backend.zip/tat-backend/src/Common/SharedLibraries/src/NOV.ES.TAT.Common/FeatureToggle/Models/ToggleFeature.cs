﻿namespace NOV.ES.TAT.Common.FeatureToggle.Models
{
    public class ToggleFeature
    {
        public string ModuleName​ { get; set; }
        public string FeatureDescription { get; set; }
        public string FeatureCode​ { get; set; }
        public string JiraTicket​ { get; set; }
    }
}
