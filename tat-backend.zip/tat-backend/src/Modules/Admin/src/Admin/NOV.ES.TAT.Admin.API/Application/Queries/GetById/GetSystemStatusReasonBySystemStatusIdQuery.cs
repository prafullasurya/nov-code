﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;


namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetSystemStatusReasonBySystemStatusIdQuery : IQuery<IEnumerable<SystemStatusReasonDto>>
    {
        public int SystemStatusId { get; private set; }
        public GetSystemStatusReasonBySystemStatusIdQuery(int systemStatusId)
        {
            this.SystemStatusId = systemStatusId;
        }
    }
}
