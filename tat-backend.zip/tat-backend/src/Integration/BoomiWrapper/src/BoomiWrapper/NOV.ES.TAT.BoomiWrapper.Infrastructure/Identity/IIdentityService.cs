﻿namespace NOV.ES.TAT.BoomiWrapper.Infrastructure;

public interface IIdentityService
{
    string GetUserIdentity();
    string GetUserName();
}

