﻿namespace NOV.ES.TAT.Common.UserPermissions.Models
{
    public class UserBusinessUnit
    {
        public int? businessunitid { get; set; }
        public int? companyid { get; set; }
        public string businessunitname { get; set; }
        public string businessunitcode { get; set; }
        public string relatedbu { get; set; }
        public string countrycode { get; set; }
        public string divisioncode { get; set; }
        public string email { get; set; }

    }
}
