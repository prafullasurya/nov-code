﻿using NOV.ES.TAT.EmailService.API.Dtos;
using NOV.ES.TAT.EmailService.Helper;

namespace NOV.ES.TAT.EmailService
{
    public interface IEmailBaseService
    {       
        public EmailStatus NotifiersWithFile(EmailFlieDto emailParam);
        public EmailStatus Notifiers(EmailDto emailParam);
    }
}
