﻿using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Admin.DomainService.Helper;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetSystemStatusesLookupDataByColumnQuery : GetLookupDataBaseQuery
    {
        public GetSystemStatusesLookupDataByColumnQuery(Paging pagingParameters, FilterData filterData,
           string searchText, string searchColum, bool includeInActive)
           : base(pagingParameters, filterData, searchText, searchColum, includeInActive)
        {

        }
    }
}