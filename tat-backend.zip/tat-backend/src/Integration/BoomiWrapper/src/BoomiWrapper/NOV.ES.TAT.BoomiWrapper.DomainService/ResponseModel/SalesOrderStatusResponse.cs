﻿namespace NOV.ES.TAT.BoomiWrapper.DomainService.ResponseModel
{
    public class  SalesOrderStatusResponse
    {
        public string Success { get; set; }
        public decimal CurrencyConverRate { get; set; }
        public int OrderNumber { get; set; }
        public string QueryServiceStatus { get; set; }
        public string OrderType { get; set; }
        public string RelatedOrderType { get; set; }
        public int UniqueOrderReferenceNumber { get; set; }
        public List<ErpError> Errors { get; set; }
    }
}
