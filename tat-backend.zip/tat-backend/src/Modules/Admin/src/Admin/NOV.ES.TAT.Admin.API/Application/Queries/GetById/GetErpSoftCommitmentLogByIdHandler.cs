﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetErpSoftCommitmentLogByIdHandler : IQueryHandler<GetErpSoftCommitmentLogByIdQuery, ErpSoftCommitmentLogDto>
    {
        private readonly IMapper mapper;
        private readonly IErpSoftCommitmentLogService erpSoftCommitmentLogService;

        public GetErpSoftCommitmentLogByIdHandler(
            IMapper mapper,
            IErpSoftCommitmentLogService erpSoftCommitmentLogService)
        {
            this.mapper = mapper;
            this.erpSoftCommitmentLogService = erpSoftCommitmentLogService;
        }

        public Task<ErpSoftCommitmentLogDto> Handle(GetErpSoftCommitmentLogByIdQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var erpSoftCommitmentLog = erpSoftCommitmentLogService.GetErpSoftCommitmentLogById(request.Id);
            var result = mapper.Map<ErpSoftCommitmentLog, ErpSoftCommitmentLogDto>(erpSoftCommitmentLog);
            return Task.FromResult(result);
        }
        private static bool IsValidRequest(GetErpSoftCommitmentLogByIdQuery request)
        {
            return (request != null && request.Id != 0);
        }
    }
}