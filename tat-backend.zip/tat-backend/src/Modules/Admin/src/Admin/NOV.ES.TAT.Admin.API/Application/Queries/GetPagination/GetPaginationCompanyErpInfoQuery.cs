﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Admin.API.DTOs;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetPaginationCompanyErpInfoQuery : IQuery<PagedResult<CompanyErpInfoDto>>
    {
        public Paging PagingParameters { get; private set; }

        public GetPaginationCompanyErpInfoQuery(Paging pagingParameters)
        {
            this.PagingParameters = pagingParameters;
        }
    }
}
