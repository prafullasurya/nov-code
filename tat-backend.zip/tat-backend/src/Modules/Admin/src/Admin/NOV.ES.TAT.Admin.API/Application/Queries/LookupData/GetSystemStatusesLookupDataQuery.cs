﻿using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Admin.DomainService.Helper;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetSystemStatusesLookupDataQuery : GetLookupDataBaseQuery
    {
        public GetSystemStatusesLookupDataQuery(Paging pagingParameters, FilterData filterData,
           string searchText, bool includeInActive)
           : base(pagingParameters, filterData, searchText, includeInActive)
        {

        }
    }
}