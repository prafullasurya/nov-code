﻿namespace NOV.ES.TAT.BoomiWrapper.DomainService.RequestModel
{
    public class GetInventoryExtractRequest : BaseRequestModel
    {
        public string UniqueOrderReferenceNumber { get; set; }
    }
}
