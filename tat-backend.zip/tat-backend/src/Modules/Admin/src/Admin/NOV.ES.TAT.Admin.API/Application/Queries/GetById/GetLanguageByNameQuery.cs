﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetLanguageByErpCodeQuery : IQuery<LanguageDto>
    {
        public string ErpLanguageCode { get; private set; }

        public GetLanguageByErpCodeQuery(string erpLanguageCode)
        {
            this.ErpLanguageCode = erpLanguageCode;
        }
    }
}