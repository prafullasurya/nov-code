﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.API.Helper;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetPaginationAccountTypesHandler
           : IQueryHandler<GetPaginationAccountTypesQuery, PagedResult<AccountTypeDto>>
    {
        private readonly IMapper mapper;
        private readonly IAccountTypeService accountTypeService;
        private readonly IHttpContextAccessor httpContextAccessor;

        public GetPaginationAccountTypesHandler(
            IMapper mapper
            ,IAccountTypeService accountTypeService
            , IHttpContextAccessor httpContextAccessor)
        {
            this.mapper = mapper;
            this.accountTypeService = accountTypeService;
            this.httpContextAccessor = httpContextAccessor;
        }

        public Task<PagedResult<AccountTypeDto>> Handle(GetPaginationAccountTypesQuery request,
          CancellationToken cancellationToken)
        {
            var accountTypes = accountTypeService.GetAccountTypes(request.PagingParameters);
            var result = mapper.Map<PagedResult<AccountType>, PagedResult<AccountTypeDto>>(accountTypes);

            PagingHelper.AddPagingMetadata<AccountTypeDto>(result, httpContextAccessor);
            return Task.FromResult(result);
        }
    }
}