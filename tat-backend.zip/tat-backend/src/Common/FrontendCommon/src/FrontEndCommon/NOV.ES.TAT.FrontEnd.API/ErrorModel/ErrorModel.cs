﻿namespace NOV.ES.TAT.FrontEnd.API
{
    public class ErrorModel
    {
        public string? Application { get; set; }
        public string? Message { get; set; }
        public string? Action { get; set; }
        public string? Priority { get; set; }
        public string? URL { get; set; }
    }
}
