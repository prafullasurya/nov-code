using Newtonsoft.Json;

namespace NOV.ES.TAT.BoomiWrapper.DomainService.ResponseModel
{
    public class ItemMasterResponse
    {
        public string Success { get; set; }
        public List<ItemError> Errors { get; set; }
        public string Description1 { get; set; }
        public string Description2 { get; set; }
        public string UnitOfMeasureWeight { get; set; }
        public string Weight { get; set; }

        [JsonProperty("partNumber")]
        public string PartNumber { get; set; }
        public string RAPartNumber { get; set; }
        public string UserDefinedCode { get; set; }
    }
}
