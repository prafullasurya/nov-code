import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ItemsFinanceComponent } from './items-finance.component';

describe('ItemsFinanceComponent', () => {
  let component: ItemsFinanceComponent;
  let fixture: ComponentFixture<ItemsFinanceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ItemsFinanceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ItemsFinanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
function beforeEach(arg0: () => void) {
  throw new Error('Function not implemented.');
}

