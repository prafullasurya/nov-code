﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.FrontEnd.API.Constant;
using NOV.ES.TAT.FrontEnd.API.DTOs;
using NOV.ES.TAT.FrontEnd.Domain;
using NOV.ES.TAT.FrontEnd.DomainService;
namespace NOV.ES.TAT.FrontEnd.API.Application
{
    public class GetMaintenanceQueryHandler
        : IQueryHandler<MaintenanceQuery, IEnumerable<MaintenanceDto>>
    {
        private readonly IMaintenanceService maintenanceService;
        private readonly IMapper mapper;
        public GetMaintenanceQueryHandler(IMapper mapper, IMaintenanceService maintenanceService)
        {
            this.mapper = mapper;
            this.maintenanceService = maintenanceService;
        }

        public Task <IEnumerable<MaintenanceDto>> Handle(MaintenanceQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var maintenanceDetails = maintenanceService.GetMaintenance();
            var result = mapper.Map<IEnumerable<MaintenanceModel>, IEnumerable<MaintenanceDto>>(maintenanceDetails);
             return Task.FromResult(result);
        }

        private static bool IsValidRequest(MaintenanceQuery request)
        {
            return (request != null);
        }
    }
}
