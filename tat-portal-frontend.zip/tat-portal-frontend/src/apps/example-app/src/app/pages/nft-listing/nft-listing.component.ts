import { Component, OnInit } from '@angular/core';
import { ConfirmationService, MessageService } from 'primeng/api';
import { Product } from '../../models/product';
import { ProductService } from '../../models/productservice';


interface City {
  name: string,
  code: string
}
@Component({
  selector: 'nft-listing',
  templateUrl: './nft-listing.component.html',
  styleUrls: ['./nft-listing.component.scss']
})
export class nftListingComponent {
  
  displayBasic: boolean;
  displayCreateNft: boolean;

    // ngOnInit(): void {
    //   throw new Error('Method not implemented.');
    // }
    showBasicDialog() {
      this.displayBasic = true;
    }
    showCreateNftDialog() {
      this.displayCreateNft = true;
    }  

}
