﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.DomainService.Helper;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetErpAddressCodesFilterQuery : IQuery<IEnumerable<string>>
    {
        public FilterData FilterData { get; private set; }

        public GetErpAddressCodesFilterQuery(FilterData filterData)
        {
            this.FilterData = filterData;
        }
    }
}