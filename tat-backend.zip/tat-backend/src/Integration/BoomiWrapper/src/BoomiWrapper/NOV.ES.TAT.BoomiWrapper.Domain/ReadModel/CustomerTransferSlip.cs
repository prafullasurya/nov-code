﻿using NOV.ES.Framework.Core.DTOs;

namespace NOV.ES.TAT.BoomiWrapper.Domain.ReadModel
{
    public class CustomerTransferSlip : BaseModel<int>
    {
        public int CustomerTransferNumber { get; set; }
        public int CompanyId { get; set; }
        public string CompanyName { get; set; }
        public string CompanyCode { get; set; }
        public DateTime SlipDate { get; set; }
        public DateTime? UsageDate { get; set; }
        public int? OilCompanyId { get; set; }
        public string OilCompanyName { get; set; }
        public int? RigId { get; set; }
        public Guid? CorpRigId { get; set; }
        public string RigName { get; set; }
        public string RigJDEName { get; set; }
        public string ContractorName { get; set; }
        public int? WellSiteId { get; set; }
        public Guid? CorpWellSiteId { get; set; }
        public string WellName { get; set; }
        public string WellLocation { get; set; }
        public string WellNameSource { get; set; }
        public int? ErpJobNumber { get; set; }
        public string CustomerJobNumber { get; set; }
        public string ShipVia { get; set; }
        public string ShippedBy { get; set; }
        public int? CustomerId { get; set; }
        public string CustomerName { get; set; }
        public Int64 CustomerCode { get; set; }
        public int? EffectiveCustomerId { get; set; }
        public string EffectiveCustomerName { get; set; }
        public int? DrillingApplicationId { get; set; }
        public string DrillingApplicationName { get; set; }
        public int? BillingApplicationId { get; set; }
        public string BillingApplicationName { get; set; }
        public int? BusinessUnitId { get; set; }
        public string BusinessUnitName { get; set; }
        public string BusinessUnitCode { get; set; }
        public string HeaderAddress { get; set; }
        public string HeaderPhone { get; set; }
        public string HeaderFax { get; set; }
        public string CustomerContact { get; set; }
        public string CustomerPhoneNumber { get; set; }
        public int? FreightTypeId { get; set; }
        public string FreightType { get; set; }
        public string BillOfLading { get; set; }
        public string WayBill { get; set; }
        public string GLCode { get; set; }
        public int? SalesPersonId { get; set; }
        public string SalesPersonName { get; set; }
        public string CheckedBy { get; set; }
        public int? SendingLocationId { get; set; }
        public string SendingLocationName { get; set; }
        public int? SendingBuId { get; set; }
        public string SendingBuName { get; set; }
        public string SendingBuCode { get; set; }
        public int? SendingBuTempId { get; set; }
        public string SendingBuTempName { get; set; }
        public string LsdCounty { get; set; }
        public string OcsgNumber { get; set; }
        public string Verbiage { get; set; }
        public string Comments { get; set; }
        public string Currency { get; set; }
        public string VatNo { get; set; }
        public string SlipType { get; set; }
        public string ErrorMessage { get; set; }
        public string CustomerPoAfe { get; set; }
        public string ShipToAddress { get; set; }
        public string OtherDocInfo { get; set; }
        public string OtherDocNumber { get; set; }
        public bool? IsIntendedUseOnLand { get; set; }
        public string RentalAgreement { get; set; }
        public bool? ShowChildItemOnCommercialInvoice { get; set; }
        public int? SalesZoneId { get; set; }
        public string Consignee { get; set; }
        public string ForwardingInstruction { get; set; }
        public string ErpDocType { get; set; }
        public string ErpDocNumber { get; set; }
        public short? IsCompleted { get; set; } = 0;
        public ICollection<CustomerTransferSlipDetail> CustomerTransferSlipDetails { get; set; }
        public string FieldTicket { get; set; }
        public string SalesZoneName { get; set; }

        public string JDEDocNumberTemp { get; set; }
    }
}
