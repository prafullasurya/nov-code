﻿namespace NOV.ES.TAT.Common.UserPermissions.Models
{
    public class UserCompany
    {
        public int? companyid { get; set; }
        public string name { get; set; }
        public string code { get; set; }
        public string currency { get; set; }
        public string email { get; set; }
        public bool istoolmovementdocrequired { get; set; }
        public bool isshiptopsrequired { get; set; }
        public bool isslipsequencechangeallowed { get; set; }
        public bool processerpitems { get; set; }
        public bool isjobrequired { get; set; }
        public bool isremitoallowed { get; set; }
    }
}

