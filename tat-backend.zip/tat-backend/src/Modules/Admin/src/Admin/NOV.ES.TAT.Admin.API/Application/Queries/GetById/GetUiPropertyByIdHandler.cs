﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetUiPropertyByIdHandler : IQueryHandler<GetUiPropertyByIdQuery, UiPropertyDto>
    {
        private readonly IMapper mapper;
        private readonly IUiPropertyService uiPropertyService;

        public GetUiPropertyByIdHandler(
            IMapper mapper,
            IUiPropertyService uiPropertyService)
        {
            this.mapper = mapper;
            this.uiPropertyService = uiPropertyService;
        }

        public Task<UiPropertyDto> Handle(GetUiPropertyByIdQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var uiProperty = uiPropertyService.GetUiPropertyById(request.Id);
            var result = mapper.Map<UiProperty, UiPropertyDto>(uiProperty);
            return Task.FromResult(result);
        }
        private static bool IsValidRequest(GetUiPropertyByIdQuery request)
        {
            return (request != null && request.Id != 0);
        }
    }
}