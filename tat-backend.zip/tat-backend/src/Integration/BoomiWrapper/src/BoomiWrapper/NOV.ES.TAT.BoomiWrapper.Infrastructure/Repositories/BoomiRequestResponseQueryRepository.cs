﻿using NOV.ES.Framework.Core.Data.Repository;
using NOV.ES.TAT.BoomiWrapper.Domain;

namespace NOV.ES.TAT.BoomiWrapper.Infrastructure
{
    public class BoomiRequestResponseQueryRepository :
        GenericReadRepository<BoomiRequestResponse>,
        IBoomiRequestResponseQueryRepository
    {
        public BoomiRequestResponseQueryRepository(InterfaceDBContext interfaceDBContext)
            : base(interfaceDBContext)
        {
        }
    }
}