﻿using IdentityModel.Client;

namespace NOV.ES.TAT.Common.ServiceBase
{
    public interface IIdentityServerClient
    {
        Task<string> GetIdentityToken();
    }
}
