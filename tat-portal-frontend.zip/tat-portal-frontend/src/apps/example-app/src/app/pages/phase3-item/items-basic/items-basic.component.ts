import { Component, OnInit } from '@angular/core';
import { ConfirmationService, MessageService } from 'primeng/api';
import { Product } from '../../../models/product';
import { ProductService } from '../../../models/productservice';


interface City {
  name: string,
  code: string
}
@Component({
  selector: 'items-basic',
  templateUrl: './items-basic.component.html',
  styleUrls: ['./items-basic.component.scss']
})
export class ItemsBasicComponent {
  
  // activeIndex1: number = 0;

  // activeIndex2: number = 0;

  // scrollableTabs: any[] = Array.from({ length: 50 }, (_, i) => ({ title: `Tab ${i + 1}`, content: `Tab ${i + 1} Content` }));

}
