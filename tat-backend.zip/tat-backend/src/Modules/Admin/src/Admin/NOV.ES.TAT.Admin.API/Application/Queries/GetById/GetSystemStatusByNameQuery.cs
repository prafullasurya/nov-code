﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetSystemStatusByNameQuery : IQuery<SystemStatusDto>
    {
        public string Name { get; private set; }

        public GetSystemStatusByNameQuery(string name)
        {
            this.Name = name;
        }
    }
}