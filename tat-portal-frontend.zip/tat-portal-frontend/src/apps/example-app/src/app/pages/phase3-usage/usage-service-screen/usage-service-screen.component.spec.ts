import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UsageServiceScreenComponent } from './usage-service-screen.component';

describe('UsageServiceScreenComponent', () => {
  let component: UsageServiceScreenComponent;
  let fixture: ComponentFixture<UsageServiceScreenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UsageServiceScreenComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UsageServiceScreenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
function beforeEach(arg0: () => void) {
  throw new Error('Function not implemented.');
}

