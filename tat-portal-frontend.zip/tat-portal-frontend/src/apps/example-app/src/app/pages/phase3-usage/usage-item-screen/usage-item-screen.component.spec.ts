import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UsageItemScreenComponent } from './usage-item-screen.component';

describe('UsageItemScreenComponent', () => {
  let component: UsageItemScreenComponent;
  let fixture: ComponentFixture<UsageItemScreenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UsageItemScreenComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UsageItemScreenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
function beforeEach(arg0: () => void) {
  throw new Error('Function not implemented.');
}

