﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetDefinedInputGroupValueByDefinedInputGroupIdQuery : IQuery<IEnumerable<DefinedInputGroupValueDto>>
    {
        public int? DefinedInputGroupId { get; private set; }

        public GetDefinedInputGroupValueByDefinedInputGroupIdQuery(int? definedInputGroupId)
        {
            this.DefinedInputGroupId = definedInputGroupId;
        }
    }
}