import { Component, OnInit } from '@angular/core';
import { ConfirmationService, MessageService } from 'primeng/api';


@Component({
  selector: 'usage-product-analysis',
  templateUrl: './usage-product-analysis.component.html',
  styleUrls: ['./usage-product-analysis.component.scss']
})
export class UsageProductAnalysisComponent {
  
}
