﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetDocStatusByIdQueryHandler : IQueryHandler<GetDocStatusByIdQuery, DocStatusDto>
    {
        private readonly IMapper mapper;
        private readonly IDocStatusService docStatusService;

        public GetDocStatusByIdQueryHandler(
            IMapper mapper,
            IDocStatusService docStatusService)
        {
            this.mapper = mapper;
            this.docStatusService = docStatusService;
        }

        public Task<DocStatusDto> Handle(GetDocStatusByIdQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var docStatus = docStatusService.GetDocStatusById(request.DocStatusId);
            return Task.FromResult(mapper.Map<DocStatus, DocStatusDto>(docStatus));
        }

        private static bool IsValidRequest(GetDocStatusByIdQuery request)
        {
            return (request != null && request.DocStatusId != 0);
        }
    }
}
