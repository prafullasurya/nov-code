﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;


namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetDefinedInputGroupByIdQuery : IQuery<DefinedInputGroupDto>
    {
        public int DefinedInputGroupId { get; private set; }
        public GetDefinedInputGroupByIdQuery(int definedInputGroupId)
        {
            this.DefinedInputGroupId = definedInputGroupId;
        }
    }
}
