﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using NOV.ES.Framework.Core.Data;
using NOV.ES.Framework.Core.Data.Repository;
using NOV.ES.TAT.FrontEnd.Domain;
using NOV.ES.TAT.FrontEnd.Domain.WriteModels;
using NOV.ES.TAT.FrontEnd.DomainService.Clients;
using NOV.ES.TAT.FrontEnd.Infrastructure;
using System;

namespace NOV.ES.TAT.FrontEnd.DomainService
{
    public class MaintenanceService : IMaintenanceService
    {
        private readonly IReadRepository<MaintenanceModel> maintenanceQueryRepository;
        private readonly ILogger<MaintenanceService> logger;
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly IMaintenanceWriteRepository maintenanceWriteRepository;
        private readonly IFrontendCommonAppNotificationClient frontendCommonAppNotificationClient;

        public MaintenanceService(
            ILogger<MaintenanceService> logger,
            IHttpContextAccessor httpContextAccessor,
            IReadRepository<MaintenanceModel> maintenanceQueryRepository,
            IMaintenanceWriteRepository maintenanceWriteRepository,
            IFrontendCommonAppNotificationClient frontendCommonAppNotificationClient)
        {
            this.logger = logger;
            this.httpContextAccessor = httpContextAccessor;
            this.maintenanceQueryRepository = maintenanceQueryRepository;
            this.maintenanceWriteRepository = maintenanceWriteRepository;
            this.frontendCommonAppNotificationClient = frontendCommonAppNotificationClient;
        }

        public List<MaintenanceModel> GetMaintenance()
        {
            var filter = PredicateBuilder.Create<MaintenanceModel>(x => x.IsActive);
            return maintenanceQueryRepository.Get(filter, null, null).ToList();
        }

        public MaintenanceModel AddMaintenanceInfo(AddMaintenanceModel request)
        {
            var newMaintenanceModel = new MaintenanceModel();
            logger.LogInformation($"Start: Add System Down message");
            MapToMaintenaceModel(newMaintenanceModel, request);
            var result = SaveMaintenanceInfoAsync(newMaintenanceModel).Result;
            logger.LogInformation($"End: Create FTS Header request processing is completed {result}");

            return result;
        }

        public async Task<bool> MarkAsCompleted(int id)
        {
            bool result = false;
            var existimgMaintenanceModel = await this.maintenanceWriteRepository.GetById(id);
            if (existimgMaintenanceModel != null)
            {
                existimgMaintenanceModel.IsActive = false;
                string actionBy = string.Empty;
                if (httpContextAccessor.HttpContext != null)
                {
                    actionBy = httpContextAccessor.HttpContext.Items["user_email_id"] != null ? httpContextAccessor.HttpContext.Items["user_email_id"]?.ToString() : "API";
                }
                maintenanceWriteRepository.SetUserProvider(actionBy);
                this.maintenanceWriteRepository.Update(existimgMaintenanceModel);
                this.maintenanceWriteRepository.SaveChanges();
                result = true;
            }
            return result;
        }

        private void MapToMaintenaceModel(MaintenanceModel newMaintenanceModel,
            AddMaintenanceModel request)
        {
            if (request != null)
            {
                newMaintenanceModel.DownTimeReason = request.DownTimeReason;
                newMaintenanceModel.MessageId = request.MessageId;
                newMaintenanceModel.ScheduledOn = request.ScheduledOn;
                newMaintenanceModel.ExpectedResumeBy = request.ExpectedResumeBy;
            }
        }
        private async Task<MaintenanceModel> SaveMaintenanceInfoAsync(MaintenanceModel maintenanceModel)
        {
            string actionBy = string.Empty;
            if (httpContextAccessor.HttpContext != null)
            {
                actionBy = httpContextAccessor.HttpContext.Items["user_email_id"] != null ? httpContextAccessor.HttpContext.Items["user_email_id"]?.ToString() : "API";
            }
            maintenanceWriteRepository.SetUserProvider(actionBy);
            maintenanceWriteRepository.AddSystemDownMessage(maintenanceModel);
            maintenanceWriteRepository.SaveChanges();

            logger.LogInformation("Get System Down Message {id} ", maintenanceModel.Id);
            var createdSystemDownMessage = await maintenanceWriteRepository.GetById(maintenanceModel.Id);
            if (createdSystemDownMessage != null)
            {
                await this.frontendCommonAppNotificationClient.BroadcastSystemShutingdownMessageAsync(createdSystemDownMessage);
            }
            
            return createdSystemDownMessage;
        }
    }
}
