﻿using Newtonsoft.Json;
using NOV.ES.Framework.Core.Messaging.IntegrationEvents;
using NOV.ES.Framework.Core.Sagas;
using NOV.ES.TAT.BoomiWrapper.API.Application.IntegrationEvents.PublishEvents;
using NOV.ES.TAT.BoomiWrapper.Domain;
using NOV.ES.TAT.BoomiWrapper.Domain.WriteModels;
using NOV.ES.TAT.BoomiWrapper.DomainService;
using NOV.ES.TAT.BoomiWrapper.DomainService.RequestModel;
using NOV.ES.TAT.BoomiWrapper.DomainService.ResponseModel;
using AutoMapper;

namespace NOV.ES.TAT.BoomiWrapper.API.Application.IntegrationEvents.SubscribedEvents
{
    public class GenerateGetExchangeRateHandler
        : IIntegrationEventHandler<GenerateGetExchangeRate>
    {
        private ILogger<GenerateGetExchangeRateHandler> logger;
        private readonly IBoomiWrapperService boomiWrapperService;
        private readonly IIntegrationEventBus integrationEventBus;
        private readonly IMapper mapper;

        public GenerateGetExchangeRateHandler(
            ILogger<GenerateGetExchangeRateHandler> logger,
            IBoomiWrapperService boomiWrapperService,
            IIntegrationEventBus integrationEventBus,
            IMapper mapper)
        {
            this.logger = logger;
            this.boomiWrapperService = boomiWrapperService;
            this.integrationEventBus = integrationEventBus;
            this.mapper = mapper;
        }

        public Task Handle(GenerateGetExchangeRate @event)
        {
            logger.LogInformation("----- Consuming Event: Generate Exchange Rate Integration Event");
            logger.LogInformation("----- CorelationId is {id}", @event.CorelationId);
            logger.LogInformation("----- Event Detail is {info}", @event.JsonStringData);

            BoomiRequestResponse boomiRequestResponse;
            //1.Generate request for boomi 
            ExchangeRateRequest exchangeRateRequest = GenerateRequestPayload(@event.CorelationId, @event.ActionBy, @event.JsonStringData, out boomiRequestResponse);

            //2.Record request in database
            boomiWrapperService.RecordRequestPayload(boomiRequestResponse);

            //3. Boomi Call
            ExchangeRateResponse exchangeRateResponse = boomiWrapperService.GetExchangeRate(exchangeRateRequest).Result;

            //4. Record Response
            boomiRequestResponse.Status = BoomiResponseType.Success.ToString();
            boomiRequestResponse.ResponseStatus = exchangeRateResponse.Success;
            boomiRequestResponse.RequestDateTime = DateTime.UtcNow;
            boomiRequestResponse.ResponseBody = JsonConvert.SerializeObject(exchangeRateResponse);
            if (exchangeRateResponse.Errors != null && exchangeRateResponse.Errors.Any())
            {
                boomiRequestResponse.ErrorMessage = JsonConvert.SerializeObject(exchangeRateResponse.Errors);
                boomiRequestResponse.Status = BoomiResponseType.Failed.ToString();
            }

            boomiWrapperService.RecordResponse(boomiRequestResponse);

            //5.Generate response for publish event
            var result = GenerateResponseForPublishEvent(exchangeRateResponse);

            //6.publish event
            GeneratedCreateSalesOrder success =
            new(
                boomiRequestResponse.RequestId.ToString(),
                @event.CorelationId,
                JsonConvert.SerializeObject(result),
                DateTime.UtcNow,
                SagaEventExecutionResult.Success,
                @event.ActionBy
                );

            logger.LogInformation("Publish Generated Create Sales Order event  - GeneratedCreateSalesOrder.");
            integrationEventBus.Publish(success);

            return Task.CompletedTask;

        }

        private ExchangeRateRequest GenerateRequestPayload(Guid corelationId, string actionBy, string jsonStringData, out BoomiRequestResponse boomiRequestResponse)
        {
            var generateExchangeRateRequest = JsonConvert.DeserializeObject<GenerateExchangeRateRequest>(jsonStringData);

            var exchangeRateRequest = mapper.Map<GenerateExchangeRateRequest, ExchangeRateRequest>(generateExchangeRateRequest);
            boomiRequestResponse = new BoomiRequestResponse()
            {
                RequestId = generateExchangeRateRequest.RequestId,
                CorelationId = corelationId,
                EventId = generateExchangeRateRequest.EventId,
                KeyName = generateExchangeRateRequest.KeyName,
                KeyValue = generateExchangeRateRequest.KeyValue,
                RequestDateTime = DateTime.UtcNow,
                RequestStatus = BoomiResponseType.Success.ToString(),
                RequestBody = JsonConvert.SerializeObject(exchangeRateRequest),
                RequestURL = "inSalesOrder/GetExchangeRate",
                RequestMethod = "GetExchangeRate",
                HttpVerb = "Post",
                ActionBy = actionBy
            };

            return exchangeRateRequest;
        }

        private static int GenerateResponseForPublishEvent(ExchangeRateResponse exchangeRateResponse)
        {
            return (int)exchangeRateResponse.DefaultRate;
        }
    }
}

