﻿namespace NOV.ES.TAT.BoomiWrapper.DomainService.ResponseModel
{
    public class GetInventoryExtractResponse
    {
        public string Success { get; set; }
        public QueryServiceStatus QueryServiceStatus { get; set; }
        public List<ErpError> Errors { get; set; }
    }
}
