using System.Net;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using NOV.ES.Framework.Core.Sagas;
using NOV.ES.TAT.BoomiWrapper.Domain;
using NOV.ES.TAT.BoomiWrapper.Domain.Event;
using NOV.ES.TAT.BoomiWrapper.Domain.ReadModel;
using NOV.ES.TAT.BoomiWrapper.Domain.WriteModels;
using NOV.ES.TAT.BoomiWrapper.DomainService.ResponseModel;
using NOV.ES.TAT.MDM.Domain;
using NOV.ES.TAT.MDM.DomainService;

namespace NOV.ES.TAT.BoomiWrapper.DomainService
{
    public class InventoryItemsService : IInventoryItemsService
    {
        private readonly ILogger<InventoryItemsService> logger;
        private readonly IBoomiWrapperService boomiWrapperService;
        private readonly IErpItemsBatchService erpItemsBatchService;
        private readonly IErpSoftCommitmentLogService erpSoftCommitmentLogService;
        private readonly IBusinessUnitService businessUnitService;

        private readonly IHttpContextAccessor httpContextAccessor;

        public InventoryItemsService(
            ILogger<InventoryItemsService> logger,
            IBoomiWrapperService boomiWrapperService,
            IErpItemsBatchService erpItemsBatchService,
            IErpSoftCommitmentLogService erpSoftCommitmentLogService,
            IBusinessUnitService businessUnitService,
            IHttpContextAccessor httpContextAccessor)
        {
            this.logger = logger;
            this.boomiWrapperService = boomiWrapperService;
            this.erpItemsBatchService = erpItemsBatchService;
            this.erpSoftCommitmentLogService = erpSoftCommitmentLogService;
            this.httpContextAccessor = httpContextAccessor;
            this.businessUnitService = businessUnitService;
        }

        public string GetActionBy()
        {
            if (httpContextAccessor.HttpContext != null)
            {
                return httpContextAccessor.HttpContext.Request.Headers["user_email_id"].FirstOrDefault() != null ? httpContextAccessor.HttpContext.Request.Headers["user_email_id"].FirstOrDefault()?.ToString() : "API";
            }
            return "API";
        }
        public Guid ProcessErpItems(SagaEvent @event, ProcessInventoryItemsInErp processInventoryItemsInErp, ErpOperations erpOperation)
        {
            var boomiRequestId = Guid.Empty;
            if (processInventoryItemsInErp != null && processInventoryItemsInErp.ErpItems != null && processInventoryItemsInErp.ErpItems.Any())
            {

                var inventoryTransferDetails = new List<InventoryTransferDetails>();
                var customerTransferId = processInventoryItemsInErp.CustomerTransferSlip.Id;
                boomiRequestId = Guid.NewGuid();

                ErpItemsBatch erpItemsBatch;
                int erpItemsBatchNumber;

                //Calling Validate Inventory Items Boomi Wrapper Service
                var failurePartNumbers = new List<string>();

                Task<ValidateInventoryResponse> validateInventoryResponse = null;
                if (erpOperation == ErpOperations.ADD)
                {
                    if (processInventoryItemsInErp.ErpItems.Count > 0)
                    {
                        string[] partNumbers = processInventoryItemsInErp.ErpItems.Where(x => x.ItemType.ToString() == "J")
                            .Select(x => x.PartNumber).Distinct().ToArray();

                        var validateInventoryRequest = new RequestModel.ValidateInventoryRequest
                        {
                            Partnumbers = partNumbers,
                            CostCenter = processInventoryItemsInErp.CustomerTransferSlip.BusinessUnitCode,
                            TargetERP = "JDE"
                        };
                        var request = JsonConvert.SerializeObject(validateInventoryRequest);
                        logger.LogInformation(request.ToString());

                        validateInventoryResponse = this.boomiWrapperService.ValidateInventory(validateInventoryRequest);
                        failurePartNumbers = validateInventoryResponse?.Result.Data
                            .Where(x => x.IsItemExistInRCC == "0")
                            .Select(o => o.PartNumber).Distinct().ToList();
                    }
                }
                /////////////////////
                #region Create ErpItemBatch
                CreateErpItemBatch(@event, processInventoryItemsInErp, customerTransferId, out erpItemsBatch, out erpItemsBatchNumber);
                #endregion

                #region Create payload and call boomi InventoryTransfer interface
                foreach (CustomerTransferSlipErpItem erpItem in processInventoryItemsInErp.ErpItems)
                {
                    #region Create ErpSoftCommitmentLog
                    CreateErpSoftCommitmentLog(@event, processInventoryItemsInErp, erpItemsBatchNumber, erpItem, erpOperation.ToString());
                    #endregion

                    if (validateInventoryResponse != null && validateInventoryResponse.Result.Data.Count > 0
                        && erpOperation == ErpOperations.ADD && failurePartNumbers.Count() > 0)
                    {
                        if (!failurePartNumbers.Any(x => x == erpItem.PartNumber))
                        {
                            ProcessSingleErpItem(processInventoryItemsInErp, erpOperation, erpItem, @event, boomiRequestId, inventoryTransferDetails);
                        }
                    }
                    else
                    {
                        ProcessSingleErpItem(processInventoryItemsInErp, erpOperation, erpItem, @event, boomiRequestId, inventoryTransferDetails);
                    }

                }

                var responseErpItems = JsonConvert.SerializeObject(processInventoryItemsInErp.ErpItems);
                logger.LogInformation("Final ERPItems : " + responseErpItems.ToString());

                var responseInventoryTransferDetails = JsonConvert.SerializeObject(inventoryTransferDetails);
                logger.LogInformation("Inventory Transfer Details : " + responseInventoryTransferDetails.ToString());
                InventoryTransferResponse inventoryTransferResponse = null;

                if (inventoryTransferDetails.Count > 0)
                {
                    ///Boomi InventoryTransfer call
                    inventoryTransferResponse = InventoryTransfer(
                       @event, processInventoryItemsInErp
                       , inventoryTransferDetails, boomiRequestId, erpOperation);
                }

                #endregion

                #region Update Success / Failure in ErpSoftCommitmentLog ,ErpItemsBatch
                if (inventoryTransferResponse == null)
                {
                    foreach (CustomerTransferSlipErpItem erpItem in processInventoryItemsInErp.ErpItems)
                    {
                        /// Update error message in case if RA Part Number is missing
                        if (failurePartNumbers.Any(a => a == erpItem.PartNumber))
                        {
                            erpItem.ErrorMessage = $"The following related part number(s) are missing for this base part number in the item branch of the Revenue BU: {erpItem.PartNumber}";
                        }
                    }
                }
                else if (inventoryTransferResponse != null && !inventoryTransferResponse.Success.Equals("1")
                   && inventoryTransferResponse.Errors != null && inventoryTransferResponse.Errors.Any())
                {
                    var errorMessage = JsonConvert.SerializeObject(inventoryTransferResponse.Errors);
                    erpSoftCommitmentLogService.Update(null, null, errorMessage, @event.ActionBy, erpItemsBatchNumber);
                    foreach (CustomerTransferSlipErpItem erpItem in processInventoryItemsInErp.ErpItems)
                    {
                        /// Update error message in case if RA Part Number is missing
                        if (failurePartNumbers.Any(a => a == erpItem.PartNumber))
                        {
                            erpItem.ErrorMessage = $"The following related part number(s) are missing for this base part number in the item branch of the Revenue BU: {erpItem.PartNumber}";
                        }
                        else
                        {
                            if (inventoryTransferResponse.DictErrors != null && inventoryTransferResponse.DictErrors.ContainsKey(erpItem.PartNumber.Trim()))
                            {
                                erpItem.ErrorMessage = inventoryTransferResponse.DictErrors[erpItem.PartNumber.Trim()].ErrorMsg;
                            }
                            else
                            {
                                erpItem.ErrorMessage = errorMessage;
                            }
                        }

                    }

                }
                else
                {
                    erpSoftCommitmentLogService.Update(inventoryTransferResponse.JDEDocNumber, inventoryTransferResponse.JDEDocType, null, @event.ActionBy, erpItemsBatchNumber);

                    foreach (CustomerTransferSlipErpItem erpItem in processInventoryItemsInErp.ErpItems)
                    {
                        erpItem.ErpDocNumber = inventoryTransferResponse.JDEDocNumber;
                        erpItem.ErpDocType = inventoryTransferResponse.JDEDocType;
                        erpItem.LastActionCompleted = true;
                        erpItem.PreviousQuantityShipped = erpItem.QuantityShipped;
                        /// Update error message in case if RA Part Number is missing
                        if (failurePartNumbers.Any(a => a == erpItem.PartNumber))
                        {
                            erpItem.ErrorMessage = $"The following related part number(s) are missing for this base part number in the item branch of the Revenue BU: {erpItem.PartNumber}";
                        }
                        else
                            erpItem.ErrorMessage = String.Empty;
                    }

                    erpItemsBatch.BatchCompleted = true;
                    erpItemsBatchService.Update(erpItemsBatch);
                }
                #endregion
            }
            return boomiRequestId;
        }

        public (FieldTransferSlip, HttpStatusCode,string) ProcessErpItemsForFieldTransfer(FieldTransferSlip fieldTransferSlip, Guid corelationId = new Guid())
        {
            if (fieldTransferSlip == null)
                return (null, HttpStatusCode.BadRequest,string.Empty);
            // Process Payload
            var boomiRequestId = Guid.Empty;
            var status = HttpStatusCode.Created;

            if (fieldTransferSlip.FieldTransferSlipDetails != null && fieldTransferSlip.FieldTransferSlipDetails.Any())
            {
                var inventoryTransferDetails = new List<InventoryTransferDetails>();
                var fieldTransferId = fieldTransferSlip.FieldTransferNumber;
                boomiRequestId = Guid.NewGuid();
                string toDisplayLocation = string.Empty;
                string toLocation = string.Empty;
                string fromLocation = string.Empty;
                bool isJobLocation = false;
                BusinessUnit businessUnit = businessUnitService.GetBusinessUnitByBU(fieldTransferSlip.FromCcCode);

                isJobLocation = (businessUnit.DivisionCode == "WS" && businessUnit.SubDivisionCode != "MDT") || (businessUnit.DivisionCode == "RH");

                if (isJobLocation) //(fieldTransferSlip.ToErpJobNumber != null && fieldTransferSlip.ToErpJobNumber > 0)
                {
                    toLocation = fieldTransferSlip.ToErpJobNumber.ToString();
                    fromLocation = fieldTransferSlip.FromErpJobNumber.ToString();
                }
                else
                {
                    toLocation = !string.IsNullOrEmpty(fieldTransferSlip.ToRigName) ? fieldTransferSlip.ToRigName.Replace(" ", ".") : "";
                    fromLocation = !string.IsNullOrEmpty(fieldTransferSlip.FromRigName) ? fieldTransferSlip.FromRigName.Replace(" ", ".") : "";
                }
                  /// create and add inventoryTransferDetail to InventoryTransferDetails
                #region Create payload and call boomi InventoryAdjustment interface
                foreach (FieldTransferSlipDetail erpItem in fieldTransferSlip.FieldTransferSlipDetails)
                {
                    if (erpItem.QuantityShipped != null && erpItem.QuantityShipped > 0)
                    {
                        var inventoryTransferDetail = new InventoryTransferDetails()
                        {
                            InventoryTransactionType = "Reclassification",
                            FromItemNumber = erpItem.PartNumber,
                            FromBU = fieldTransferSlip.FromCcCode,
                            ToBU = fieldTransferSlip.ToCcCode,
                            CAllowHeldLot = "1",
                            CFromTo = "F",
                            PODefaultLotStatus = "2",
                            CToLotStatusCode = "N",
                            CLotStatusCode = "N",
                            ToSerialNumber = erpItem.ItemSerialNumber,
                            ToItemNumber = erpItem.PartNumber,
                            ToDisplayLocation = toDisplayLocation,
                            FromDisplayLocation = "",
                            UpdateQuantityOnHand = "1",
                            AllowQtyOverAvailable = "",
                            JDEJobNumber = "",
                            FromLotNumber = erpItem.ItemSerialNumber,
                            FromSerialNumber = erpItem.ItemSerialNumber,
                            FromQuantity = Convert.ToString(erpItem.QuantityShipped * -1),
                            ToQuantity = Convert.ToString(erpItem.QuantityShipped),
                            FromLocation = fromLocation,
                            ToLocation = toLocation
                        };
                        inventoryTransferDetails.Add(inventoryTransferDetail);
                    }
                    if (erpItem.QuantityMiscReceipt != null && erpItem.QuantityMiscReceipt > 0)
                    {
                        var inventoryTransferDetail = new InventoryTransferDetails()
                        {
                            InventoryTransactionType = "Adjustment",
                            FromItemNumber = erpItem.PartNumber,
                            FromBU = fieldTransferSlip.ToCcCode,// fieldTransferSlip.FromCcCode,
                           // ToBU = fieldTransferSlip.ToCcCode,
                            CAllowHeldLot = "1",
                            CFromTo = "F",
                            PODefaultLotStatus = "2",
                            //CToLotStatusCode = "N",
                            CLotStatusCode = "N",
                            //ToSerialNumber = erpItem.ItemSerialNumber,
                            ToItemNumber = erpItem.PartNumber,
                            ToDisplayLocation = toDisplayLocation,
                            FromDisplayLocation = "",
                            UpdateQuantityOnHand = "1",
                            AllowQtyOverAvailable = "",
                            JDEJobNumber = "",
                            FromLotNumber = erpItem.ItemSerialNumber,
                            FromSerialNumber = erpItem.ItemSerialNumber,
                            FromQuantity = Convert.ToString(erpItem.QuantityMiscReceipt),
                            //ToQuantity = Convert.ToString(erpItem.QuantityMiscReceipt),
                            FromLocation = toLocation,
                            ToLocation = erpItem.ItemSerialNumber
                        };
                        inventoryTransferDetails.Add(inventoryTransferDetail);
                    }
                 }
                //var responseErpItems = JsonConvert.SerializeObject(processInventoryItemsInErp.ErpItems);
                //logger.LogInformation("Final ERPItems : " + responseErpItems.ToString());

                var responseInventoryTransferDetails = JsonConvert.SerializeObject(inventoryTransferDetails);
                logger.LogInformation("Inventory Transfer Details : " + responseInventoryTransferDetails.ToString());

                logger.LogInformation($"{this.GetType()} : headers : {JsonConvert.SerializeObject(httpContextAccessor.HttpContext.Request.Headers,new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore})}");

                InventoryTransferResponse inventoryTransferResponse = null;

                GenerateInventoryTransferRequest generateInventoryTransferRequest = new GenerateInventoryTransferRequest()
                {
                    Version = Constants.Version_DDSOPS0001,
                    TransferSlipNumber = fieldTransferSlip.FieldTransferNumber.ToString(),
                    CreatedDate = fieldTransferSlip.TransferDate.Value,
                    ActionBy = fieldTransferSlip.ModifiedBy,
                    CorelationId = corelationId,
                    ErpType = "",
                    KeyName = Constants.FTS,
                    KeyValue = fieldTransferSlip.FieldTransferNumber.ToString(),
                    EventId = fieldTransferSlip.EventInfoId,
                    RequestId = boomiRequestId,
                    TargetERP = Constants.TargetERP_JDE,
                    TransactionType = Constants.TransactionType_RT,
                    TransferSlipOrderType = Constants.TransferSlipOrderType_TT,
                    TargetInterface = Constants.TargetInterface_InventoryAdjustment,
                    FromBranchPlant = inventoryTransferDetails[0]?.FromBU,
                    ToBranchPlant = inventoryTransferDetails[0]?.ToBU,
                    Details = inventoryTransferDetails,
                };

                if (inventoryTransferDetails.Count > 0)
                {
                    try
                    {
                        ///Boomi InventoryAdjustment call
                        inventoryTransferResponse = InventoryAdjustment(generateInventoryTransferRequest);
                    }
                    catch (System.Exception ex)
                    {
                        return (null,HttpStatusCode.ExpectationFailed,ex.Message);
                    }
                }

                #endregion
                #region Update Success / Failure in ErpSoftCommitmentLog ,ErpItemsBatch
                if (inventoryTransferResponse != null && !inventoryTransferResponse.Success.Equals("1")
                   && inventoryTransferResponse.Errors != null && inventoryTransferResponse.Errors.Any())
                {
                    var errorMessage = JsonConvert.SerializeObject(inventoryTransferResponse.Errors);
                    foreach (FieldTransferSlipDetail erpItem in fieldTransferSlip.FieldTransferSlipDetails)
                    {
                        if (inventoryTransferResponse.DictErrors != null && inventoryTransferResponse.DictErrors.ContainsKey(erpItem.PartNumber.Trim()))
                        {
                            erpItem.ErrorMessage = inventoryTransferResponse.DictErrors[erpItem.PartNumber.Trim()].ErrorMsg;
                        }
                        else
                        {
                            erpItem.ErrorMessage = errorMessage;
                        }
                    }
                    status = HttpStatusCode.InternalServerError;
                }
                else
                {
                    foreach (FieldTransferSlipDetail erpItem in fieldTransferSlip.FieldTransferSlipDetails)
                    {
                        erpItem.ErpDocNumber = inventoryTransferResponse.JDEDocNumber;
                        erpItem.ErpDocType = inventoryTransferResponse.JDEDocType;
                        erpItem.LastActionCompleted = true;
                        erpItem.ErrorMessage = String.Empty;
                    }
                }
                #endregion
            }
            //return boomiRequestId;
            return (fieldTransferSlip, status,string.Empty);
        }

        private InventoryTransferResponse InventoryAdjustment(GenerateInventoryTransferRequest generateInventoryTransferRequest)
        {
            var inventoryTransferResponse = boomiWrapperService.InventoryTransfer(generateInventoryTransferRequest).Result;
            return inventoryTransferResponse;
        }
        private void ProcessSingleErpItem(ProcessInventoryItemsInErp processInventoryItemsInErp, ErpOperations erpOperation,
            CustomerTransferSlipErpItem erpItem, SagaEvent @event, Guid boomiRequestId, List<InventoryTransferDetails> inventoryTransferDetails)
        {
            /// create and add inventoryTransferDetail to InventoryTransferDetails
            var inventoryTransferDetail = new InventoryTransferDetails()
            {
                FromItemNumber = erpItem.PartNumber,
                FromBU = processInventoryItemsInErp.CustomerTransferSlip.SendingBuCode,
                ToBU = processInventoryItemsInErp.CustomerTransferSlip.SendingBuCode,
                CAllowHeldLot = "1",
                CToLotStatusCode = "",
                ToSerialNumber = erpItem.PartSerialNumber,
                ToItemNumber = erpItem.PartNumber,
                FromQuantity = "",
                ToQuantity = "",
                ToDisplayLocation = "",
                FromDisplayLocation = "",
                UpdateQuantityOnHand = "",
                AllowQtyOverAvailable = "",
                JDEJobNumber = "",
                FromLotNumber = erpItem.PartSerialNumber,
            };
            if (erpOperation == ErpOperations.RESUBMIT || (erpOperation == ErpOperations.UPDATE && !string.IsNullOrEmpty(erpItem.ErrorMessage)))
                erpItem.PreviousQuantityShipped = GetJdeQuantityShipped(@event, boomiRequestId, erpItem
                    , processInventoryItemsInErp);

            if (erpOperation == ErpOperations.ADD || (erpOperation == ErpOperations.UPDATE
                && (erpItem.QuantityShipped - erpItem.PreviousQuantityShipped) > 0) ||
                (erpOperation == ErpOperations.RESUBMIT
                && (erpItem.QuantityShipped - erpItem.PreviousQuantityShipped) > 0))
            {
                inventoryTransferDetail.FromDisplayLocation = erpItem.ErpLocation;
                inventoryTransferDetail.ToDisplayLocation = Constants.STAGING;
            }
            else
            {
                inventoryTransferDetail.FromDisplayLocation = Constants.STAGING;
                inventoryTransferDetail.ToDisplayLocation = erpItem.ErpLocation;
            }

            var qty = erpItem.QuantityShipped - erpItem.PreviousQuantityShipped;
            logger.LogInformation($"QuantityShipped {erpItem.QuantityShipped} ConsolidatedQuantityShipped {erpItem.ConsolidatedQuantityShipped}  PreviousQuantityShipped {erpItem.PreviousQuantityShipped}");
            logger.LogInformation($"Quantity {qty}");
            if (erpOperation == ErpOperations.ADD || (erpOperation == ErpOperations.DELETE && string.IsNullOrEmpty(erpItem.ErrorMessage)))
                inventoryTransferDetail.FromQuantity = (erpItem.QuantityShipped * 1).ToString();
            else if (erpOperation == ErpOperations.DELETE && !string.IsNullOrEmpty(erpItem.ErrorMessage))
            {
                inventoryTransferDetail.FromQuantity = GetJdeQuantityShipped(@event, boomiRequestId, erpItem
                    , processInventoryItemsInErp).ToString();
            }
            else if (erpOperation == ErpOperations.UPDATE || erpOperation == ErpOperations.RESUBMIT)
            {
                inventoryTransferDetail.FromQuantity = Math.Abs(qty).ToString();
            }

            inventoryTransferDetails.Add(inventoryTransferDetail);
        }
        private decimal GetJdeQuantityShipped(SagaEvent @event, Guid boomiRequestId
            , CustomerTransferSlipErpItem erpItem, ProcessInventoryItemsInErp processInventoryItemsInErp)
        {
            decimal quantityAvailable = 0;
            GetJdeInventoryRequest getJdeInventoryRequest = new GetJdeInventoryRequest()
            {
                ActionBy = @event.ActionBy,
                CorelationId = @event.CorelationId,
                ErpType = Constants.TargetERP_JDE,
                KeyName = Constants.CDS,
                KeyValue = GetErpAction(ErpOperations.RESUBMIT),
                EventId = processInventoryItemsInErp.EventInfo.ParentEventInfoId != null
                ? processInventoryItemsInErp.EventInfo.ParentEventInfoId : 0,
                RequestId = boomiRequestId,
                TargetERP = Constants.TargetERP_JDE,
                PartNumber = erpItem.PartNumber,
                ReferenceNumber = processInventoryItemsInErp.CustomerTransferSlip.CustomerTransferNumber,
            };
            var jdeInventoryResponse = boomiWrapperService.GetJdeInventory(getJdeInventoryRequest).Result;

            if (!(jdeInventoryResponse.Errors != null && jdeInventoryResponse.Errors.Any()
                    && !string.IsNullOrEmpty(jdeInventoryResponse.Errors.FirstOrDefault().Error)))
            {
                foreach (var jdeInventory in from jdeInventory in jdeInventoryResponse.Data
                                             where jdeInventory.Location.Equals(Constants.STAGING)
                                             && jdeInventory.BusinessUnit
                                             == processInventoryItemsInErp.CustomerTransferSlip.SendingBuCode
                                             && jdeInventory.SerialNumber.Equals(erpItem.PartSerialNumber)
                                             select jdeInventory)
                {
                    quantityAvailable += Convert.ToDecimal(jdeInventory.QuantityAvailable) / 1000;
                }
            }
            logger.LogInformation($"quantityAvailable from JDE {quantityAvailable}");
            return quantityAvailable;
        }

        private InventoryTransferResponse InventoryTransfer(SagaEvent @event
            , ProcessInventoryItemsInErp saveErpItemsRequest
            , List<InventoryTransferDetails> inventoryTransferDetails
            , Guid boomiRequestId, ErpOperations erpOperation)
        {
            GenerateInventoryTransferRequest generateInventoryTransferRequest = new GenerateInventoryTransferRequest()
            {
                Version = Constants.Version_DDSOPS0001,
                TransferSlipNumber = saveErpItemsRequest.CustomerTransferSlip.CustomerTransferNumber.ToString(),
                CreatedDate = DateTime.UtcNow,
                ActionBy = @event.ActionBy,
                CorelationId = @event.CorelationId,
                ErpType = saveErpItemsRequest.ErpType,
                KeyName = Constants.CDS,
                KeyValue = GetErpAction(erpOperation),
                EventId = saveErpItemsRequest.EventInfo.ParentEventInfoId != null ? saveErpItemsRequest.EventInfo.ParentEventInfoId : 0,
                RequestId = boomiRequestId,
                TargetERP = saveErpItemsRequest.ErpType,
                TransactionType = Constants.TransactionType_RI,
                TransferSlipOrderType = Constants.TransferSlipOrderType_TT,
                TargetInterface = Constants.TargetInterface_InventoryTransfer,
                FromBranchPlant = inventoryTransferDetails[0]?.FromBU,
                ToBranchPlant = inventoryTransferDetails[0]?.ToBU,
                Details = inventoryTransferDetails,
            };

            var inventoryTransferResponse = boomiWrapperService.InventoryTransfer(generateInventoryTransferRequest).Result;
            return inventoryTransferResponse;
        }

        private static string GetErpAction(ErpOperations erpOperation)
        {
            if (erpOperation == ErpOperations.ADD)
                return Constants.AddERPItems;
            if (erpOperation == ErpOperations.UPDATE)
                return Constants.UpdateERPItems;
            if (erpOperation == ErpOperations.RESUBMIT)
                return Constants.ResubmitERPItems;
            return Constants.DeleteERPItems;
        }

        private void CreateErpSoftCommitmentLog(SagaEvent @event, ProcessInventoryItemsInErp saveErpItemsRequest, int erpItemsBatchNumber, CustomerTransferSlipErpItem erpItem, string tatLineAction)
        {
            var erpSoftCommitmentLog = new ErpSoftCommitmentLog()
            {
                // Id = Guid.NewGuid(),
                Id = 0,
                TatOrderType = Constants.CDS,
                TatOrderLineId = erpItem.ItemId,
                TatLineAction = tatLineAction,
                ErpType = saveErpItemsRequest.ErpType,
                CreatedBy = @event.ActionBy,
                ErpItemsBatchId = erpItemsBatchNumber
            };
            erpSoftCommitmentLogService.CreateErpSoftCommitmentLog(erpSoftCommitmentLog);
            erpItem.LastErpSoftCommitmentId = erpSoftCommitmentLog.Id;
        }

        private void CreateErpItemBatch(SagaEvent @event, ProcessInventoryItemsInErp saveErpItemsRequest, int customerTransferId, out ErpItemsBatch erpItemsBatch, out int erpItemsBatchNumber)
        {
            erpItemsBatch = new ErpItemsBatch()
            {
                // Id = Guid.NewGuid(),
                Id = 0,
                TatSlipType = Constants.CDS,
                TatSlipId = customerTransferId,
                BatchCompleted = false,
                ErpType = saveErpItemsRequest.ErpType,
                CreatedBy = @event.ActionBy,
                DateCreated = @event.CreationDate,

            };
            erpItemsBatchNumber = erpItemsBatchService.CreateErpItemsBatch(erpItemsBatch);
        }
    }
}
