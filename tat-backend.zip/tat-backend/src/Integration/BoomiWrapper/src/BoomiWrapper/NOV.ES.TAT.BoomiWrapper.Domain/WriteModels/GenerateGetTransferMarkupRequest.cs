﻿namespace NOV.ES.TAT.BoomiWrapper.Domain.WriteModels
{
    public class GenerateGetTransferMarkupRequest : BoomiRequestBaseModel
	{
        public int AddressNumber { get; set; }
        public int BusinessUnit { get; set; }
		public string ItemNumber { get; set; }
		public string SalesReportingCode2 { get; set; }
    }
}
