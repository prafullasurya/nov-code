﻿namespace NOV.ES.TAT.BoomiWrapper.DomainService.RequestModel
{
    public class ExchangeRateRequest : BaseRequestModel
    {
        public string CurrencyCodeFrom { get; set; }
        public string CurrencyCodeTo { get; set; }
        public DateTime ExchangeDate { get; set; }
    }
}
