import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerReturnMiscInfoCompletedComponent } from './customer-return-misc-info-completed.component';

describe('CustomerReturnMiscInfoCompletedComponent', () => {
  let component: CustomerReturnMiscInfoCompletedComponent;
  let fixture: ComponentFixture<CustomerReturnMiscInfoCompletedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerReturnMiscInfoCompletedComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerReturnMiscInfoCompletedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
