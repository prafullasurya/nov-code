﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetProductTypeByIdHandler : IQueryHandler<GetProductTypeByIdQuery, ProductTypeDto>
    {
        private readonly IMapper mapper;
        private readonly IProductTypeService productTypeService;

        public GetProductTypeByIdHandler(
            IMapper mapper,
            IProductTypeService productTypeService)
        {
            this.mapper = mapper;
            this.productTypeService = productTypeService;
        }

        public Task<ProductTypeDto> Handle(GetProductTypeByIdQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var ProductType = productTypeService.GetProductTypeById(request.Id);
            var result = mapper.Map<ProductType, ProductTypeDto>(ProductType);
            return Task.FromResult(result);
        }
        private static bool IsValidRequest(GetProductTypeByIdQuery request)
        {
            return (request != null && request.Id != 0);
        }
    }
}