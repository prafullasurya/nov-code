﻿using FluentValidation;
using NOV.ES.TAT.CustomerTransfer.EventSourcing.API.Application.Commands;
using NOV.ES.TAT.FrontEnd.API.Application;
using NOV.ES.TAT.FrontEnd.API.Constant;

namespace NOV.ES.TAT.FrontEnd.API.Validators
{
    public class MaintenanceInfoCommandValidator
        : AbstractValidator<AddMaintenanceInfoCommand>
    {
        public MaintenanceInfoCommandValidator()
        {
            RuleFor(o => o.MessageId).NotNull().NotEmpty().WithMessage(string.Format(Constants.EMPTY_MESSAGE, "MessageId"));
            RuleFor(o => o.DownTimeReason).NotNull().NotEmpty().WithMessage(string.Format(Constants.EMPTY_MESSAGE, "DownTimeReason"));
            RuleFor(o => o.ScheduledOn).NotNull().WithMessage(string.Format(Constants.EMPTY_MESSAGE, "ScheduledOn"));
            RuleFor(o => o.ExpectedResumeBy).NotNull().WithMessage(string.Format(Constants.EMPTY_MESSAGE, "ExpectedResumeBy"));
        }
    }

    public class MarkAsCompletedCommaandValidator
        : AbstractValidator<MarkAsCompletedCommaand>
    {
        public MarkAsCompletedCommaandValidator()
        {
            //RuleFor(o => o.Id).GreaterThan(0).WithMessage(string.Format(Constants.EMPTY_MESSAGE, "Id"));
        }
    }
}
