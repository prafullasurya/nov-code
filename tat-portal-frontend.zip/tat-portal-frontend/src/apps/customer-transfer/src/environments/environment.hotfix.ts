export const environment = {
    production: true,
    apiHostUrl: 'https://tatservicehotfix.nov.cloud',
    errorLoggingApiEndPoint:'https://tatservicehotfix.nov.cloud/frontendcommonsvc/ErrorLogging',
    gridPageSize:50,
    dropdownPazeSize:100,
    assemblyUrl: 'https://wbtrn.nov.com/tat/Tools/ToolsDetails.aspx?id=',
    componentUrl: 'https://wbtrn.nov.com/tat/Components/ComponentsDetails.aspx?id=',
    usageUrl: 'https://wbtrn.nov.com/tat/Usages/UsagesDetails.aspx?id=',
    OldTatURl: 'https://wbtrn.nov.com/tat/',
  };
  