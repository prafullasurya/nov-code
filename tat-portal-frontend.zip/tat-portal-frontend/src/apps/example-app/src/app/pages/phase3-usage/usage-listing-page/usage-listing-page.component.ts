import { Component } from '@angular/core';


@Component({
  selector: 'usage-listing-page',
  templateUrl: './usage-listing-page.component.html',
  styleUrls: ['./usage-listing-page.component.scss'],
})

export class UsageListingPageComponent {

}
