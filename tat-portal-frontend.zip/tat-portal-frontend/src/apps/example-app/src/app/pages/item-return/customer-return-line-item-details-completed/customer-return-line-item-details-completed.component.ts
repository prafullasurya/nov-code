import { Component} from '@angular/core';

interface City {
  name: string,
  code: string
}
@Component({
  selector: 'customer-return-line-item-details-completed',
  templateUrl: './customer-return-line-item-details-completed.component.html',
  styleUrls: ['./customer-return-line-item-details-completed.component.scss']
})
export class CustomerReturLineItemDetailsCompletedComponent {
  
  displayAddMiscReceiptItem: boolean;
  displayModal: boolean;
  displayCompleteFieldTransferSlip: boolean;
  displayonfirmAssemblyNft: boolean;
  displaySearchInventory: boolean;

  //Dialog
  showAddMiscReceiptItem() {
    this.displayAddMiscReceiptItem = true;//showAddMiscReceiptItem
  }

  //Data Validation Message
  showModalDialog() {
    this.displayModal = true;
  }

  showCompleteFieldTransferSlip() {
    this.displayCompleteFieldTransferSlip = true;
  }

  showConfirmAssemblyNftDialog() {
    this.displayonfirmAssemblyNft = true;
  } 

  showNftSearchinventoryDialog() {
    this.displaySearchInventory = true;
  } 


}
