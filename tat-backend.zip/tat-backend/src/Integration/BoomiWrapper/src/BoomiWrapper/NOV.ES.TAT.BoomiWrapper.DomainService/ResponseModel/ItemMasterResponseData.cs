﻿namespace NOV.ES.TAT.BoomiWrapper.DomainService.ResponseModel
{
    public class ItemMasterResponseData
    {
        public string Description1 { get; set; }
        public string Description2 { get; set; }
        public string UnitOfMeasureWeight { get; set; }
        public string Weight { get; set; }
        public string partNumber { get; set; }
        public string RAPartNumber { get; set; }
        public string UserDefinedCode { get; set; }
    }
}
