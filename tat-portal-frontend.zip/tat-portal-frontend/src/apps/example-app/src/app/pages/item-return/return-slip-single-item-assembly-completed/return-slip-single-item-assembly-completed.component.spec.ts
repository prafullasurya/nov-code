import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReturnSlipSingleItemAssemblyCompletedComponent } from './return-slip-single-item-assembly-completed.component';

describe('ReturnSlipSingleItemAssemblyCompletedComponent', () => {
  let component: ReturnSlipSingleItemAssemblyCompletedComponent;
  let fixture: ComponentFixture<ReturnSlipSingleItemAssemblyCompletedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReturnSlipSingleItemAssemblyCompletedComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReturnSlipSingleItemAssemblyCompletedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
