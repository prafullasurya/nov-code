import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerReturnAddInventoryComponent } from './customer-return-add-inventory.component';

describe('CustomerReturnAddInventoryComponent', () => {
  let component: CustomerReturnAddInventoryComponent;
  let fixture: ComponentFixture<CustomerReturnAddInventoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerReturnAddInventoryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerReturnAddInventoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
