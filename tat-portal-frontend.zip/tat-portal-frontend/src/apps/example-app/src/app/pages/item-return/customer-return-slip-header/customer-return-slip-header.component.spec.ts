import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerReturnSlipHeaderComponent } from './customer-return-slip-header.component';

describe('CustomerReturnSlipComponent', () => {
  let component: CustomerReturnSlipHeaderComponent;
  let fixture: ComponentFixture<CustomerReturnSlipHeaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerReturnSlipHeaderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerReturnSlipHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
