﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetUserPreferenceByUserQuery : IQuery<IEnumerable<UserPreferenceDto>>
    {
        public int UserId { get; private set; }

        public GetUserPreferenceByUserQuery(int userId)
        {
            this.UserId = userId;
        }
    }
}