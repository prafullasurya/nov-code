﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetTatReferenceByTITANIdQuery : IQuery<TatReferenceDto>
    {
        public int TitanId { get; private set; }
        public GetTatReferenceByTITANIdQuery(int titanId)
        {
            this.TitanId = titanId;
        }
    }
}
