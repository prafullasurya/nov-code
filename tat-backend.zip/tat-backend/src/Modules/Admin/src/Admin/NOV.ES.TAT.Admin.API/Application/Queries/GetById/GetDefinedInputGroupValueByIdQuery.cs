﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;


namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetDefinedInputGroupValueByIdQuery : IQuery<DefinedInputGroupValueDto>
    {
        public int DefinedInputGroupValueId { get; private set; }
        public GetDefinedInputGroupValueByIdQuery(int definedInputGroupValueId)
        {
            this.DefinedInputGroupValueId = definedInputGroupValueId;
        }
    }
}
