import { Component} from '@angular/core';

interface City {
  name: string,
  code: string
}
@Component({
  selector: 'nft-tat-item',
  templateUrl: './nft-line-item-details.component.html',
  styleUrls: ['./nft-line-item-details.component.scss']
})
export class nftLineItemDetailsComponent {
  
  displayAddMiscReceiptItem: boolean;
  displayModal: boolean;
  displayCompleteFieldTransferSlip: boolean;
  displayonfirmAssemblyNft: boolean;
  displaySearchInventory: boolean;

  //Dialog
  showAddMiscReceiptItem() {
    this.displayAddMiscReceiptItem = true;//showAddMiscReceiptItem
  }

  //Data Validation Message
  showModalDialog() {
    this.displayModal = true;
  }

  showCompleteFieldTransferSlip() {
    this.displayCompleteFieldTransferSlip = true;
  }

  showConfirmAssemblyNftDialog() {
    this.displayonfirmAssemblyNft = true;
  } 

  showNftSearchinventoryDialog() {
    this.displaySearchInventory = true;
  } 


}
