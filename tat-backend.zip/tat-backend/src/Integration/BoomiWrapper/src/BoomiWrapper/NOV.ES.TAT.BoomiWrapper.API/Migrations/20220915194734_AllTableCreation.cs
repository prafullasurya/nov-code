﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace NOV.ES.TAT.BoomiWrapper.API.Migrations
{
    public partial class AllTableCreation : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "BoomiRequestResponse",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RequestId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    CorelationId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    EventId = table.Column<long>(type: "bigint", nullable: true),
                    KeyName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    KeyValue = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    RequestDateTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    RequestStatus = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    RequestBody = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RequestURL = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    RequestMethod = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    HttpVerb = table.Column<string>(type: "nvarchar(8)", maxLength: 8, nullable: true),
                    RequestQueryParameters = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SourceApplication = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    SourceIPAddress = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    MachineName = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    Status = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    ErrorMessage = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ResponseStatus = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    ResponseBody = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ResponseDateTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    RetryCount = table.Column<int>(type: "int", nullable: false),
                    ActionBy = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    ProcessId = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    ProcessName = table.Column<string>(type: "nvarchar(512)", maxLength: 512, nullable: true),
                    ThreadName = table.Column<string>(type: "nvarchar(512)", maxLength: 512, nullable: true),
                    ThreadId = table.Column<string>(type: "nvarchar(128)", maxLength: 128, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BoomiRequestResponse", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ErpItemsBatch",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ErpItemsBatchNumber = table.Column<int>(type: "int", nullable: false),
                    TATSlipType = table.Column<string>(type: "nvarchar(5)", maxLength: 5, nullable: false),
                    TATSlipId = table.Column<int>(type: "int", nullable: false),
                    TATErrorMessage = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ErpErrorMessage = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    BatchCompleted = table.Column<bool>(type: "bit", nullable: false),
                    ErpType = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    DateCreated = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    DateModified = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ModifiedBy = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    CreatedSource = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: true),
                    ModifiedSource = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: true),
                    TATReferenceId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ErpItemsBatch", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ErpSoftCommitmentLog",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ErpItemsBatchId = table.Column<int>(type: "int", nullable: true),
                    TATOrderType = table.Column<string>(type: "nvarchar(5)", maxLength: 5, nullable: true),
                    TATOrderLineId = table.Column<int>(type: "int", nullable: true),
                    TATLineAction = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: true),
                    ErpDocType = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: true),
                    ErpDocNumber = table.Column<string>(type: "nvarchar(25)", maxLength: 25, nullable: true),
                    ErrorMessage = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true),
                    ErpType = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    DateCreated = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    DateModified = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ModifiedBy = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    CreatedSource = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: true),
                    ModifiedSource = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: true),
                    TATReferenceId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ErpSoftCommitmentLog", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "RemitoCompanyInterfaceMapping",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Company = table.Column<string>(type: "nvarchar(28)", maxLength: 28, nullable: true),
                    InterfaceName = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    LastUdatedBy = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    DateCreated = table.Column<DateTime>(type: "datetime2", nullable: false),
                    DateModified = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RemitoCompanyInterfaceMapping", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "BoomiRequestResponse");

            migrationBuilder.DropTable(
                name: "ErpItemsBatch");

            migrationBuilder.DropTable(
                name: "ErpSoftCommitmentLog");

            migrationBuilder.DropTable(
                name: "RemitoCompanyInterfaceMapping");
        }
    }
}
