﻿using NOV.ES.Framework.Core.Data.Repositories;
using NOV.ES.TAT.BoomiWrapper.Domain;

namespace NOV.ES.TAT.BoomiWrapper.Infrastructure
{
    public interface IErpSoftCommitmentLogCommandRepository
        : IWriteRepository<ErpSoftCommitmentLog>
    {
        void Update(string erpDocNumber, string erpDocType, string errorMessage, string lastUpdateBy, int latestBatchId);
        public int SaveChanges();
        public Task<int> SaveChangesAsync(CancellationToken cancellationToken);
    }
}
