﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetModuleByIdHandler : IQueryHandler<GetModuleByIdQuery, ModuleDto>
    {
        private readonly IMapper mapper;
        private readonly IModuleService moduleService;

        public GetModuleByIdHandler(
            IMapper mapper,
            IModuleService moduleService)
        {
            this.mapper = mapper;
            this.moduleService = moduleService;
        }

        public Task<ModuleDto> Handle(GetModuleByIdQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var module = moduleService.GetModuleById(request.Id);
            var result = mapper.Map<Module, ModuleDto>(module);
            return Task.FromResult(result);
        }
        private static bool IsValidRequest(GetModuleByIdQuery request)
        {
            return (request != null && request.Id != 0);
        }
    }
}