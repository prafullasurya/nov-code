﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.API.Helper;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetUserPreferencesByUserIdAndModuleIdHandler 
        : IQueryHandler<GetUserPreferencesByUserIdAndModuleIdQuery
            , PagedResult<UserPreferenceDto>>
    {
        private readonly IUserPreferenceService userPreferenceService;
        private readonly IMapper mapper;
        private readonly IHttpContextAccessor httpContextAccessor;
        public GetUserPreferencesByUserIdAndModuleIdHandler(
             IUserPreferenceService userPreferenceService
            , IMapper mapper
            , IHttpContextAccessor httpContextAccessor)
        {            
            this.userPreferenceService = userPreferenceService;
            this.mapper = mapper;
            this.httpContextAccessor = httpContextAccessor;
        }
        public Task<PagedResult<UserPreferenceDto>> Handle(GetUserPreferencesByUserIdAndModuleIdQuery request, CancellationToken cancellationToken)
        {
            if(!IsValidRequest(request))
                throw new ArgumentException("Value can not be null or Empty");

            var result = userPreferenceService.GetUserPreferences(request.PagingParameters,request.UserId,request.ModuleId);
            var pagedResult = mapper.Map<PagedResult<UserPreference>, PagedResult<UserPreferenceDto>>(result);
            PagingHelper.AddPagingMetadata(pagedResult, httpContextAccessor);
            return Task.FromResult(pagedResult);
        }

        private static bool IsValidRequest(GetUserPreferencesByUserIdAndModuleIdQuery request)
        {
            //if (request != null &&( request.UserId != 0 || request.ModuleId != 0))

                if (request != null)
                    return true;
            return false;
        }
    }
}