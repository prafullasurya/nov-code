﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.API.Helper;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetPaginationAssetAccountsHandler
           : IQueryHandler<GetPaginationAssetAccountsQuery, PagedResult<AssetAccountDto>>
    {
        private readonly IMapper mapper;
        private readonly IAssetAccountService assetAccountService;
        private readonly IHttpContextAccessor httpContextAccessor;

        public GetPaginationAssetAccountsHandler(
            IMapper mapper
            ,IAssetAccountService assetAccountService
            , IHttpContextAccessor httpContextAccessor)
        {
            this.mapper = mapper;
            this.assetAccountService = assetAccountService;
            this.httpContextAccessor = httpContextAccessor;
        }

        public Task<PagedResult<AssetAccountDto>> Handle(GetPaginationAssetAccountsQuery request,
          CancellationToken cancellationToken)
        {
            var assetAccounts = assetAccountService.GetAssetAccounts(request.PagingParameters);
            var result = mapper.Map<PagedResult<AssetAccount>, PagedResult<AssetAccountDto>>(assetAccounts);
            PagingHelper.AddPagingMetadata<AssetAccountDto>(result, httpContextAccessor);
            return Task.FromResult(result);
        }
    }
}