import { Component, OnInit } from '@angular/core';
import {TreeNode} from 'primeng/api';
import { ProductService } from '../../models/productservice';
import { Product } from '../../models/product';

interface City {
  name: string,
  code: string
}

@Component({
  selector: 'tat-portal-frontend-location-change',
  templateUrl: './location-change.component.html',
  styleUrls: ['./location-change.component.scss']
})
export class LocationChangeComponent implements OnInit {
  displayBasic1: boolean;
  displayAddMiscReceiptItem: boolean;
  displayModal: boolean;
  displayCreateNewFinancialTransfer: boolean;
  displayAdvanceSearch: boolean;

  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }

  showBasicDialog() {
    this.displayBasic1 = true;
  }

  //Dialog Advance Search
  showAdvanceSearch() {
    this.displayAdvanceSearch = true;//showAddMiscReceiptItem
  }

  //Data Validation Message
  showModalDialog() {
    this.displayModal = true;
  }

  showCreateNewFinancialTransfer() {
    this.displayCreateNewFinancialTransfer = true;
  }
}
