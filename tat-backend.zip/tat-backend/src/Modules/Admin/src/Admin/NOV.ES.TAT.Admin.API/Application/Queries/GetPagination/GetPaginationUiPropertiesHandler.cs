﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.API.Helper;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetPaginationUiPropertiesHandler
           : IQueryHandler<GetPaginationUiPropertiesQuery, PagedResult<UiPropertyDto>>
    {
        private readonly IMapper mapper;
        private readonly IUiPropertyService uiPropertyService;
        private readonly IHttpContextAccessor httpContextAccessor;

        public GetPaginationUiPropertiesHandler(
             IMapper mapper
            , IUiPropertyService uiPropertyService
            , IHttpContextAccessor httpContextAccessor)
        {            
            this.mapper = mapper;
            this.uiPropertyService = uiPropertyService;
            this.httpContextAccessor = httpContextAccessor;
        }

        public Task<PagedResult<UiPropertyDto>> Handle(GetPaginationUiPropertiesQuery request,
          CancellationToken cancellationToken)
        {
            var uiProperties = uiPropertyService.GetUiProperties(request.PagingParameters);
            var result = mapper.Map<PagedResult<UiProperty>, PagedResult<UiPropertyDto>>(uiProperties);
            PagingHelper.AddPagingMetadata<UiPropertyDto>(result, httpContextAccessor);
            return Task.FromResult(result);
        }
    }
}