import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ftsFromToolDetailsComponent } from './fts-from-tool-details.component';

describe('ftsFromToolDetailsComponent', () => {
  let component: ftsFromToolDetailsComponent;
  let fixture: ComponentFixture<ftsFromToolDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ftsFromToolDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ftsFromToolDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
