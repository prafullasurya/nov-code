﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetCompanyConfigByCompanyCodeHandler : IQueryHandler<GetCompanyConfigByCompanyCodeQuery, CompanyConfigDto>
    {
        private readonly IMapper mapper;
        private readonly ICompanyConfigService companyConfigService;

        public GetCompanyConfigByCompanyCodeHandler(
            IMapper mapper,
            ICompanyConfigService companyConfigService)
        {
            this.mapper = mapper;
            this.companyConfigService = companyConfigService;
        }

        public Task<CompanyConfigDto> Handle(GetCompanyConfigByCompanyCodeQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var companyConfig = companyConfigService.GetCompanyConfigByCompanyCode(request.CompanyCode);
            var result = mapper.Map<CompanyConfig, CompanyConfigDto>(companyConfig);
            return Task.FromResult(result);
        }
        private static bool IsValidRequest(GetCompanyConfigByCompanyCodeQuery request)
        {
            return (request != null && !string.IsNullOrEmpty(request.CompanyCode));
        }
    }
}