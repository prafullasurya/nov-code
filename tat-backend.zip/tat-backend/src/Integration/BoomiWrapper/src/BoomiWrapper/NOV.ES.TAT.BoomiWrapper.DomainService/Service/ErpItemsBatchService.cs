﻿using NOV.ES.TAT.BoomiWrapper.Domain;
using NOV.ES.TAT.BoomiWrapper.Infrastructure;

namespace NOV.ES.TAT.BoomiWrapper.DomainService.Service
{
    public class ErpItemsBatchService : IErpItemsBatchService
    {
        private readonly IErpItemsBatchCommandRepository erpItemsBatchCommandRepository;

        public ErpItemsBatchService(IErpItemsBatchCommandRepository erpItemsBatchCommandRepository)
        {
            this.erpItemsBatchCommandRepository = erpItemsBatchCommandRepository;
        }

        public int CreateErpItemsBatch(ErpItemsBatch erpItemsBatch)
        {
            erpItemsBatchCommandRepository.Create(erpItemsBatch);
            erpItemsBatchCommandRepository.SaveChanges();

            var addedErpItemsBatch = erpItemsBatchCommandRepository.GetById(erpItemsBatch.Id);
            addedErpItemsBatch.ErpItemsBatchNumber = addedErpItemsBatch.Id;

            erpItemsBatchCommandRepository.Update(addedErpItemsBatch);

            return addedErpItemsBatch.ErpItemsBatchNumber;
        }

        public void Update(ErpItemsBatch erpItemsBatch)
        {

            erpItemsBatchCommandRepository.Update(erpItemsBatch);

            erpItemsBatchCommandRepository.interfaceDBContext.Entry(erpItemsBatch)
                .Property(x => x.ErpItemsBatchNumber).IsModified = false;

            erpItemsBatchCommandRepository.SaveChanges();
        }
    }
}
