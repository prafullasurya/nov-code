﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetBusinessUnitInfoByIdHandler : IQueryHandler<GetBusinessUnitInfoByIdQuery, BusinessUnitInfoDto>
    {
        private readonly IMapper mapper;
        private readonly IBusinessUnitInfoService businessUnitInfoService;

        public GetBusinessUnitInfoByIdHandler(
            IMapper mapper,
            IBusinessUnitInfoService businessUnitInfoService)
        {
            this.mapper = mapper;
            this.businessUnitInfoService = businessUnitInfoService;
        }

        public Task<BusinessUnitInfoDto> Handle(GetBusinessUnitInfoByIdQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var businessUnitInfo = businessUnitInfoService.GetBusinessUnitInfoById(request.Id);
            var result = mapper.Map<BusinessUnitInfo, BusinessUnitInfoDto>(businessUnitInfo);
            return Task.FromResult(result);
        }
        private static bool IsValidRequest(GetBusinessUnitInfoByIdQuery request)
        {
            return (request != null && request.Id != 0);
        }
    }
}