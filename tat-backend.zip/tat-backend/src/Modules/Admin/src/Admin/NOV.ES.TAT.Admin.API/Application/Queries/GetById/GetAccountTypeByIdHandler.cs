﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetAccountTypeByIdHandler : IQueryHandler<GetAccountTypeByIdQuery, AccountTypeDto>
    {
        private readonly IMapper mapper;
        private readonly IAccountTypeService accountTypeService;

        public GetAccountTypeByIdHandler(
            IMapper mapper,
            IAccountTypeService accountTypeService)
        {           
            this.mapper = mapper;
            this.accountTypeService = accountTypeService;
        }

        public Task<AccountTypeDto> Handle(GetAccountTypeByIdQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var accountType = accountTypeService.GetAccountTypeById(request.Id);
            var result = mapper.Map<AccountType, AccountTypeDto>(accountType);
            return Task.FromResult(result);
        }
        private static bool IsValidRequest(GetAccountTypeByIdQuery request)
        {
            return (request != null && request.Id != 0);
        }
    }
}