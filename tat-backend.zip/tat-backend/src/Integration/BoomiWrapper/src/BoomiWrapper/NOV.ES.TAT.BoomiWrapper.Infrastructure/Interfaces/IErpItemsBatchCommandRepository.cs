﻿using NOV.ES.Framework.Core.Data.Repositories;
using NOV.ES.TAT.BoomiWrapper.Domain;

namespace NOV.ES.TAT.BoomiWrapper.Infrastructure
{
    public interface IErpItemsBatchCommandRepository
        : IWriteRepository<ErpItemsBatch>
    {
        ErpItemsBatch GetById(long id);
        public InterfaceDBContext interfaceDBContext { get; }
        public int SaveChanges();
        public Task<int> SaveChangesAsync(CancellationToken cancellationToken);
    }
}
