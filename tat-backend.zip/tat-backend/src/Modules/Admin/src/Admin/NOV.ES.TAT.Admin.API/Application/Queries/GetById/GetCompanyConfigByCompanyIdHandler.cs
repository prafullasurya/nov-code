﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetCompanyConfigByCompanyIdHandler : IQueryHandler<GetCompanyConfigByCompanyIdQuery, CompanyConfigDto>
    {
        private readonly IMapper mapper;
        private readonly ICompanyConfigService companyConfigService;

        public GetCompanyConfigByCompanyIdHandler(
            IMapper mapper,
            ICompanyConfigService companyConfigService)
        {
            this.mapper = mapper;
            this.companyConfigService = companyConfigService;
        }

        public Task<CompanyConfigDto> Handle(GetCompanyConfigByCompanyIdQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var companyConfig = companyConfigService.GetCompanyConfigByCompanyId(request.CompanyId);
            var result = mapper.Map<CompanyConfig, CompanyConfigDto>(companyConfig);
            return Task.FromResult(result);
        }
        private static bool IsValidRequest(GetCompanyConfigByCompanyIdQuery request)
        {
            return (request != null && request.CompanyId != 0);
        }
    }
}