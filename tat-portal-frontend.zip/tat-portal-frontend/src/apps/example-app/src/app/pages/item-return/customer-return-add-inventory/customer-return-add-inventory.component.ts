import { Component} from '@angular/core';

interface City {
  name: string,
  code: string
}
@Component({
  selector: 'customer-return-add-inventory',
  templateUrl: './customer-return-add-inventory.component.html',
  styleUrls: ['./customer-return-add-inventory.component.scss']
})
export class CustomerReturnAddInventoryComponent {
  
  displaySearchInventory: boolean;



  showNftSearchinventoryDialog() {
    this.displaySearchInventory = true;
  } 
}
