import { Component, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'usage-listing-search',
  templateUrl: './usage-listing-search.component.html',
  styleUrls: ['./usage-listing-search.component.scss'],
})
export class UsageListingSearchComponent {
  isHidden = false;
  displayOption: boolean;
  displayBasic: boolean;
  @Output() onToggle: EventEmitter<boolean> = new EventEmitter<boolean>();
  hideSlipSearch() {
    this.isHidden = !this.isHidden;
    this.onToggle.emit(this.isHidden);
  }
  showOptionDialog() {
    this.displayOption = true;
  }
  showBasicDialog() {
    this.displayBasic = true;
  }

}
