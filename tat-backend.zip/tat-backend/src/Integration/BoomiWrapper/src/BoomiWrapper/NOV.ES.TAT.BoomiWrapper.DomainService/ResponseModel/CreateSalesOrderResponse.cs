﻿using Newtonsoft.Json;

namespace NOV.ES.TAT.BoomiWrapper.DomainService.ResponseModel
{
    public class CreateSalesOrderResponse
    {
        public string Success { get; set; }
        public string OrderNumber { get; set; }
        public string OrderType { get; set; }
        [JsonProperty("exchangeRate")]
        public string ExchangeRate { get; set; }

        [JsonProperty("salesOrderNumber1")]
        public string SalesOrderNumber1 { get; set; }

        [JsonProperty("salesOrderType1")]
        public string SalesOrderType1 { get; set; }
        public List<ErpError> Errors { get; set; }
    }
}
