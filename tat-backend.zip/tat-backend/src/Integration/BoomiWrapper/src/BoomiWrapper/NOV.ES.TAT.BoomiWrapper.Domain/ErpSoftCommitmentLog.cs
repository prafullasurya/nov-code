﻿using NOV.ES.Framework.Core.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NOV.ES.TAT.BoomiWrapper.Domain
{
    [Table("ErpSoftCommitmentLog")]
    public class ErpSoftCommitmentLog : BaseEntity<long>
    {
        public int? ErpItemsBatchId { get; set; }
        [Column("TATOrderType")]
        [MaxLength(5)]
        public string TatOrderType { get; set; }
        [Column("TATOrderLineId")]
        public int? TatOrderLineId { get; set; }
        [Column("TATLineAction")]
        [MaxLength(15)]
        public string TatLineAction { get; set; }
        [MaxLength(15)]
        public string ErpDocType { get; set; }
        [MaxLength(25)]
        public string ErpDocNumber { get; set; }
        [MaxLength(1000)]
        public string ErrorMessage { get; set; }
        [Required]
        [MaxLength(50)]
        public string ErpType { get; set; }
    }
}
