﻿using NOV.ES.TAT.BoomiWrapper.Domain;
using NOV.ES.TAT.BoomiWrapper.Infrastructure;

namespace NOV.ES.TAT.BoomiWrapper.DomainService
{
    public class ErpSoftCommitmentLogService : IErpSoftCommitmentLogService
    {
        private readonly IErpSoftCommitmentLogCommandRepository erpSoftCommitmentLogCommandRepository;

        public ErpSoftCommitmentLogService(IErpSoftCommitmentLogCommandRepository erpSoftCommitmentLogCommandRepository)
        {
            this.erpSoftCommitmentLogCommandRepository = erpSoftCommitmentLogCommandRepository;
        }

        public void CreateErpSoftCommitmentLog(ErpSoftCommitmentLog erpSoftCommitmentLog)
        {
            erpSoftCommitmentLogCommandRepository.Create(erpSoftCommitmentLog);
            erpSoftCommitmentLogCommandRepository.SaveChanges();
        }

        public void Update(string erpDocNumber, string erpDocType, string errorMessage, string lastUpdateBy, int latestBatchId)
        {
            erpSoftCommitmentLogCommandRepository.Update(erpDocNumber, erpDocType, errorMessage, lastUpdateBy, latestBatchId);
        }
    }
}
