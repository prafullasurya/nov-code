﻿namespace NOV.ES.TAT.BoomiWrapper.Domain.WriteModels;

public class InventoryAdjustmentDetails
{
    public string InventoryTransactionType { get; set; }
    public string FromItemNumber { get; set; }
    public string ToItemNumber { get; set; }
    public decimal FromQuantity { get; set; }
    public string ToQuantity { get; set; }
    public string FromBU { get; set; }
    public string ToBU { get; set; }
    public string ToLocation { get; set; }
    public string FromLocation { get; set; }
    public string CFromTo { get; set; }
    public string UpdateQuantityOnHand { get; set; }
    public decimal AllowQtyOverAvailable { get; set; }
    public int CAllowHeldLot { get; set; }
    public string CToLotStatusCode { get; set; }
    public string ToSerialNumber { get; set; }
    public string FromSerialNumber { get; set; }
    public string JDEJobNumber { get; set; }

}
