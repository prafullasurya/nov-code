﻿using NOV.ES.TAT.BoomiWrapper.Domain;
using NOV.ES.TAT.BoomiWrapper.Domain.Event;
using NOV.ES.TAT.BoomiWrapper.Domain.ReadModel;
using NOV.ES.TAT.BoomiWrapper.Domain.WriteModels;
using NOV.ES.TAT.BoomiWrapper.DomainService.RequestModel;
using NOV.ES.TAT.BoomiWrapper.DomainService.ResponseModel;
using System.Threading.Tasks;

namespace NOV.ES.TAT.BoomiWrapper.DomainService
{
    public interface IBoomiWrapperService
    {
        //Task<BatchNextNumberResponse> GetBatchNextNumber(BatchNextNumberRequest batchNextNumberRequest);
        Task<BatchNextNumberResponse> GetBatchNextNumber(GenerateBatchNextNumberRequest generateBatchNextNumberRequest);
        Task<InsertEDIGLResponse> InsertEDIGL(InsertEDIGLRequest insertEDIGLRequest);
        Task<JobCreationResponse> CreateJob(JobCreationRequest jobCreationRequest);
        Task<JobCreationResponse> CreateJob(GenerateJobCreationRequest generateJobCreationRequest);
        Task<ItemAvailabilityResponse> GetItemAvailability(ItemAvailabilityRequest itemAvailabilityRequest);
        Task<CreateSalesOrderResponse> CreateSalesOrder(GenerateCreateSalesOrderRequest createSalesOrderRequest);
        Task<InventoryAdjustmentResponse> InventoryAdjustment(InventoryAdjustmentRequest inventoryAdjustmentRequest);
        Task<InventoryTransferResponse> InventoryTransfer(GenerateInventoryTransferRequest generateInventoryTransferRequest);
        Task<InventoryTransferResponse> InventoryTransfer(InventoryTransferRequest inventoryTransferRequest);
        Task<CreateWorkOrderResponse> CreateWorkOrder(CreateWorkOrderRequest createWorkOrderRequest);
        Task<SalesOrderStatusResponse> GetSalesOrderStatus(SalesOrderStatusRequest salesOrderStatusRequest);
        Task<ExchangeRateResponse> GetExchangeRate(ExchangeRateRequest exchangeRateRequest);
        Task<GetInventoryExtractResponse> GetInventoryExtract(GetInventoryExtractRequest getInventoryExtractRequest);
        Task<GetTransferMarkupResponse> GetTransferMarkup(GetTransferMarkupRequest getTransferMarkupRequest);
        void RecordRequestPayload(BoomiRequestResponse boomiRequestResponse);
        void RecordResponse(BoomiRequestResponse boomiRequestResponse);
        Task<List<BoomiRequestResponse>> GetEventInfo(long eventId);
        Task<ItemBranchResponse> GetItemBranch(ItemBranchRequest itemBranchRequest);
        Task<ItemMasterResponse> GetItemMaster(ItemMasterRequest itemMasterRequest);
        Task<RemitoResponse> GenerateRemito(GenerateRemitoRequest generateRemitoRequest);
        Task<JdeInventoryResponse> GetJdeInventory(GetJdeInventoryRequest getJdeInventoryRequest);
        Task<ValidateInventoryResponse> ValidateInventory(ValidateInventoryRequest validateInventoryRequest);
        InventoryTransferResponse SaveTransferJDEItems(CustomerTransferSlip customerTransferSlip, List<CustomerTransferSlipDetail> inventoryItems);
        InventoryTransferResponse SaveAdjustmentJDEItems(CustomerTransferSlip customerTransferSlip, List<CustomerTransferSlipDetail> inventoryItems);
        InventoryTransferResponse SaveAdjustmentNRJDEItems(CustomerTransferSlip customerTransferSlip, List<CustomerTransferSlipDetail> inventoryItems);

        Task<NotaFiscalResponse> UpdateNotfiscalInCDS(NotaFiscalRequest notaFiscalRequest);
        Task<NotaFiscalResponse> UpdateNotafiscal(NotaFiscalRequest notaFiscalRequest);
    }
}
