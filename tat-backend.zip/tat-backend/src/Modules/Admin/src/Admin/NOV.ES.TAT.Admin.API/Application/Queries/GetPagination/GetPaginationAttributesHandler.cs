﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.API.Helper;
using NOV.ES.TAT.Admin.DomainService;
using Attribute = NOV.ES.TAT.Admin.Domain.Attribute;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetPaginationAttributesHandler : IQueryHandler<GetPaginationAttributesQuery, PagedResult<AttributeDto>>
    {
        private readonly IMapper mapper;
        private readonly IAttributeService attributeService;
        private readonly IHttpContextAccessor httpContextAccessor;

        public GetPaginationAttributesHandler(
            IMapper mapper,
            IAttributeService attributeService,
            IHttpContextAccessor httpContextAccessor)
        {
            this.mapper = mapper;
            this.attributeService = attributeService;
            this.httpContextAccessor = httpContextAccessor;
        }
        public Task<PagedResult<AttributeDto>> Handle(GetPaginationAttributesQuery request,
            CancellationToken cancellationToken)
        {
            var attribute = attributeService.GetAttributes(request.PagingParameters);
            var result = mapper.Map<PagedResult<Attribute>, PagedResult<AttributeDto>>(attribute);
            PagingHelper.AddPagingMetadata<AttributeDto>(result, httpContextAccessor);
            return Task.FromResult(result);
        }
    }
}
