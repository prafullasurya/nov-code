﻿namespace NOV.ES.TAT.BoomiWrapper.DomainService.ResponseModel
{
    public class ValidateInventoryResponse
    {
        public string Success { get; set; }
        public List<ErpError> Errors { get; set; }
        public List<ValidateInventoryResponseData> Data { get; set; }
    }
}
