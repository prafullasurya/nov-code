﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Net.Http.Headers;
using NOV.ES.Framework.Core.Caching;
using NOV.ES.TAT.Common.UserPermissions.Models;
using System.Net.Http.Headers;
using System.Net.Http.Json;

namespace NOV.ES.TAT.Common.UserPermissions.Service
{
    public class UserProfileService : IUserProfileService
    {
        private const int dafaultCacheExpirationInDays = 1;
        private const int dafaultCacheExpirationInMinutes = 3;
        private readonly HttpClient httpClient;
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly IConfiguration configuration;
        //private readonly ILogger<UserProfileService> logger;
        //private readonly ICache cache;

        public UserProfileService(HttpClient httpClient
            , IHttpContextAccessor httpContextAccessor
            , IConfiguration configuration)
            //, ICache cache
            //, ILogger<UserProfileService> logger)
        {
            this.httpClient = httpClient;
            this.httpContextAccessor = httpContextAccessor;
            this.configuration = configuration;
            //this.cache = cache;
            //this.logger = logger;
        }
        public async Task<UserProfile> GetUserProfile()
        {
            UserProfile userProfile = new UserProfile();
            string clientId = string.Empty;
            if (httpContextAccessor.HttpContext.Request.Headers.TryGetValue("Client_Id", out var id))
                clientId = id;
            var accessToken = httpContextAccessor.HttpContext.Request.Headers[HeaderNames.Authorization];

            httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer"
                , accessToken.ToString().Replace("Bearer", "").Replace("bearer", "").Trim());

            httpClient.DefaultRequestHeaders.Add("Client_Id", string.IsNullOrEmpty(clientId) ? configuration["Default_Client_Id"] : clientId);

            using (var result  = await httpClient.GetAsync(configuration["UPM_User_Profile_URI"]))
            {
                if (result.IsSuccessStatusCode)
                {
                    userProfile = await result.Content.ReadFromJsonAsync<UserProfile>() ;
                }
            }

            return userProfile;
        }

        /*
        public async Task<UserProfile> GetUserProfileByRedisCache()
        {
            UserProfile userProfile = new UserProfile();
            string clientId = string.Empty;
            string userId = string.Empty;

            if (httpContextAccessor.HttpContext.Request.Headers.TryGetValue("user_email_id", out var emailId))
                userId = emailId;

            userProfile = GetUserProfileFromCache(userId);

            if (userProfile != null && userProfile.Email.Equals(userId))
                return userProfile;

            if (httpContextAccessor.HttpContext.Request.Headers.TryGetValue("Client_Id", out var id))
                clientId = id;
            var accessToken = httpContextAccessor.HttpContext.Request.Headers[HeaderNames.Authorization];
            httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer"
                , accessToken.ToString().Replace("Bearer", "").Replace("bearer", "").Trim());
            httpClient.DefaultRequestHeaders.Add("Client_Id", string.IsNullOrEmpty(clientId) ? configuration["Default_Client_Id"] : clientId);


            var responseTask = httpClient.GetAsync(configuration["UPM_User_Profile_URI"]);
            responseTask.Wait();
            var result = responseTask.Result;
            if (result.IsSuccessStatusCode)
            {
                userProfile = await result.Content.ReadFromJsonAsync<UserProfile>();
                /// Add user profile to Redis Cache
                AddUserProfileToCache(GetUserProfileKey(userId), userProfile);
            }

            return userProfile;
        }

        /// <summary>
        /// Update cache expiration of user profile entry.
        /// </summary>
        /// <param name="userId">Logged in user email id</param>
        /// <param name="inMinutes">Cache expiration time in minutes.</param>
        /// <returns>Cache key</returns>
        public string UpdateCacheExpiration(string userId, int inMinutes = 60)
        {
            var key = GetUserProfileKey(userId);
            var userProfile = GetUserProfileFromCache(userId);
            if (userProfile != null)
            {
                this.cache.Add(key, userProfile, new TimeSpan(0, inMinutes, 0));
                key = null;
            }
            return key;
        }

        /// <summary>
        /// Gets cached user profile details.
        /// </summary>
        /// <param name="userId">Logged in user email id as userId</param>
        /// <returns>Return user profile object for provided email id from cache.</returns>
        public UserProfile GetUserProfileFromCache(string userId)
        {
            return this.cache.Get<UserProfile>(GetUserProfileKey(userId));
        }

        /// <summary>
        /// Removes user profile cached value from cache.
        /// Use this to remove cache after successfully completing logout.
        /// </summary>
        /// <param name="userId">logged in user email id as user Id </param>
        /// <returns>Cache key</returns>
        public string RemoveUserProfileCache (string userId)
        {
            var key = GetUserProfileKey(userId);
            cache.Remove(key);
            logger.LogInformation($"User Profile for user {userId} removed successfully");
            return key;
        }

        private bool AddUserProfileToCache(string key, UserProfile userProfile)
        {
            UserProfile cachedVal = null;
            cachedVal = this.cache.Get<UserProfile>(key);
            if (cachedVal != null)
            {
                this.cache.Remove(key);
            }
            else
            {
                cachedVal = userProfile;
            }

            this.cache.Add(key, cachedVal, new TimeSpan(dafaultCacheExpirationInDays, 0, 0, 0));
            logger.LogInformation($"User Profile {key} successfuly added in cache.");

            return true;
        }

        private string GetUserProfileKey(string userId)
        {
            return $"{configuration["Deployment_Environment"]}_{userId}";
        }*/
    }
}
