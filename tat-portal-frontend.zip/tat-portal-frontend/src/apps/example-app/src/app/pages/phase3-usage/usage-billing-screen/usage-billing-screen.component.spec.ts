import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UsageBillingScreenComponent } from './usage-billing-screen.component';

describe('UsageBillingScreenComponent', () => {
  let component: UsageBillingScreenComponent;
  let fixture: ComponentFixture<UsageBillingScreenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UsageBillingScreenComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UsageBillingScreenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
function beforeEach(arg0: () => void) {
  throw new Error('Function not implemented.');
}

