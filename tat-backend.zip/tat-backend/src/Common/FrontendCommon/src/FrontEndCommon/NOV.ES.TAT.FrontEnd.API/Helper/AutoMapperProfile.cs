﻿using NOV.ES.TAT.FrontEnd.API.DTOs;
using NOV.ES.TAT.FrontEnd.Domain;
using AutoMapper;
namespace NOV.ES.TAT.FrontEnd.API.Helper
{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<MaintenanceModel, MaintenanceDto>();
        }
    }
}
