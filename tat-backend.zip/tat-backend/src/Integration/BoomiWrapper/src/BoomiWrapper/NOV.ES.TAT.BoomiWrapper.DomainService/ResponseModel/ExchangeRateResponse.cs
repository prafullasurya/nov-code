﻿namespace NOV.ES.TAT.BoomiWrapper.DomainService.ResponseModel
{
    public class ExchangeRateResponse
    {
        public string Success { get; set; }
        public decimal DefaultRate { get; set; }
        public List<ErpError> Errors { get; set; }
    }
}
