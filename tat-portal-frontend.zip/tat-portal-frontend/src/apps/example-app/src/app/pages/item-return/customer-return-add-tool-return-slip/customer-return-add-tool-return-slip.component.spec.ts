import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerReturnAddToolReturnSlipComponent } from './customer-return-add-tool-return-slip.component';

describe('CustomerReturnAddToolReturnSlipComponent', () => {
  let component: CustomerReturnAddToolReturnSlipComponent;
  let fixture: ComponentFixture<CustomerReturnAddToolReturnSlipComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerReturnAddToolReturnSlipComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerReturnAddToolReturnSlipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
