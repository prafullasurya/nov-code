﻿namespace NOV.ES.TAT.BoomiWrapper.DomainService.RequestModel
{
    public class BaseRequestModel
    {
        public string TargetERP { get; set; } = "JDE";
        public string Source { get; set; } = "TAT";
    }
}
