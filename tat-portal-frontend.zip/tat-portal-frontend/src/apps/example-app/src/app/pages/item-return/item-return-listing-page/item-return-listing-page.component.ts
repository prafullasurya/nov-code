import { Component } from '@angular/core';


@Component({
  selector: 'item-return-listing-page',
  templateUrl: './item-return-listing-page.component.html',
  styleUrls: ['./item-return-listing-page.component.scss'],
})

export class ItemReturnListingPageComponent {

}
