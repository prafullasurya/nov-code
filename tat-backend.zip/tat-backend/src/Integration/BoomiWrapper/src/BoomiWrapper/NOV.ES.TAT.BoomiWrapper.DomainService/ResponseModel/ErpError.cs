﻿namespace NOV.ES.TAT.BoomiWrapper.DomainService.ResponseModel
{
    public class ErpError
    {
        public string Error { get; set; }
        public string Code { get; set; }
        public string Description { get; set; }
    }
}
