﻿namespace NOV.ES.TAT.BoomiWrapper.Domain.WriteModels
{
    public class GenerateJobCreationRequest : BoomiRequestBaseModel
    {
        public string Customer { get; set; }
        public string RevenueBU { get; set; }
        public string SendingBU { get; set; }
        public string RigID { get; set; }
        public string ActualStartDate { get; set; }
        public string ContactName { get; set; }
        public string ContactNumber { get; set; }
        public string CustomerPO { get; set; }
        public string RentalAgreement { get; set; }
        public string JobDescription { get; set; }
        public string JobDescription2 { get; set; }
    }
}
