﻿using FluentValidation;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;
using NOV.ES.Framework.Core.CQRS.Behaviors;
using NOV.ES.Framework.Core.CQRS.Commands;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Data;
using NOV.ES.Framework.Core.Data.Repository;
using NOV.ES.Framework.Core.Messaging.IntegrationEvents;
using NOV.ES.Framework.Core.Messaging.IntegrationEvents.Subscription;
using NOV.ES.Infrastructure.IntegrationEventBus.RabbitMq;
using NOV.ES.Infrastructure.IntegrationEventBus.RabbitMq.Infrastructure;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;
using NOV.ES.TAT.Admin.Infrastructure;
using NOV.ES.TAT.Admin.Infrastructure.Interfaces;
using NOV.ES.TAT.Admin.Infrastructure.Repositories;
using NOV.ES.TAT.BoomiWrapper.API.Application.IntegrationEvents.SubscribedEvents;
using NOV.ES.TAT.BoomiWrapper.API.Filters;
using NOV.ES.TAT.BoomiWrapper.DomainService;
using NOV.ES.TAT.BoomiWrapper.DomainService.Service;
using NOV.ES.TAT.BoomiWrapper.Infrastructure;
using NOV.ES.TAT.MDM.DomainService;
using NOV.ES.TAT.MDM.Infrastructure;
using Polly;
using Polly.Extensions.Http;
using System.Reflection;

namespace NOV.ES.TAT.BoomiWrapper.API
{
    public static class DependencyRegistrar
    {
        public static IServiceCollection AddCustomMvc(this IServiceCollection services)
        {
            services.AddControllers(
                options =>
                {
                    options.Filters.Add(typeof(HttpGlobalExceptionFilter));
                }
            ).AddNewtonsoftJson(
                joptions =>
                {
                    joptions.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();
                    joptions.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
                    joptions.SerializerSettings.Converters.Add(new StringEnumConverter());
                }
            );
            services.AddCors(options =>
            {
                options.AddPolicy("CorsPolicy",
                    builder => builder
                    .SetIsOriginAllowed((host) => true)
                    .AllowAnyMethod()
                    .AllowAnyHeader()
                    .AllowCredentials());
            });
            return services;
        }
        public static IServiceCollection AddHealthChecks(this IServiceCollection services, IConfiguration configuration)
        {
            var hcBuilder = services.AddHealthChecks();

            hcBuilder.AddCheck("self", () => HealthCheckResult.Healthy());

            return services;
        }
        public static IServiceCollection AddCustomSwagger(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v1", new OpenApiInfo
                {
                    Title = "TAT BoomiWrapper API",
                    Version = "v1",
                    Description = "BoomiWrapper REST API"
                });
                options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme()
                {
                    Name = "Authorization",
                    Type = SecuritySchemeType.ApiKey,
                    Scheme = "Bearer",
                    BearerFormat = "JWT",
                    In = ParameterLocation.Header,
                    Description = "JWT Authorization header using the Bearer scheme. \r\n\r\n Enter 'Bearer' [space] and then your token in the text input below.\r\n\r\nExample: \"Bearer 12345abcdef\"",
                });
                options.AddSecurityRequirement(new OpenApiSecurityRequirement()
                {
                    {
                          new OpenApiSecurityScheme()
                            {
                                Reference = new OpenApiReference
                                {
                                    Type = ReferenceType.SecurityScheme,
                                    Id = "Bearer"
                                }
                            },
                            new string[] {}
                    }
                });
            });

            return services;
        }
        public static IServiceCollection AddDomainCoreDependecy(this IServiceCollection services)
        {
            services.AddTransient<ICommandBus, CommandBus>();
            services.AddTransient<IQueryBus, QueryBus>();
            services.AddTransient<BaseContext, AdminDBContext>();
            //services.AddTransient<BaseContext, InterfaceDBContext>();
            services.AddTransient(typeof(IPipelineBehavior<,>), typeof(LoggingBehavior<,>));
            services.AddTransient<IBoomiRequestResponseCommandRepository, BoomiRequestResponseCommandRepository>();
            services.AddTransient<IBoomiRequestResponseQueryRepository, BoomiRequestResponseQueryRepository>();
            services.AddTransient<IBoomiWrapperService, BoomiWrapperService>();
            services.AddTransient<IErpItemsBatchCommandRepository, ErpItemsBatchCommandRepository>();
            services.AddTransient<IErpSoftCommitmentLogCommandRepository, ErpSoftCommitmentLogCommandRepository>();
            services.AddTransient<DomainService.IErpSoftCommitmentLogService, DomainService.ErpSoftCommitmentLogService>();
            services.AddTransient<DomainService.IErpItemsBatchService, DomainService.Service.ErpItemsBatchService>();
            services.AddTransient<IInventoryItemsService, InventoryItemsService>();
            services.AddValidatorsFromAssembly(typeof(Startup).Assembly);
            services.AddTransient<GenerateBatchNextNumberHandler>();
            services.AddTransient<ProcessAddInventoryItemsInErpHandler>();
            services.AddTransient<ProcessUpdateInventoryItemsInErpHandler>();
            services.AddTransient<ProcessDeleteInventoryItemsInErpHandler>();
            services.AddTransient<ResubmitErpItemToBoomiHandler>();
            //services.AddTransient<DbContext, MdmDBContext>();
            services.AddTransient<IBusinessUnitService, BusinessUnitService>();
            services.AddTransient<ICompanyConfigService, CompanyConfigService>();
            services.AddTransient<ICompanyDivisionService, CompanyDivisionService>();
            services.AddTransient<ICompanyDivisionRepository, CompanyDivisionRepository>();
            services.AddTransient<IDivisionService, DivisionService>();
            //services.AddTransient<IDivisionRepository, DivisionRepository>();
            services.AddTransient<IReadRepository<CompanyConfig>, GenericReadRepository<CompanyConfig>>();
            services.AddTransient<IReadRepository<CompanyDivision>, GenericReadRepository<CompanyDivision>>();
            services.AddTransient<IReadRepository<Division>, GenericReadRepository<Division>>();
            services.AddScoped<INotaFiscalInfoService, NotaFiscalInfoService>();
            services.AddScoped<INotaFiscalInfoQueryRepository, NotaFiscalInfoQueryRepository>();
         
            services.AddTransient<IBusinessUnitQueryRepository, BusinessUnitQueryRepository>();

            //services.AddTransient<MdmDBContext, BusinessUnitQueryRepository>();


            return services;
        }
        public static IServiceCollection AddAutoMapper(this IServiceCollection services)
        {
            services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());
            return services;
        }
        public static IServiceCollection AddPolly(this IServiceCollection services, IConfiguration configuration)
        {
            #region PollyImplementation
            //Note: Need to install Microsoft.Extensions.Http.Polly
            services.AddHttpClient<IBoomiWrapperService, BoomiWrapperService>(client =>
            {
                client.BaseAddress = new Uri(configuration["Boomi_Base_url"]);
            })
            .SetHandlerLifetime(TimeSpan.FromMinutes(Convert.ToInt32(configuration["HandlerLifetimeInMinutes"])))
            .AddPolicyHandler(GetWaitRetryPolicy(configuration))
            .AddPolicyHandler(GetCircuitBreakerPolicy(configuration));
            #endregion
            return services;
        }
        private static IAsyncPolicy<HttpResponseMessage> GetWaitRetryPolicy(IConfiguration configuration)
        {
            return HttpPolicyExtensions
            .HandleTransientHttpError()
            .WaitAndRetryAsync(Convert.ToInt32(configuration["RetryCount"])
            , retryAttempt => TimeSpan.FromSeconds(Convert.ToInt32(configuration["RetryCount"])));
        }
        private static IAsyncPolicy<HttpResponseMessage> GetCircuitBreakerPolicy(IConfiguration configuration)
        {
            return HttpPolicyExtensions
            .HandleTransientHttpError()
            .CircuitBreakerAsync(Convert.ToInt32(configuration["RetryCountAllowedCircuitBreaking"])
            , TimeSpan.FromMinutes(Convert.ToInt32(configuration["DurationOfBreakInMinutes"])));
        }
        public static IServiceCollection AddIntegrationEventBus(this IServiceCollection services)
        {
            services.AddSingleton<IEventBusSubscriptionsManager, InMemoryEventBusSubscriptionsManager>();
            services.AddSingleton<IIntegrationEventBus, EventBusRabbitMq>();
            return services;
        }
        public static IServiceCollection RegistorMediatR(this IServiceCollection services)
        {
            services.AddMediatR(typeof(Startup).GetTypeInfo().Assembly);
            services.AddValidatorsFromAssembly(typeof(Startup).Assembly);

            return services;
        }
        public static IServiceCollection AddRabbitMq(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddRabbitMqEventBus(configuration, "IntegrationEventBusConfig", "TATInternalIntegrationBus");

            // Override RabitMq connection string per environment read from Kubernetes Secret
            var rabbitConfig = configuration.GetSection("TATInternalIntegrationBusRQCON");
            var rabbitMqConfigObj = Newtonsoft.Json.JsonConvert.DeserializeObject<RabbitMqConfig>(rabbitConfig.Value);
            services.PostConfigure<RabbitMqConfig>(o =>
            {
                o.RabbitMqConnection.HostName = rabbitMqConfigObj.RabbitMqConnection.HostName;
                if (!string.IsNullOrEmpty(rabbitMqConfigObj.RabbitMqConnection.Username))
                {
                    o.RabbitMqConnection.Username = rabbitMqConfigObj.RabbitMqConnection.Username;
                    o.RabbitMqConnection.Password = rabbitMqConfigObj.RabbitMqConnection.Password;
                }

                o.RabbitMqConnection.IsSSLEnabled = rabbitMqConfigObj.RabbitMqConnection.IsSSLEnabled;
                o.RabbitMqConnection.AutomaticRecoveryEnabled = rabbitMqConfigObj.RabbitMqConnection.AutomaticRecoveryEnabled;
                o.RabbitMqConnection.RequestedHeartbeat = rabbitMqConfigObj.RabbitMqConnection.RequestedHeartbeat;
            });

            // Override RabitMq Integration Bus Config per environment read from Kubernetes Secret
            var busConfigSec = configuration.GetSection("CTBoomiWrapperMQBusConfig");
            var busConfigObj = Newtonsoft.Json.JsonConvert.DeserializeObject<IntegrationEventBusConfig>(busConfigSec.Value);
            if (busConfigObj != null)
            {
                services.PostConfigure<IntegrationEventBusConfig>(o =>
                {
                    o.BrokerName = busConfigObj.BrokerName;
                    o.ExchangeType = busConfigObj.ExchangeType;
                    o.QueueName = busConfigObj.QueueName;
                    o.Topic = busConfigObj.Topic;
                    o.PreFetchCount = busConfigObj.PreFetchCount;
                });
            }
            return services;
        }
        public static IServiceCollection AddCustomDbContext(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddDbContext<InterfaceDBContext>(options =>
            {
                options.UseSqlServer(configuration["InterfaceDBConnString"],
                    sqlServerOptionsAction: sqlOptions =>
                    {
                        sqlOptions.MigrationsAssembly(typeof(Startup).GetTypeInfo().Assembly.GetName().Name);
                        sqlOptions.EnableRetryOnFailure(maxRetryCount: 3, maxRetryDelay: TimeSpan.FromSeconds(30), errorNumbersToAdd: null);
                    });
            },
            ServiceLifetime.Scoped
            );
            services.AddDbContext<MdmDBContext>(options =>
            {
                options.UseSqlServer(configuration["MdmDBConnString"],
                    sqlServerOptionsAction: sqlOptions =>
                    {
                        sqlOptions.MigrationsAssembly(typeof(Startup).GetTypeInfo().Assembly.GetName().Name);
                        sqlOptions.EnableRetryOnFailure(maxRetryCount: 3, maxRetryDelay: TimeSpan.FromSeconds(30), errorNumbersToAdd: null);
                    });
            },
            ServiceLifetime.Scoped
            );
            services.AddDbContext<AdminDBContext>(options =>
            {
                options.UseSqlServer(configuration["TrackAToolDbConnString"],
                    sqlServerOptionsAction: sqlOptions =>
                    {
                        sqlOptions.MigrationsAssembly(typeof(Startup).GetTypeInfo().Assembly.GetName().Name);
                        sqlOptions.EnableRetryOnFailure(maxRetryCount: 3, maxRetryDelay: TimeSpan.FromSeconds(30), errorNumbersToAdd: null);
                    });
            },
         ServiceLifetime.Scoped
         );
            return services;
        }
    }
}
