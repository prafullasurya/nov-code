﻿namespace NOV.ES.TAT.BoomiWrapper.DomainService.ResponseModel
{
    public class InventoryExtractDetails
    {
        public int OrderNumber { get; set; }
        public string OrderType { get; set; }
    }
}
