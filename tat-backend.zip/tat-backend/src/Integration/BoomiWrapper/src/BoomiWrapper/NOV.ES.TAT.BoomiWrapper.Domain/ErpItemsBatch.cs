﻿using NOV.ES.Framework.Core.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NOV.ES.TAT.BoomiWrapper.Domain
{
    [Table("ErpItemsBatch")]
    public class ErpItemsBatch : BaseEntity<int>
    {
        //[DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ErpItemsBatchNumber { get; set; }
        [Column("TATSlipType")]
        [Required, MaxLength(5)]
        public string TatSlipType { get; set; }
        [Column("TATSlipId")]
        [Required]
        public int TatSlipId { get; set; }
        [Column("TATErrorMessage")]
        public string TatErrorMessage { get; set; }
        public string ErpErrorMessage { get; set; }
        public bool BatchCompleted { get; set; }
        [Required]
        [MaxLength(50)]
        public string ErpType { get; set; }
    }
}
