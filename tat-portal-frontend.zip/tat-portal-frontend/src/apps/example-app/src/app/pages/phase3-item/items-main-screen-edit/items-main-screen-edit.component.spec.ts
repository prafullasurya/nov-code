import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ItemsMainScreenEditComponent } from './items-main-screen-edit.component';

describe('ItemsMainScreenEditComponent', () => {
  let component: ItemsMainScreenEditComponent;
  let fixture: ComponentFixture<ItemsMainScreenEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ItemsMainScreenEditComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ItemsMainScreenEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
function beforeEach(arg0: () => void) {
  throw new Error('Function not implemented.');
}

