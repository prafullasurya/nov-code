﻿namespace NOV.ES.TAT.Common.Exception
{
    public class ErrorModel
    {
        public int Code { get; set; }
        public string Error { get; set; }
        public string Message { get; set; }
        public string Details { get; set; }
        public string RequestId { get; set; }
        public string TraceId { get; set; }
        public string HelpUrl { get; set; }
    }
}
