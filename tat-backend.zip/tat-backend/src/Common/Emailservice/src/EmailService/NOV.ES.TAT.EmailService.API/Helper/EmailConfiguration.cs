﻿namespace NOV.ES.TAT.EmailService.Helper
{
  
    public class EmailConfiguration
    {
        public string SMTPHost { get; set; }

        public int SMTPPort { get; set; }

        public string EmailFrom { get; set; }

        public string Username { get; set; }

        public string Password { get; set; }

        public EmailConfiguration(string smtpHost, int smtpPort, string emailFrom, string username, string password)
        {
            this.SMTPHost = smtpHost;
            this.SMTPPort = smtpPort;
            this.EmailFrom = emailFrom;
            this.Username = username;
            this.Password = password;
        }

        public EmailConfiguration()
        {
            // todo: complete member initialization
        }

    }
}
