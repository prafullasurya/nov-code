﻿using NOV.ES.Framework.Core.CQRS.Commands;
using System.Text.Json.Serialization;

namespace NOV.ES.TAT.FrontEnd.API.Application
{
    public class RecordLogCommand : ICommand<bool>
    {
        public ErrorModel ErrorModel { get; private set; }

        [JsonConstructor]
        public RecordLogCommand(ErrorModel errorModel)
        {
            this.ErrorModel = errorModel;
        }
    }
}
