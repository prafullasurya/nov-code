﻿namespace NOV.ES.TAT.Common.UserPermissions.Models
{
    public class UserSystemFeaturePermissions
    {
        public string PermissionId { get; set; }
        public string Code { get; set; }
        public string Description { get; set; }
        public string PermissionName { get; set; }
    }
}
