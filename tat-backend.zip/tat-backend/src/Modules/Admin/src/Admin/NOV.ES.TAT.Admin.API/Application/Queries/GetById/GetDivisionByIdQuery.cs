﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;


namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetDivisionByIdQuery : IQuery<DivisionDto>
    {
        public int DivisionId { get; private set; }
        public GetDivisionByIdQuery(int divisionId)
        {
            this.DivisionId = divisionId;
        }
    }
}
