﻿namespace NOV.ES.TAT.Common.Authentication
{
    public class Constants
    {
        #region Authrization
        public const string MIX_AUTH_SCHEME = "Okta, InternalIdentity";
        public const string IDENTITY_AUTH_SCHEME = "InternalIdentity";
        public const string OKTA_AUTH_SCHEME = "Okta";
        #endregion
    }
}
