import { Component} from '@angular/core';

interface City {
  name: string,
  code: string
}
@Component({
  selector: 'tat-portal-frontend-nft-completed',
  templateUrl: './nft-completed.component.html',
  styleUrls: ['./nft-completed.component.scss']
})
export class nftCompletedComponent {
  
  displayAddMiscReceiptItem: boolean;
  displayModal: boolean;
  displayCompleteFieldTransferSlip: boolean;
  displayonfirmAssemblyNft: boolean;
  displaySearchInventory: boolean;

  //Dialog
  showAddMiscReceiptItem() {
    this.displayAddMiscReceiptItem = true;//showAddMiscReceiptItem
  }

  //Data Validation Message
  showModalDialog() {
    this.displayModal = true;
  }

  showCompleteFieldTransferSlip() {
    this.displayCompleteFieldTransferSlip = true;
  }

  showConfirmAssemblyNftDialog() {
    this.displayonfirmAssemblyNft = true;
  } 

  showNftSearchinventoryDialog() {
    this.displaySearchInventory = true;
  } 


}
