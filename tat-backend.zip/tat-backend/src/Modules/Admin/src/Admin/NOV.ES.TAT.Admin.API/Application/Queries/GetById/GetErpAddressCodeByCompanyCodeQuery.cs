﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetErpAddressCodeByCompanyCodeQuery : IQuery<IEnumerable<ErpAddressCodeDto>>
    {
        public string CompanyCode { get; private set; }

        public GetErpAddressCodeByCompanyCodeQuery(string companyCode)
        {
            this.CompanyCode = companyCode;
        }
    }
}