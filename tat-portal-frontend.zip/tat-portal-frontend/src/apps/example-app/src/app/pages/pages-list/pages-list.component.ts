import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'tat-portal-frontend-pages-list',
  templateUrl: './pages-list.component.html',
  styleUrls: ['./pages-list.component.scss']
})
export class PagesListComponent implements OnInit {
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }

}
