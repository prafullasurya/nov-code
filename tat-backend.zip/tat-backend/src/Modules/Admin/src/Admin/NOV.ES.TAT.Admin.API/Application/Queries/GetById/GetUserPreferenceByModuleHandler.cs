﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetUserPreferenceByModuleHandler : IQueryHandler<GetUserPreferenceByModuleQuery, IEnumerable<UserPreferenceDto>>
    {
        private readonly IMapper mapper;
        private readonly IUserPreferenceService userPreferenceService;

        public GetUserPreferenceByModuleHandler(
            IMapper mapper,
            IUserPreferenceService userPreferenceService)
        {
            this.mapper = mapper;
            this.userPreferenceService = userPreferenceService;
        }

        public Task<IEnumerable<UserPreferenceDto>> Handle(GetUserPreferenceByModuleQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var userPreferences = userPreferenceService.GetUserPreferencesByModule(request.ModuleId);
            var result = mapper.Map<IEnumerable<UserPreference>, IEnumerable<UserPreferenceDto>>(userPreferences);
            return Task.FromResult(result);
        }
        private static bool IsValidRequest(GetUserPreferenceByModuleQuery request)
        {
            return (request != null);
        }
    }
}