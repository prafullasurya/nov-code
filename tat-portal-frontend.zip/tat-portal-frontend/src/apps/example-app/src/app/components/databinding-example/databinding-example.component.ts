import { Component, OnInit } from '@angular/core';
import { OilCompanyService, OilCompnay, SearchParams } from '@tat/example-app/data-access';
import { LazyLoadEvent, PrimeNGConfig } from 'primeng/api';
@Component({
  selector: 'tat-portal-frontend-databinding-example',
  templateUrl: './databinding-example.component.html',
  styleUrls: ['./databinding-example.component.scss']
})
export class DatabindingExampleComponent implements OnInit {
  searchParams= new SearchParams();
  
  oilCompnaies: OilCompnay[];
  totalRecords: number;
  loading: boolean;

  constructor(private oilCompanyService: OilCompanyService,
    private primengConfig: PrimeNGConfig) { }

  ngOnInit() {
    this.searchParams.SortColumn='name',
    this.searchParams.pageIndex=0;
    this.searchParams.pageSize=0;
    this.oilCompanyService.getCompanies(this.searchParams).
      subscribe(response=>{
        this.totalRecords=response.body.length;
      })
  }

  loadCompnaies(event: LazyLoadEvent) {
    this.loading = true;
    this.searchParams.SortColumn='name',
    this.searchParams.pageIndex=event.first;  
    this.searchParams.pageSize=event.rows;
    console.log(event.first + '|' + event.rows)
    this.oilCompanyService.getCompanies(this.searchParams).
      subscribe(response=>{
        //console.log(response.body);
        this.oilCompnaies =response.body;
        this.loading = false
      })
      console.log(this.oilCompnaies);
  }
}