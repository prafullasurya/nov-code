import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import {
  ModuleModel,
  UserPreferenceService,
} from '@tat/core/data-access-admin';
import { CustomerTransferMenu } from '@tat/customer-transfer/feature-customer-transfer';
import { AuthenticationService } from '@tat/shared/util-authentication';
import {
  FeatureToggleService,
  ToggleFeature,
  UserProfile,
  UserProfileService,
} from '@tat/shared/util-upm';
import { MenuItem } from 'primeng/api';
import { BehaviorSubject, Observable } from 'rxjs';
import { MODULE_NANE } from '@tat/core';
const externalLinkIdentifier = '/externalRedirect';

@Component({
  selector: 'tat-portal-frontend-customer-transfer-entry',
  templateUrl: './entry.component.html',
  styleUrls: ['./entry.component.scss'],
})
export class RemoteEntryComponent implements OnInit {
  public isAuthenticatedUser = false;
  menuItems: MenuItem[] = [];
  userProfile$: Observable<UserProfile>;
  pagelist: any[] = [
    { key: 0, value: 'slips' },
    { key: 0, value: 'EditCustomerTransferSlip' },
    { key: 0, value: 'AddCustomerTransferSlip' },
    { key: 1, value: 'jobs' },
    { key: 1, value: 'job' },

    { key: 2, value: 'fieldtransfers' },
    { key: 2, value: 'AddFieldTransferSlip' },
    { key: 2, value: 'EditFieldTransfer' },
  ];
  currentUrl: any;
  constructor(
    public authService: AuthenticationService,
    private translate: TranslateService,
    private _router: Router,
    private userPreferenceService: UserPreferenceService,
    private userProfileService: UserProfileService,
    private featureToggleService: FeatureToggleService,
    private activatedRoute: ActivatedRoute
  ) {
    this.isAuthenticatedUser = this.authService.isAuthenticated();
    this.currentUrl = window.location.href.split('/')[4];
    //alert(this.currentUrl);

    this.authService.isAuthenticatedObs$.subscribe((authenticated: boolean) => {
      this.isAuthenticatedUser = authenticated;
      console.log('Shell Auth observer' + authenticated);
      if (
        sessionStorage.getItem('returnUrl') != undefined &&
        sessionStorage.getItem('returnUrl') != null
      ) {
        let returnUrl = sessionStorage.getItem('returnUrl');
        sessionStorage.removeItem('returnUrl');
        this._router.navigateByUrl(returnUrl);
      }
    });

    this.translate.use(
      !localStorage.getItem('language-preference')
        ? 'en'
        : localStorage.getItem('language-preference')
    );
  }
  activeSubMenu(event: any) {
    let node;
    if (event.target.tagName === 'A') {
      node = event.target;
    } else {
      node = event.target.parentNode;
    }
    let menuitem = document.getElementsByClassName('p-menuitem-link');
    for (let i = 0; i < menuitem.length; i++) {
      menuitem[i].classList.remove('highlight');
    }

    node.classList.add('highlight');
  }
  async ngOnInit() {
    this.userProfile$ = this.userProfileService.userProfile$;
    this.userProfile$.subscribe((data) => {
      this.userPreferenceService
        .getModules()
        .subscribe((modules: ModuleModel[]) => {
          let moduleId = modules.filter(
            (x) => x.name === MODULE_NANE.PACKINGSLIP
          )[0].id;
          this.userPreferenceService.getUserPreferencePackingSlip(moduleId);
        });
    });
    await this.loadMenue();
  }
  async loadMenue() {
    this.menuItems.push({
      label: 'Customer Delivery Slip',
      visible: true,
      routerLink: [
        externalLinkIdentifier,
        {
          internalUrl: '/customer-transfer/slips',
        },
      ],
    });
    this.featureToggleService.getFeatures().subscribe(
      (data: ToggleFeature[]) => {
        let menuitem = document.getElementsByClassName('p-menuitem-link');
        menuitem[4]?.classList.add('active');
        this.menuItems.push(
          {
            label: 'Job',
            visible: data.some((x) => x.featurecode == 'JOBS'),
            routerLink: [
              externalLinkIdentifier,
              {
                internalUrl: '/customer-transfer/jobs',
              },
            ],
          },
          {
            label: 'Field Transfer',
            visible: data.some((x) => x.featurecode == 'FTS'),
            routerLink: [
              externalLinkIdentifier,
              {
                internalUrl: '/customer-transfer/fieldtransfers',
              },
            ],
          }
        );
        this.menuItems = [...this.menuItems];
        if (this.currentUrl !== '' && this.currentUrl !== undefined) {
          setTimeout(() => {
            document
              .querySelectorAll('.p-tabmenuitem a')
              [
                this.pagelist?.find((x) => x.value == this.currentUrl)?.key
              ].classList.add('highlight');
          }, 1500);
        }
      },
      (err) => {
        console.log(err);
      }
    );
  }
}
