import { Component, OnInit } from '@angular/core';

@Component({
    templateUrl: 'user-dashboard.component.html',
    styleUrls: ['user-dashboard.component.scss'],
    // providers: [ProjectDefinitionDataService]
  })
  export class UserDashboardComponent implements OnInit {
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }
  }

  