﻿using Newtonsoft.Json;
using NOV.ES.Framework.Core.Messaging.IntegrationEvents;
using NOV.ES.Framework.Core.Sagas;
using NOV.ES.TAT.BoomiWrapper.API.Application.IntegrationEvents.PublishEvents;
using NOV.ES.TAT.BoomiWrapper.Domain.Event;
using NOV.ES.TAT.BoomiWrapper.DomainService;
using NOV.ES.TAT.Common.CompressDecompress;

namespace NOV.ES.TAT.BoomiWrapper.API.Application.IntegrationEvents.SubscribedEvents
{
    public class ResubmitErpItemToBoomiHandler
        : IIntegrationEventHandler<ResubmitErpItemToBoomi>
    {
        private readonly ILogger<ResubmitErpItemToBoomiHandler> logger;
        private readonly IInventoryItemsService inventoryItemsService;
        private readonly IIntegrationEventBus integrationEventBus;

        public ResubmitErpItemToBoomiHandler(
            ILogger<ResubmitErpItemToBoomiHandler> logger
            , IInventoryItemsService inventoryItemsService
            , IIntegrationEventBus integrationEventBus)
        {
            this.logger = logger;
            this.inventoryItemsService = inventoryItemsService;
            this.integrationEventBus = integrationEventBus;
        }

        public Task Handle(ResubmitErpItemToBoomi @event)
        {
            logger.LogInformation("----- Consuming Event: Process Resubmit Erp Items Integration Event");
            logger.LogInformation("----- CorelationId is {id}", @event.CorelationId);
            logger.LogInformation("----- Event Detail is {info}", @event.JsonStringData);

            var processInventoryItemsInErp = JsonConvert.DeserializeObject<ProcessInventoryItemsInErp>(CompressDecompress
                .DecompressData(@event.JsonStringData));
            var boomiRequestId = inventoryItemsService.ProcessErpItems(@event, processInventoryItemsInErp, ErpOperations.RESUBMIT);

            #region publish event

            ProcessedUpdateInventoryItemsInErp success =
            new(
                @event.KeyId,
                @event.CorelationId,
                CompressDecompress.CompressData(JsonConvert.SerializeObject(processInventoryItemsInErp)),
                DateTime.UtcNow,
                SagaEventExecutionResult.Success,
                @event.ActionBy
                );

            logger.LogInformation("Publish Processed Resubmit Erp Items  - ResubmitedErpItemToBooomi.");
            integrationEventBus.Publish(success);
            #endregion

            return Task.CompletedTask;
        }
    }
}


