﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Net.Http.Headers;
using NOV.ES.TAT.Common.FeatureToggle.Models;
using System.Net.Http.Headers;
using System.Net.Http.Json;

namespace NOV.ES.TAT.Common.FeatureToggle.Service
{
    public class FeatureToggleService : IFeatureToggleService
    {
        private readonly HttpClient httpClient;
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly IConfiguration configuration;

        public FeatureToggleService(HttpClient httpClient
            , IHttpContextAccessor httpContextAccessor
            , IConfiguration configuration)
        {
            this.httpClient = httpClient;
            this.httpContextAccessor = httpContextAccessor;
            this.configuration = configuration;
        }
        public async Task<ToggleFeatures> GetUserToggleFeatures()
        {
            ToggleFeatures toggleFeatures = new ToggleFeatures();

            var accessToken = httpContextAccessor.HttpContext.Request.Headers[HeaderNames.Authorization];
            httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer"
                , accessToken.ToString().Replace("Bearer", "").Replace("bearer", "").Trim());

            using (var result = await httpClient.GetAsync(configuration["UPM_FeatureToggle_URI"]))
            {
                if (result.IsSuccessStatusCode)
                {
                    toggleFeatures = await result.Content.ReadFromJsonAsync<ToggleFeatures>();
                }
            }
            return toggleFeatures;
        }
        public bool HasAllowed(string feature)
        {
            ToggleFeatures toggleFeatures = (ToggleFeatures)httpContextAccessor.HttpContext.Items["ToggleFeatures"];
            return toggleFeatures.toggleFeatures_.FirstOrDefault(x => x.FeatureCode.Equals(feature)) != null;

        }
    }
}
