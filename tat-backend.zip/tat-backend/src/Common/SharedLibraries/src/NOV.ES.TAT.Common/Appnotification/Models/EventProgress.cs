﻿

using Newtonsoft.Json;

namespace NOV.ES.TAT.Common.Appnotification.Models
{
    
    public class EventProgress
    {
        public string EventKey { get; set; }
        public string KeyId { get; set; }
        public string SecondaryKeyId { get; set; }
        public string Description { get; set; }        
        public string ErrorMessage { get; set; }        
        public TaskStatus TaskStatus { get; set; }
        public long StartedAt { get; set; }
        public long CompletedAt { get; set; }
        public List<EventSubTask> SubTasks { get; set; }

        public EventProgress(Event @event, string keyId, string errorMessage = null)
        {
            EventKey = $"{@event.ToString()}_{keyId}";
            KeyId = keyId;
            TaskStatus = TaskStatus.InProgress;
            ErrorMessage = errorMessage;
        
            StartedAt = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
            CompletedAt = 0;

            var subTasks = Constants.Events.GetValueOrDefault(@event);
            int count = subTasks.Count;
            this.SubTasks = new List<EventSubTask>();
            for (int i = 0; i < count; i++)
            {
                var val = subTasks[i+1];
                this.SubTasks.Add(new EventSubTask(EventKey, keyId, i+1, val));
            }
                        
        }

        [JsonConstructor]
        public EventProgress(string eventKey, string keyId, string secondaryKeyId, 
            string description, string errorMessage, 
            TaskStatus taskStatus, long startedAt, long completedAt, 
            List<EventSubTask> subTasks)
        {
            EventKey = eventKey;
            KeyId = keyId;
            SecondaryKeyId = secondaryKeyId;
            Description = description;
            ErrorMessage = errorMessage;
            TaskStatus = taskStatus;
            StartedAt = startedAt;
            CompletedAt = completedAt;
            SubTasks = subTasks;
        }
    }
}
