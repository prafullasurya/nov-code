﻿using NOV.ES.Framework.Core.DTOs;

namespace NOV.ES.TAT.FrontEnd.API.DTOs
{
    public class MaintenanceDto : BaseModel<int>
    {
        public MaintenanceDto()
        {
        }

        public MaintenanceDto(string downTimeReason, string messageId, DateTime? expectedResumeBy, DateTime? scheduledOn)
        {
            DownTimeReason = downTimeReason;
            MessageId = messageId;
            ExpectedResumeBy = expectedResumeBy;
            ScheduledOn = scheduledOn;
        }

        public string DownTimeReason { get; set; }
        public DateTime? ExpectedResumeBy { get; set; }
        public DateTime? ScheduledOn { get; set; }
        public string MessageId { get; set; }
    }
}
