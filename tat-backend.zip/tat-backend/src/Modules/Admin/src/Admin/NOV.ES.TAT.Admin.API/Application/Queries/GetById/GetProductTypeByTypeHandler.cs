﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetProductTypeByTypeHandler : IQueryHandler<GetProductTypeByTypeQuery, ProductTypeDto>
    {
        private readonly IMapper mapper;
        private readonly IProductTypeService productTypeService;

        public GetProductTypeByTypeHandler(
            IMapper mapper,
            IProductTypeService productTypeService)
        {
            this.mapper = mapper;
            this.productTypeService = productTypeService;
        }

        public Task<ProductTypeDto> Handle(GetProductTypeByTypeQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var ProductType = productTypeService.GetProductTypeByType(request.Type);
            var result = mapper.Map<ProductType, ProductTypeDto>(ProductType);
            return Task.FromResult(result);
        }
        private static bool IsValidRequest(GetProductTypeByTypeQuery request)
        {
            return (request != null && request.Type != string.Empty);
        }
    }
}