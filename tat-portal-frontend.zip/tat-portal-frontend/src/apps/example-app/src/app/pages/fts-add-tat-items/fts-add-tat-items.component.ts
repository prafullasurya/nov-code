import { Component, OnInit } from '@angular/core';
import {TreeNode} from 'primeng/api';
import { ProductService } from '../../models/productservice';
import { Product } from '../../models/product';

interface City {
  name: string,
  code: string
}

@Component({
  selector: 'tat-portal-frontend-fts-add-tat-items',
  templateUrl: './fts-add-tat-items.component.html',
  styleUrls: ['./fts-add-tat-items.component.scss']
})
export class FtsAddTatItemsComponent implements OnInit {
  displayBasic1: boolean;

  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }

  showBasicDialog() {
    this.displayBasic1 = true;
  }

}
