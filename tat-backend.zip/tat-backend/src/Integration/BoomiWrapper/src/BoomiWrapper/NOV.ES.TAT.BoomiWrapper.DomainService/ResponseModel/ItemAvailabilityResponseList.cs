﻿namespace NOV.ES.TAT.BoomiWrapper.DomainService.ResponseModel
{
    public  class ItemAvailabilityResponseList
    {
        public List<ItemAvailabilityResponse> ResponseList { get; set; }
    }
}
