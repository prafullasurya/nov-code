import { Component, OnInit } from '@angular/core';

interface City {
  name: string,
  code: string
}
@Component({
  selector: 'item-listing-page',
  templateUrl: './item-listing-page.component.html',
  styleUrls: ['./item-listing-page.component.scss']
})
export class ItemListingPageComponent {
  
  displayBasic: boolean;
  displayCreateNft: boolean;
  displayOption: boolean;

    // ngOnInit(): void {
    //   throw new Error('Method not implemented.');
    // }
    showBasicDialog() {
      this.displayBasic = true;
    }
    showCreateNftDialog() {
      this.displayCreateNft = true;
    }
    showOptionDialog() {
      this.displayOption = true;
    }
}
