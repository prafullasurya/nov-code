import { Component} from '@angular/core';

interface City {
  name: string,
  code: string
}
@Component({
  selector: 'return-slip-single-item-assembly-completed',
  templateUrl: './return-slip-single-item-assembly-completed.component.html',
  styleUrls: ['./return-slip-single-item-assembly-completed.component.scss']
})
export class ReturnSlipSingleItemAssemblyCompletedComponent {
  
  


}
