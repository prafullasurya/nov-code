import { Component, OnInit } from '@angular/core';
import { Product } from '../../models/product';
import { ProductService } from '../../models/productservice';

@Component({
  selector: 'tat-portal-frontend-nft-header-details',
  templateUrl: './nft-header-details.component.html',
  styleUrls: ['./nft-header-details.component.scss']
})
export class nftHeaderDetailsComponent implements OnInit {
  products: Product[];
  

    constructor(private productService: ProductService) { }
  
    ngOnInit() {
        this.productService.getProductsWithOrdersSmall().then(data => this.products = data);
        console.log(this.products);
    }
}

