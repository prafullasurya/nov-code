import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MessageService, ConfirmationService } from 'primeng/api';
import { FormsModule } from '@angular/forms';
import { RemoteEntryComponent } from './entry.component';
import { RemoteEntryRoutingModule } from './entry-routing.module';
import { PrimeNgModule } from '@tat/core';
import { ENVIRONMENT } from '@tat/core';
import { environment } from '../../environments/environment';
import { SharedUtilAuthenticationModule } from '@tat/shared/util-authentication';
import { CustomerTransferFeatureCustomerTransferModule } from '@tat/customer-transfer/feature-customer-transfer';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { ItemsFeatureItemsSearchModule } from '@tat/items/feature-items-search';
import { FieldTransferFeatureFieldTransferModule } from '@tat/field-transfer/feature-field-transfer';

export function HttpLoaderFactory(http: HttpClient): TranslateHttpLoader {
  return new TranslateHttpLoader(http);
}

@NgModule({
  declarations: [RemoteEntryComponent],
  imports: [
    CommonModule,
    PrimeNgModule,
    FormsModule,
    CustomerTransferFeatureCustomerTransferModule,
    ItemsFeatureItemsSearchModule,
    FieldTransferFeatureFieldTransferModule,
    RemoteEntryRoutingModule,
    HttpClientModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient],
      },
    }),
    RouterModule.forChild([
      {
        path: '',
        component: RemoteEntryComponent,
      },
    ]),
    SharedUtilAuthenticationModule,
  ],
  providers: [
    MessageService,
    ConfirmationService,
    {
      provide: 'environment',
      useValue: environment,
    },
    {
      provide: ENVIRONMENT,
      useValue: environment,
    },
  ],
  exports:[
    TranslateModule
  ]
})
export class RemoteEntryModule {}
