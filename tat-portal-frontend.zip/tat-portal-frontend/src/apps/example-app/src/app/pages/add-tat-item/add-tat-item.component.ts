import { Component, OnInit } from '@angular/core';
import {MenuItem, SortEvent} from 'primeng/api';
import {SelectItem} from 'primeng/api';
import {SelectItemGroup} from 'primeng/api';
import { Product } from '../../models/product';
import { ProductService } from '../../models/productservice';

interface City {
  name: string,
  code: string,
  namelist: string
}

@Component({
  selector: 'tat-portal-frontend-add-tat-item',
  templateUrl: './add-tat-item.component.html',
  styleUrls: ['./add-tat-item.component.scss']
})

export class AddTatItemComponent implements OnInit {

cities: City[];
selectedCountry: string;
countries: any[];
items: SelectItem[];
item: string;
products1: Product[];
products: Product[];
ChangeSequenceDisplay: boolean;
primengConfig: any;

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  ngOnInit() {
    this.primengConfig.ripple = true;
  }

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  ChangeSequenceDialog() {
    this.ChangeSequenceDisplay = true;
  }
}
