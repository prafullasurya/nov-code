﻿using AutoMapper;
using NOV.ES.TAT.BoomiWrapper.Domain.WriteModels;
using NOV.ES.TAT.BoomiWrapper.DomainService.RequestModel;


namespace NOV.ES.TAT.BoomiWrapper.API.Helper
{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<GenerateInsertEDIGLRequest, InsertEDIGLRequest>();
            CreateMap<GenerateJobCreationRequest, JobCreationRequest>();
            CreateMap<GenerateItemAvailabilityRequest, ItemAvailabilityRequest>();
            CreateMap<GenerateInventoryAdjustmentRequest, InventoryAdjustmentRequest>();
            CreateMap<GenerateInventoryTransferRequest, InventoryTransferRequest>();
            CreateMap<GenerateCreateWorkOrderRequest, CreateWorkOrderRequest>();
            CreateMap<GenerateExchangeRateRequest, ExchangeRateRequest>();
            CreateMap<GenerateGetInventoryExtractRequest, GetInventoryExtractRequest>();
            CreateMap<GenerateSalesOrderStatusRequest, SalesOrderStatusRequest>();
            CreateMap<GenerateCreateWorkOrderRequest, CreateWorkOrderRequest>();
            CreateMap<GenerateItemBranchRequest, ItemBranchRequest>();
            CreateMap<GenerateItemMasterRequest, ItemMasterRequest>();
        }
    }
}
