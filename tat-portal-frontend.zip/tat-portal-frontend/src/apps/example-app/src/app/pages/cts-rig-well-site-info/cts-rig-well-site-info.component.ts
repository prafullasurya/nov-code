import { Component, OnInit } from '@angular/core';
import { TreeNode } from 'primeng/api';
import { Product } from '../../models/product';
import { ThemeService } from '../../services/theme.service';
import { NodeService } from './nodeservice';

interface City {
  name: string,
  code: string
}
@Component({
  selector: 'tat-portal-frontend-cts-rig-well-site-info',
  templateUrl: './cts-rig-well-site-info.component.html',
  styleUrls: ['./cts-rig-well-site-info.component.scss']
})

export class CtsRigWellSiteInfoComponent implements OnInit {
  cities: City[];
  selectedCity: City;
  date3: Date;
  selectedValues: string[] = [];
  ChangeSequenceDisplay: boolean;
  completeCustomerTransferSlipDisplay: boolean;
  city: string;
  search: string;
  products: Product[];
  files1: TreeNode[];
  
  constructor(private themeService : ThemeService, private nodeService: NodeService) { 
    
    this.cities = [
      {name: 'New York', code: 'NY'},
      {name: 'Rome', code: 'RM'},
      {name: 'London', code: 'LDN'},
      {name: 'Istanbul', code: 'IST'},
      {name: 'Paris', code: 'PRS'}
    ];

    this.selectedCity=this.cities[1];
  }
  
  ngOnInit() {
    this.nodeService.getFiles().then(files => this.files1 = files);
  }

    ChangeSequenceDialog() {
    this.ChangeSequenceDisplay = true;
    }
    completeCustomerTransferSlipDialog() {
      this.completeCustomerTransferSlipDisplay = true;
    }

}
