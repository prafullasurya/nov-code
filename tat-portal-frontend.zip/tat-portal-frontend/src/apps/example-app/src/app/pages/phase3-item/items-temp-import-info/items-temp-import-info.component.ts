import { Component, OnInit } from '@angular/core';
import { ConfirmationService, MessageService } from 'primeng/api';
import { Product } from '../../../models/product';
import { ProductService } from '../../../models/productservice';


interface City {
  name: string,
  code: string
}
@Component({
  selector: 'items-temp-import-info',
  templateUrl: './items-temp-import-info.component.html',
  styleUrls: ['./items-temp-import-info.component.scss']
})
export class ItemsTempImportInfoComponent {
  
  // activeIndex1: number = 0;

  // activeIndex2: number = 0;

  // scrollableTabs: any[] = Array.from({ length: 50 }, (_, i) => ({ title: `Tab ${i + 1}`, content: `Tab ${i + 1} Content` }));

}
