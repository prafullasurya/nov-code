import { ComponentFixture, TestBed } from '@angular/core/testing';

import { nftEditAssemblyComponent } from './nft-edit-assembly.component';

describe('nftEditAssemblyComponent', () => {
  let component: nftEditAssemblyComponent;
  let fixture: ComponentFixture<nftEditAssemblyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ nftEditAssemblyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(nftEditAssemblyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
