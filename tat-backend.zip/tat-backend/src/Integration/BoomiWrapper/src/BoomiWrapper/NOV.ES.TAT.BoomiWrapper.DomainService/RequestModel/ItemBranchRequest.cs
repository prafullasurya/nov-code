﻿using Newtonsoft.Json;
using NOV.ES.TAT.BoomiWrapper.Domain.WriteModels;

namespace NOV.ES.TAT.BoomiWrapper.DomainService.RequestModel
{
    public class ItemBranchRequest: BoomiRequestBaseModel
    {
        public int BusinessUnit { get; set; }
        [JsonProperty("Partnumber")]
        public string PartNumber { get; set; }
        public string[] Partnumberlist { get; set; }
        public string Description1 { get; set; }
        public string SerialNumber { get; set; }
        public string Location { get; set; }
    }
}
