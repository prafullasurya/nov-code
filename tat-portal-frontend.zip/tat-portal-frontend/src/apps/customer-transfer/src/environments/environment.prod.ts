export const environment = {
  production: true,
  guidtointenabled: true,
  apiHostUrl: 'https://tatservice.nov.cloud',
  errorLoggingApiEndPoint:'https://tatservice.nov.cloud/frontendcommonsvc/ErrorLogging',
  gridPageSize:50,
  dropdownPazeSize:100,
  assemblyUrl: 'https://wb.nov.com/tat/Tools/ToolsDetails.aspx?id=',
  componentUrl: 'https://wb.nov.com/tat/Components/ComponentsDetails.aspx?id=',
  usageUrl: 'https://wb.nov.com/tat/Usages/UsagesDetails.aspx?id=',
  OldTatURl: 'https://wb.nov.com/tat/',
};
