import { Component, OnInit } from '@angular/core';

interface City {
  name: string,
  code: string
}

@Component({
  selector: 'tat-portal-frontend-intransit-acceptance-listing',
  templateUrl: './intransit-acceptance-listing.component.html',
  styleUrls: ['./intransit-acceptance-listing.component.scss']
})
export class IntransitAcceptanceListingComponent implements OnInit {
  displayBasic: boolean;

  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }
  showBasicDialog() {
    this.displayBasic = true;
  } 
}
