﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.API.Helper;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetPaginationAttributeSetupsHandler : IQueryHandler<GetPaginationAttributeSetupsQuery, PagedResult<AttributeSetupDto>>
    {
        private readonly IMapper mapper;
        private readonly IAttributeSetupService attributeSetupService;
        private readonly IHttpContextAccessor httpContextAccessor;

        public GetPaginationAttributeSetupsHandler(
            IMapper mapper,
            IAttributeSetupService attributeSetupService,
            IHttpContextAccessor httpContextAccessor)
        {
            this.mapper = mapper;
            this.attributeSetupService = attributeSetupService;
            this.httpContextAccessor = httpContextAccessor;
        }
        public Task<PagedResult<AttributeSetupDto>> Handle(GetPaginationAttributeSetupsQuery request,
            CancellationToken cancellationToken)
        {
            var attributeSetups = attributeSetupService.GetAttributeSetups(request.PagingParameters);
            var result = mapper.Map<PagedResult<AttributeSetup>, PagedResult<AttributeSetupDto>>(attributeSetups);
            PagingHelper.AddPagingMetadata<AttributeSetupDto>(result, httpContextAccessor);
            return Task.FromResult(result);
        }
    }
}
