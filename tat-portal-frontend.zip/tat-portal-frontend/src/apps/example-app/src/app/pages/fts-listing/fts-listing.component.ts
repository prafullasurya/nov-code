import { Component, OnInit } from '@angular/core';
import {TreeNode} from 'primeng/api';
import { ProductService } from '../../models/productservice';
import { Product } from '../../models/product';

interface City {
  name: string,
  code: string
}

@Component({
  selector: 'tat-portal-frontend-fts-listing',
  templateUrl: './fts-listing.component.html',
  styleUrls: ['./fts-listing.component.scss']
})
export class FtsListingComponent implements OnInit {
  displayBasic: boolean;

  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }
  showBasicDialog() {
    this.displayBasic = true;
  } 
}
