﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.API.Helper;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;
using NOV.ES.TAT.Admin.DomainService.Interfaces;

namespace NOV.ES.TAT.Admin.API.Application.Queries.GetPagination
{
    public class GetPaginationTransferTypesHandler
           : IQueryHandler<GetPaginationTransferTypesQuery, PagedResult<TransferTypeDto>>
    {
        private readonly IMapper mapper;
        private readonly ITransferTypeService transferTypeService;
        private readonly IHttpContextAccessor httpContextAccessor;

        public GetPaginationTransferTypesHandler(
            IMapper mapper
            , ITransferTypeService transferTypeService
            , IHttpContextAccessor httpContextAccessor)
        {
            this.mapper = mapper;
            this.transferTypeService = transferTypeService;
            this.httpContextAccessor = httpContextAccessor;
        }
        public Task<PagedResult<TransferTypeDto>> Handle(GetPaginationTransferTypesQuery request,
          CancellationToken cancellationToken)
        {
            var transferTypes = transferTypeService.GetTransferTypes(request.PagingParameters);
            var result = mapper.Map<PagedResult<TransferType>, PagedResult<TransferTypeDto>>(transferTypes);

            PagingHelper.AddPagingMetadata<TransferTypeDto>(result, httpContextAccessor);
            return Task.FromResult(result);
        }
    }
}
