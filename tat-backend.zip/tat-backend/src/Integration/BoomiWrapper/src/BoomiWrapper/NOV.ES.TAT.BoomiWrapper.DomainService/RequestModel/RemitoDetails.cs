﻿namespace NOV.ES.TAT.BoomiWrapper.DomainService.RequestModel
{
    public class RemitoDetails
	{
		public string PartNumber { get; set; }
		public string Description { get; set; }
		public string UnitOfMeasure { get; set; }
		public string SerialNumber { get; set; }
		public string CustomDispatchNumber { get; set; }
		public string Count { get; set; }
		public string Comments { get; set; }
		public decimal NBVBase { get; set; }
		public decimal NBVUSD { get; set; }

    }
}
