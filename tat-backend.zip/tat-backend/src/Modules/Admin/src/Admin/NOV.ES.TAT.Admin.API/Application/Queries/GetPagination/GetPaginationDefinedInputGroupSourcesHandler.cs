﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetPaginationDefinedInputGroupSourcesHandler : IQueryHandler<GetPaginationDefinedInputGroupSourcesQuery, PagedResult<DefinedInputGroupSourceDto>>
    {
        private readonly IMapper mapper;
        private readonly IDefinedInputGroupSourceService definedInputGroupSourceService;
        private readonly IHttpContextAccessor httpContextAccessor;

        public GetPaginationDefinedInputGroupSourcesHandler(
            IMapper mapper,
            IDefinedInputGroupSourceService definedInputGroupSourceService,
            IHttpContextAccessor httpContextAccessor)
        {
            this.mapper = mapper;
            this.definedInputGroupSourceService = definedInputGroupSourceService;
            this.httpContextAccessor = httpContextAccessor;
        }
        public Task<PagedResult<DefinedInputGroupSourceDto>> Handle(GetPaginationDefinedInputGroupSourcesQuery request,
            CancellationToken cancellationToken)
        {
            var definedInputGroupSource = definedInputGroupSourceService.GetDefinedInputGroupSources(request.PagingParameters);
            var result = mapper.Map<PagedResult<DefinedInputGroupSource>, PagedResult<DefinedInputGroupSourceDto>>(definedInputGroupSource);
            if (result.Paging != null)
            {
                httpContextAccessor.HttpContext.Response.Headers.Add("X-Paging-PageCount", result.TotalNumberOfPages.ToString());
                httpContextAccessor.HttpContext.Response.Headers.Add("X-Paging-TotalRecordCount", result.TotalNumberOfItems.ToString());
                httpContextAccessor.HttpContext.Response.Headers.Add("X-Paging-PageIndex", result.Paging.PageIndex.ToString());
                httpContextAccessor.HttpContext.Response.Headers.Add("X-Paging-PageSize", result.Paging.PageSize.ToString());
            }
            return Task.FromResult(result);
        }
    }
}
