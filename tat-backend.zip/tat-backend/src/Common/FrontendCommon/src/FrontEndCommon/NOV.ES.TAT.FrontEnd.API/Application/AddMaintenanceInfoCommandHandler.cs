﻿using FluentValidation.Results;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using NOV.ES.Framework.Core.CQRS.Commands;
using NOV.ES.TAT.FrontEnd.API.DTOs;
using NOV.ES.TAT.FrontEnd.API.Validators;
using NOV.ES.TAT.FrontEnd.DomainService;
using System.Net;
using System.Net.Mime;

namespace NOV.ES.TAT.CustomerTransfer.EventSourcing.API.Application.Commands
{
    public class AddMaintenanceInfoCommandHandler
         : ICommandHandler<AddMaintenanceInfoCommand, ContentResult>
    {
        private readonly ILogger<AddMaintenanceInfoCommandHandler> logger;
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly IMaintenanceService maintenanceService;


        public AddMaintenanceInfoCommandHandler(
            ILogger<AddMaintenanceInfoCommandHandler> logger,
            IHttpContextAccessor httpContextAccessor,
            IMaintenanceService maintenanceService)
        {
            this.logger = logger;
            this.httpContextAccessor = httpContextAccessor;
            this.maintenanceService = maintenanceService;
        }

        public async Task<ContentResult> Handle(AddMaintenanceInfoCommand request, CancellationToken cancellationToken)
        {
            logger.LogInformation("----- Create Maintenance Info Request ", request);
            ContentResult contentResult = new()
            {
                ContentType = MediaTypeNames.Application.Json
            };

            ValidationResult validationResult = new MaintenanceInfoCommandValidator().Validate(request);
            if (!validationResult.IsValid)
            {
                contentResult.Content = JsonConvert.SerializeObject(validationResult.Errors);
                contentResult.StatusCode = (int)HttpStatusCode.BadRequest;
                return await Task.FromResult(contentResult);
            }
            else
            {
                MaintenanceDto response = null;
                var result = maintenanceService.AddMaintenanceInfo(request);
                if (result != null)
                {
                    
                    logger.LogInformation($"Start: Maintenance Process for System Down");
                    contentResult.StatusCode = (int)HttpStatusCode.Created;
                    response = new MaintenanceDto(result.DownTimeReason, result.MessageId, result.ExpectedResumeBy, result.ScheduledOn);
                    logger.LogInformation($"End: Create Maintenance Process for System Down is completed {response}");
                    
                }
                else
                {
                    contentResult.StatusCode = (int)HttpStatusCode.InternalServerError;
                    response = null;
                }

                contentResult.Content = JsonConvert.SerializeObject(response);
                return await Task.FromResult(contentResult);
            }
            //return null;
        }
    }

    //public class MaintenanceDto
    //{
    //    public string MessageId { get; set; }
    //    public string DownTimeReason { get; set; }
    //    public DateTime? ExpectedResumeBy { get; set; }
    //    public DateTime? ScheduledOn { get; set; }

    //    public MaintenanceDto(string downTimeReason, string messageId,
    //        DateTime? expectedResumeBy, DateTime? scheduledOn)
    //    {
    //        DownTimeReason = downTimeReason;
    //        ExpectedResumeBy = expectedResumeBy;
    //        ScheduledOn = scheduledOn;
    //        MessageId = messageId;
    //    }
    //}
}
