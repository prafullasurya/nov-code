import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ActiveUsageAttachComponent } from './active-usage-attach.component';

describe('ActiveUsageAttachComponent', () => {
  let component: ActiveUsageAttachComponent;
  let fixture: ComponentFixture<ActiveUsageAttachComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ActiveUsageAttachComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ActiveUsageAttachComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
function beforeEach(arg0: () => void) {
  throw new Error('Function not implemented.');
}

