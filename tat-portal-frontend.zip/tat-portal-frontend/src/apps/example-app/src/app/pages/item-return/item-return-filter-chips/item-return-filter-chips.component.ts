import { Component } from '@angular/core';

@Component({
  selector: 'item-return-filter-chips',
  templateUrl: './item-return-filter-chips.component.html',
  styleUrls: ['./item-return-filter-chips.component.scss'],
})
export class ItemReturnFilterChipsComponent {
  
}
