import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'usage-item-screen',
  templateUrl: './usage-item-screen.component.html',
  styleUrls: ['./usage-item-screen.component.scss']
})
export class UsageItemScreenComponent {

}
