﻿namespace NOV.ES.TAT.EmailService.Helper
{
    public static class ContentReplacer
    {
        public static EmailContent ReplaceBody(ref EmailContent content, List<EmailAttributes> attributeList)
        {
            foreach (EmailAttributes attr in attributeList)
            {
                content = Replace(ref content, attr.AttributeName, attr.AttributeValue);
            }

            return content;
        }

        public static EmailContent Replace(ref EmailContent content, string key, string value)
        {
            List<string> oldFromSubjectBody = new List<string>();           
                oldFromSubjectBody.Add(content.From);
                oldFromSubjectBody.Add(content.Subject);
                oldFromSubjectBody.Add(content.Body);            

            List<string> fromSubjectBody = new List<string>();
            //foreach will iterate three times
            //And the sequence will always be for From, Subject and Body
            foreach (string unreplacedContent in oldFromSubjectBody)
            {
                if (unreplacedContent.Contains(key))
                {
                    fromSubjectBody.Add(unreplacedContent.Replace(key, value));
                }
                else
                {
                    fromSubjectBody.Add(unreplacedContent);
                }
            }

            content.From = fromSubjectBody[0];
            content.Subject = fromSubjectBody[1];
            content.Body = fromSubjectBody[2];
            return content;
        }

    }

}
