import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ItemsAttributesEditComponent } from './tems-attributes-edit.component';

describe('ItemsAttributesEditComponent', () => {
  let component: ItemsAttributesEditComponent;
  let fixture: ComponentFixture<ItemsAttributesEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ItemsAttributesEditComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ItemsAttributesEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
function beforeEach(arg0: () => void) {
  throw new Error('Function not implemented.');
}

