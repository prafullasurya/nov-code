﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.API.Helper;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetPaginationTatReferencesHandler : IQueryHandler<GetPaginationTatReferencesQuery, PagedResult<TatReferenceDto>>
    {
        private readonly IMapper mapper;
        private readonly ITatReferenceService tatReferenceService;
        private readonly IHttpContextAccessor httpContextAccessor;

        public GetPaginationTatReferencesHandler(
            IMapper mapper,
            ITatReferenceService tatReferenceService,
            IHttpContextAccessor httpContextAccessor)
        {            
            this.mapper = mapper;
            this.tatReferenceService = tatReferenceService;
            this.httpContextAccessor = httpContextAccessor;
        }
        public Task<PagedResult<TatReferenceDto>> Handle(GetPaginationTatReferencesQuery request,
            CancellationToken cancellationToken)
        {
            var tatReferences = tatReferenceService.GetTatReferences(request.PagingParameters);
            var result = mapper.Map<PagedResult<TatReference>, PagedResult<TatReferenceDto>>(tatReferences);
            PagingHelper.AddPagingMetadata<TatReferenceDto>(result, httpContextAccessor);
            return Task.FromResult(result);
        }
    }
}
