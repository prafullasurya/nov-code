﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NOV.ES.TAT.BoomiWrapper.Domain
{
    [Table("BoomiRequestResponse")]
    public class BoomiRequestResponse
    {
        public long Id { get; set; }
        public Guid RequestId { get; set; }
        public Guid CorelationId { get; set; }
        public long? EventId { get; set; }
        [MaxLength(100)]
        public string KeyName { get; set; }
        [MaxLength(200)]
        public string KeyValue { get; set; }
        public DateTime? RequestDateTime { get; set; }
        [MaxLength(30)]
        public string RequestStatus { get; set; }
        public string RequestBody { get; set; }
        [MaxLength(200)]
        public string RequestURL { get; set; }
        [MaxLength(200)]
        public string RequestMethod { get; set; }
        [MaxLength(8)]
        public string HttpVerb { get; set; }
        public string RequestQueryParameters { get; set; }
        [MaxLength(100)]
        public string SourceApplication { get; set; }
        [MaxLength(30)]
        public string SourceIPAddress { get; set; }
        [MaxLength(30)]
        public string MachineName { get; set; }
        [MaxLength(50)]
        public string Status { get; set; }
        public string ErrorMessage { get; set; }
        [MaxLength(30)]
        public string ResponseStatus { get; set; }
        public string ResponseBody { get; set; }
        public DateTime? ResponseDateTime { get; set; }
        public int RetryCount { get; set; }
        [MaxLength(100)]
        public string ActionBy { get; set; }
        [MaxLength(256)]
        public string ProcessId { get; set; }
        [MaxLength(512)]
        public string ProcessName { get; set; }
        [MaxLength(512)]
        public string ThreadName { get; set; }
        [MaxLength(128)]
        public string ThreadId { get; set; }
    }
}
