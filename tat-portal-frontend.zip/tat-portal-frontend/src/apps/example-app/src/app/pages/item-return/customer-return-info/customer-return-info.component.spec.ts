import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerReturnInfoComponent } from './customer-return-info.component';

describe('CustomerReturnSlipComponent', () => {
  let component: CustomerReturnInfoComponent;
  let fixture: ComponentFixture<CustomerReturnInfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerReturnInfoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerReturnInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
