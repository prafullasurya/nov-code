﻿using NOV.ES.Framework.Core.Data.Repositories;
using NOV.ES.TAT.BoomiWrapper.Domain;

namespace NOV.ES.TAT.BoomiWrapper.Infrastructure
{
    public class BoomiRequestResponseCommandRepository
        : GenericWriteRepository<BoomiRequestResponse>
        , IBoomiRequestResponseCommandRepository
    {
        private readonly InterfaceDBContext interfaceDBContext;

        public BoomiRequestResponseCommandRepository(InterfaceDBContext interfaceDBContext)
            : base(interfaceDBContext)
        {
            this.interfaceDBContext = interfaceDBContext;
        }

        public int SaveChanges()
        {
            return interfaceDBContext.SaveChanges();
        }

        public Task<int> SaveChangesAsync(CancellationToken cancellationToken)
        {
            return interfaceDBContext.SaveChangesAsync(cancellationToken);
        }
    }
}
