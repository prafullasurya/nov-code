﻿using NOV.ES.Framework.Core.Entities;

namespace NOV.ES.TAT.BoomiWrapper.Domain.ReadModel
{
    public class FieldTransferSlip : BaseEntity<int>
    {
        public int FieldTransferNumber { get; set; }
        public int? FromErpJobNumber { get; set; }
        public string FromErpJobDescription { get; set; }
        public int? ToErpJobNumber { get; set; }
        public string ToErpJobDescription { get; set; }
        public int FromCompanyId { get; set; }
        public string FromCompanyCode { get; set; }
        public string FromCompanyName { get; set; }
        public int ToCompanyId { get; set; }
        public string ToCompanyCode { get; set; }
        public string ToCompanyName { get; set; }
        public int FromCcId { get; set; }
        public string FromCcCode { get; set; }
        public string FromCcName { get; set; }
        public int ToCcId { get; set; }
        public string ToCcCode { get; set; }
        public string ToCcName { get; set; }
        public int FromCustomerId { get; set; }
        public long? FromCustomerCode { get; set; }
        public string FromCustomerName { get; set; }
        public int ToCustomerId { get; set; }
        public long? ToCustomerCode { get; set; }
        public string ToCustomerName { get; set; }
        public int? ActualCustomerId { get; set; }
        public long? ActualCustomerCode { get; set; }
        public string ActualCustomerName { get; set; }
        public Guid? FromCorpRigId { get; set; }
        public string FromRigName { get; set; }
        public Guid? ToCorpRigId { get; set; }
        public string ToRigName { get; set; }
        public Guid? CorpWellSiteId { get; set; }
        public string WellName { get; set; }
        public string WellLocation { get; set; }
        public string WellNameSource { get; set; }
        public string SalesZoneCode { get; set; }
        public string SalesZoneName { get; set; }
        public DateTime SlipDate { get; set; }
        public DateTime? TransferDate { get; set; }
        public int? IntendedUseId { get; set; }
        public string IntendedUse { get; set; }
        public int? OilCompanyId { get; set; }
        public string OilCompanyName { get; set; }
        public int? DrillingApplicationId { get; set; }
        public string DrillingApplicationName { get; set; }
        public int? BillingApplicationId { get; set; }
        public string BillingApplicationName { get; set; }
        public string ShipToAddressNumber { get; set; }
        public string ShipToAddress { get; set; }
        public string SalesPersonCode { get; set; }
        public string SalesPersonName { get; set; }
        public string RentalAgreement { get; set; }
        public string CustomerContactName { get; set; }
        public string CustomerContactNumber { get; set; }
        public string CustomerPoAfe { get; set; }
        public string CustomerJobNumber { get; set; }
        public string FreightTypeCode { get; set; }
        public string FreightTypeName { get; set; }
        public string OtherDocInfo { get; set; }
        public string OtherDocNumber { get; set; }
        public string BillOfLading { get; set; }
        public string WayBill { get; set; }
        public string FieldTicket { get; set; }
        public string LsdCounty { get; set; }
        public string Consignee { get; set; }
        public string ShippingInstruction { get; set; }
        public string Currency { get; set; }
        public string CommercialInvoiceInfo { get; set; }
        public int? SlipType { get; set; }
        public string ErrorMessage { get; set; }
        public Int16 IsCompleted { get; set; }
        public string ContractorName { get; set; }
        public long AggregateVersion { get; set; }
        public string PreparedBy { get; set; }
        public int EventInfoId { get; set; } 
        public virtual ICollection<FieldTransferSlipDetail> FieldTransferSlipDetails { get; set; }
    }
}
