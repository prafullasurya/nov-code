﻿
namespace NOV.ES.TAT.Common.UserPermissions
{
    public static class Constants
    {
        public const string MAINT_PKG_SLIP = "Maintain Packing Slip";
        public const string ADD = "Add";
        public const string EDIT = "Edit";
        public const string DELETE = "Delete";
        public const string DEFAULT_ERP_SYSTEM = "JDE";
    }
}
