﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using NOV.ES.TAT.EmailService.API;
using NOV.ES.TAT.EmailService.API.Dtos;
using NOV.ES.TAT.EmailService.Helper;
using Serilog.Core;
using System.Data;
using System.Net;
using System.Net.Mail;
using System.Xml;
using Constants = NOV.ES.TAT.EmailService.API.Constants;

namespace NOV.ES.TAT.EmailService.Service
{
    public class EmailBase : IEmailBaseService
    {
        public List<string>? ToList { get; set; }
        public List<string>? CcList { get; set; }
        public List<string>? BccList { get; set; }
        public string? Subject { get; set; }
        public string? Body { get; set; }
        public string? FileName { get; set; }
        private readonly EmailConfiguration emailConfiguration = null;
        ILogger<EmailBase> logger;

        private readonly IConfiguration configuration;

        public EmailBase(ILogger<EmailBase> logger, IConfiguration configuration)
        {
            this.configuration = configuration;
            var emailConfigSec = this.configuration.GetSection("EmailConfigurationsSecret");
            emailConfiguration = Newtonsoft.Json.JsonConvert.DeserializeObject<EmailConfiguration>(emailConfigSec.Value);
            this.logger = logger;
        }

        public EmailStatus NotifiersWithFile(EmailFlieDto emailParam)
        {

            try
            {
                this.ToList = emailParam.ToList;
                this.CcList = emailParam.CcList;
                this.BccList = emailParam.BccList;
                DataSet ds = new DataSet();
                ds.ReadXml(XmlReader.Create(new StringReader(emailParam.XmlDataSet)));
                EmailContent content = new EmailContent(ds);
                content = ContentReplacer.ReplaceBody(ref content, emailParam.AttributeList);
                this.Subject = content.Subject ?? "ERR";
                this.Body = content.Body;

                return DoNotify();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private MemoryStream GetFileStream(string fileName)
        {
            return new MemoryStream(File.ReadAllBytes(fileName));
        }

        private EmailStatus DoNotify()
        {
            try
            {
                if (ToList != null && ToList.Count > 0)
                {
                    using (var mailMessage = new MailMessage())
                    {
                        mailMessage.Subject = Subject;
                        mailMessage.Body = Body;
                        mailMessage.IsBodyHtml = true;

                        foreach (string toEmailAddress in ToList)
                        {
                            if (!String.IsNullOrEmpty(toEmailAddress))
                            {
                                if (string.IsNullOrEmpty(toEmailAddress))
                                    continue;
                                mailMessage.To.Add(toEmailAddress);
                            }
                        }

                        if (CcList != null && CcList.Count > 0)
                        {
                            foreach (string ccEmailAddress in CcList)
                            {
                                if (!string.IsNullOrEmpty(ccEmailAddress))
                                    mailMessage.CC.Add(ccEmailAddress);
                            }
                        }
                        if (BccList != null && BccList.Count > 0)
                        {
                            foreach (string bccEmailAddress in BccList)
                            {
                                if (!string.IsNullOrEmpty(bccEmailAddress))
                                    mailMessage.Bcc.Add(bccEmailAddress);
                            }
                        }

                        if (File.Exists(FileName))
                        {
                            Attachment attachment = new Attachment(FileName);
                            mailMessage.Attachments.Add(attachment);

                        }

                        if (emailConfiguration != null)
                        {
                            using (SmtpClient email = new SmtpClient(emailConfiguration.SMTPHost, emailConfiguration.SMTPPort))
                            {
                                try
                                {
                                    mailMessage.From = new MailAddress(emailConfiguration.EmailFrom);
                                    logger.LogInformation("Sending email with SMTPHost: {SMTPHost}, SMTPPort:{SMTPPort}, FromEmail:{fromEmail}, UserName:{UserName}, message: {message}",
                                       emailConfiguration.SMTPHost, emailConfiguration.SMTPPort, emailConfiguration.EmailFrom, emailConfiguration.Username, mailMessage.Body);
                                    email.Send(mailMessage);
                                }
                                catch (Exception ex)
                                {
                                    logger.LogInformation("Exception occured while sending email, error : {error}", ex.Message);
                                    logger.LogError("Exception occured while sending email: {ex}", ex);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                logger.LogInformation("Email NOT sent, status code:{code}", "400");
                return new EmailStatus { StatusCode = 400, Message = Constants.EMAIL_SEND_ERROR_MSG };
            }
            logger.LogInformation("Email sent susscussfully, status code:{code}", "200");
            //If the code is reaching here means the email is successfully sent
            return new EmailStatus { StatusCode = 200, Message = Constants.EMAIL_SEND_SUCCESS_MSG };
        }

        public EmailStatus Notifiers(EmailDto emailParam)
        {
            try
            {
                this.ToList = emailParam.ToList;
                this.CcList = emailParam.CcList;
                this.BccList = emailParam.BccList;
                this.Subject = emailParam.Subject ?? "ERR";
                this.Body = emailParam.Body;

                if (!string.IsNullOrWhiteSpace(emailParam.FileName))
                {
                    this.FileName = emailParam.FileName;
                }
                return DoNotify();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
