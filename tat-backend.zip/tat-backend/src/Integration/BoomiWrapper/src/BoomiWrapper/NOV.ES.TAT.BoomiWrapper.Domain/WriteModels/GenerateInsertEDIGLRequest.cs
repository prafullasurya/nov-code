﻿namespace NOV.ES.TAT.BoomiWrapper.Domain.WriteModels
{
    public class GenerateInsertEDIGLRequest : BoomiRequestBaseModel
    {
        public string EDIUserId { get; set; }
        public string UserId { get; set; }
        public string ProgramId { get; set; }
        public string WorkStationId { get; set; }
        public string SuccessfullyProcess { get; set; }
        public string CurrencyMode { get; set; }
        public DateTime EDIUTransmissionDateserId { get; set; }
        public DateTime DateForGLandVoucher { get; set; }
        public DateTime DateTimeUpdated { get; set; }
        public int TransactNumber { get; set; }
        public string EDIDocumentType { get; set; }
        public int LineNumber { get; set; }
        public string SendRcvIndicator { get; set; }
        public string TransactionAction { get; set; }
        public string TransactionType { get; set; }
        public int BatchNumber { get; set; }
        public string CompanyKey { get; set; }
        public string DocumentType { get; set; }
        public string BatchType { get; set; }
        public string Company { get; set; }
        public string AccountNumberInputMode { get; set; }
        public string AccountModeGL { get; set; }
        public int AccountId { get; set; }
        public string CostCenter { get; set; }
        public string ObjectAccount { get; set; }
        public string Subsidiary { get; set; }
        public string LedgerType { get; set; }
        public decimal Amount { get; set; }
        public int Units { get; set; }
        public string AlphaExplanation { get; set; }
        public string RemarkExplanation { get; set; }
        public int VendorInvoiceNumber { get; set; }
        public DateTime DateInvoice { get; set; }
        public string Subledger { get; set; }
        public string SubledgerType { get; set; }
        public string CurrencyCodeFrom { get; set; }
        public string AmountCurrency { get; set; }
        public string Reference2 { get; set; }
    }
}
