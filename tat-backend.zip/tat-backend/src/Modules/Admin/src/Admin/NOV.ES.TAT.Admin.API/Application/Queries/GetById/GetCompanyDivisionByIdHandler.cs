﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetCompanyDivisionByIdHandler : IQueryHandler<GetCompanyDivisionByIdQuery, CompanyDivisionDto>
    {
        private readonly IMapper mapper;
        private readonly ICompanyDivisionService companyDivisionService;

        public GetCompanyDivisionByIdHandler(
            IMapper mapper,
            ICompanyDivisionService companyDivisionService)
        {
            this.mapper = mapper;
            this.companyDivisionService = companyDivisionService;
        }

        public Task<CompanyDivisionDto> Handle(GetCompanyDivisionByIdQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var companyDivision = companyDivisionService.GetCompanyDivisionById(request.Id);
            var result = mapper.Map<CompanyDivision, CompanyDivisionDto>(companyDivision);
            return Task.FromResult(result);
        }
        private static bool IsValidRequest(GetCompanyDivisionByIdQuery request)
        {
            return (request != null && request.Id != 0);
        }
    }
}