﻿using IdentityModel.AspNetCore.OAuth2Introspection;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;
using NOV.ES.TAT.AppNotification.API.Constant;
using Swashbuckle.AspNetCore.Filters;
using System.IdentityModel.Tokens.Jwt;

namespace NOV.ES.TAT.AppNotification.API
{
    public static class DependencyRegistrar
    {
        public static IServiceCollection AddCustomMvc(this IServiceCollection services)
        {
            services.AddControllers(
           // options => options.Filters.Add(typeof(HttpGlobalExceptionFilter))
           ).AddNewtonsoftJson(
               joptions =>
               {
                   joptions.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();
                   joptions.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
                   joptions.SerializerSettings.Converters.Add(new StringEnumConverter());
               }
           );
            services.AddCors(options =>
            {
                options.AddPolicy("CorsPolicy",
                    builder => builder
                    .SetIsOriginAllowed((host) => true)
                    //.AllowAnyOrigin()
                    .AllowAnyMethod()
                    .AllowAnyHeader()
                    .AllowCredentials());
            });
            return services;
        }
        public static IServiceCollection AddHealthChecks(this IServiceCollection services, IConfiguration configuration)
        {
            var hcBuilder = services.AddHealthChecks();
            hcBuilder.AddCheck("self", () => HealthCheckResult.Healthy());
            return services;
        }
        public static IServiceCollection AddCustomDbContext(this IServiceCollection services, IConfiguration configuration)
        {
            //services.AddDbContext<CustomerTransferSlipProjectionDbContext>(options =>
            //{
            //    options.UseSqlServer(configuration["CustomerTransferDBConnString"],
            //        sqlServerOptionsAction: sqlOptions =>
            //        {
            //            sqlOptions.MigrationsAssembly(typeof(Startup).GetTypeInfo().Assembly.GetName().Name);
            //            sqlOptions.EnableRetryOnFailure(maxRetryCount: 3, maxRetryDelay: TimeSpan.FromSeconds(30), errorNumbersToAdd: null);
            //        });
            //},
            //ServiceLifetime.Transient,
            //ServiceLifetime.Singleton
            //);
            return services;
        }
        public static IServiceCollection AddCustomSwagger(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v1", new OpenApiInfo
                {
                    Title = "TAT App Notification Service",
                    Version = "v1",
                    Description = "Realtime Application notification using SignalR"
                });
                options.AddSecurityDefinition("Bearer", new Microsoft.OpenApi.Models.OpenApiSecurityScheme
                {
                    Description = "Standard Authorization header using the Bearer scheme. Example: \"bearer {token}\"",
                    In = ParameterLocation.Header,
                    Name = "Authorization",
                    Type = SecuritySchemeType.ApiKey
                });

                options.OperationFilter<SecurityRequirementsOperationFilter>();
            });
            return services;
        }

        public static IServiceCollection AddCustomAuthentication(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddAuthentication(OAuth2IntrospectionDefaults.AuthenticationScheme)
            .AddOAuth2Introspection(options =>
            {
                options.Authority = configuration["Authority"];
                options.ClientId = configuration["ClientId"];

                options.Events = new OAuth2IntrospectionEvents()
                {
                    OnTokenValidated = context =>
                    {
                        var jwtSecurityToken = new JwtSecurityTokenHandler().ReadToken(context.SecurityToken);
                        context.HttpContext.Items["user_email_id"] = ((JwtSecurityToken)jwtSecurityToken)
                        .Claims.FirstOrDefault(c => c.Type == "sub").Value;
                        context.HttpContext.Items["access_token"] = (JwtSecurityToken)jwtSecurityToken;
                        return Task.CompletedTask;
                    }
                };
            })
            .AddJwtBearer(Constants.IDENTITY_AUTH_SCHEME, options =>
            {
                /// local url from rancher for internal identity server
                /// http://tat-identity-server.trackatool-dev.svc.cluster.local
                options.Authority = configuration["InternalIdentity"];
                options.RequireHttpsMetadata = false;

                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateAudience = false
                };
                options.Events = new Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerEvents()
                {
                    OnTokenValidated = context =>
                    {
                        context.HttpContext.Items["x-internal-identity"] = "true";
                        return Task.CompletedTask;
                    }
                };
            });
            return services;
        }
        public static IServiceCollection AddCustomSignalR(this IServiceCollection services)
        {
            services.AddSignalR();
            return services;
        }
    }
}
