﻿using NOV.ES.Framework.Core.Data.Repositories;
using NOV.ES.TAT.BoomiWrapper.Domain;

namespace NOV.ES.TAT.BoomiWrapper.Infrastructure
{
    public class ErpSoftCommitmentLogCommandRepository
        : GenericWriteRepository<ErpSoftCommitmentLog>
        , IErpSoftCommitmentLogCommandRepository
    {
        private readonly InterfaceDBContext interfaceDBContext;

        public ErpSoftCommitmentLogCommandRepository(InterfaceDBContext interfaceDBContext)
            : base(interfaceDBContext)
        {
            this.interfaceDBContext = interfaceDBContext;
        }

        public void Update(string erpDocNumber, string erpDocType, string errorMessage, string lastUpdateBy, int latestBatchId)
        {
            interfaceDBContext.ErpSoftCommitmentLogs.Where(t => t.ErpItemsBatchId == latestBatchId).ToList().ForEach(t =>
            {
                t.ErpDocNumber = erpDocNumber;
                t.ErpDocType = erpDocType;
                t.ErrorMessage = string.IsNullOrEmpty(errorMessage) ? string.Empty : (errorMessage.Length > 1000) ? errorMessage.Substring(0, 1000) : errorMessage;
                t.ModifiedBy = lastUpdateBy;
                t.DateModified = DateTime.UtcNow;
            });
            interfaceDBContext.SaveChanges();
        }

        public int SaveChanges()
        {
            return interfaceDBContext.SaveChanges();
        }

        public Task<int> SaveChangesAsync(CancellationToken cancellationToken)
        {
            return interfaceDBContext.SaveChangesAsync(cancellationToken);
        }
    }
}
