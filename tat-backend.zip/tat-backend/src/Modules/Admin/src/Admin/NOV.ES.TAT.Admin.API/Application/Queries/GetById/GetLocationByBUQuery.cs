﻿using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Admin.API.DTOs;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetLocationByBUQuery : IQuery<PagedResult<LocationDto>>
    {
        public string BUCode { get; private set; }
        public string searchText { get; private set; }
        public Paging PagingParameters { get; private set; }

        public GetLocationByBUQuery(string buCode,string searchText, Paging pagingParameters)
        {
            this.BUCode = buCode;
            this.searchText = searchText;
            this.PagingParameters = pagingParameters;
        }
    }
}
