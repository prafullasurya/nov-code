﻿namespace NOV.ES.TAT.BoomiWrapper.Domain.WriteModels
{
    public class CreateSalesOrderHeaderSalesCommisionInfo
    {
        public int commissionLineNumber { get; set; }
        public int commissionTypeCode { get; set; }
        public int salesReportGroup { get; set; }
    }
}
