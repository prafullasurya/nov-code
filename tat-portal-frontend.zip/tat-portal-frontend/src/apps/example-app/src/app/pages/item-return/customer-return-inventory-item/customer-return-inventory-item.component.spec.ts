import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerReturnInventoryItemComponent } from './customer-return-inventory-item.component';

describe('CustomerReturnInventoryItemComponent', () => {
  let component: CustomerReturnInventoryItemComponent;
  let fixture: ComponentFixture<CustomerReturnInventoryItemComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerReturnInventoryItemComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerReturnInventoryItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
