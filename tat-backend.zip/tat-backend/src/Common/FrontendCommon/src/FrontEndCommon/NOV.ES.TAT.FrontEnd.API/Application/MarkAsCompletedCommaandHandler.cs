﻿using Microsoft.AspNetCore.Mvc;
using NOV.ES.Framework.Core.CQRS.Commands;
using NOV.ES.TAT.CustomerTransfer.EventSourcing.API.Application.Commands;
using NOV.ES.TAT.FrontEnd.API.DTOs;
using NOV.ES.TAT.FrontEnd.API.Validators;
using NOV.ES.TAT.FrontEnd.DomainService;
using System.Net.Mime;
using System.Net;
using FluentValidation.Results;
using Newtonsoft.Json;

namespace NOV.ES.TAT.FrontEnd.API.Application
{
    public class MarkAsCompletedCommaandHandler
        : ICommandHandler<MarkAsCompletedCommaand, ContentResult>
    {
        private readonly ILogger<MarkAsCompletedCommaandHandler> logger;
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly IMaintenanceService maintenanceService;

        public MarkAsCompletedCommaandHandler(
            ILogger<MarkAsCompletedCommaandHandler> logger,
            IHttpContextAccessor httpContextAccessor,
            IMaintenanceService maintenanceService)
        {
            this.logger = logger;
            this.httpContextAccessor = httpContextAccessor;
            this.maintenanceService = maintenanceService;
        }

        public async Task<ContentResult> Handle(MarkAsCompletedCommaand request, CancellationToken cancellationToken)
        {
            logger.LogInformation("----- Mark Maintenance as completed ", request);
            ContentResult contentResult = new()
            {
                ContentType = MediaTypeNames.Application.Json
            };

            ValidationResult validationResult = new MarkAsCompletedCommaandValidator().Validate(request);
            if (!validationResult.IsValid)
            {
                contentResult.Content = JsonConvert.SerializeObject(validationResult.Errors);
                contentResult.StatusCode = (int)HttpStatusCode.BadRequest;
                return await Task.FromResult(contentResult);
            }
            else
            {
                bool response = false;
                var result = await maintenanceService.MarkAsCompleted(request.Id);
                if (result)
                {

                    logger.LogInformation($"Start: Mark maintence as completed {request.Id}");
                    contentResult.StatusCode = (int)HttpStatusCode.Created;
                    response = result;
                    logger.LogInformation($"End: Mark maintence as completed {request.Id}");

                }
                else
                {
                    contentResult.StatusCode = (int)HttpStatusCode.InternalServerError;
                    //response = null;
                }

                contentResult.Content = JsonConvert.SerializeObject(response);
                return await Task.FromResult(contentResult);
            }
        }
    }
}
