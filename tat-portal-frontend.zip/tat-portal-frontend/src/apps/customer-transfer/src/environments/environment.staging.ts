export const environment = {
    production: true,
    guidtointenabled: true,
    apiHostUrl: 'https://tatservicestage.nov.cloud',
    errorLoggingApiEndPoint:'https://tatservicestage.nov.cloud/frontendcommonsvc/ErrorLogging',
    gridPageSize:50,
    dropdownPazeSize:100,
    assemblyUrl: 'https://wbstg.nov.com/tat/Tools/ToolsDetails.aspx?id=',
    componentUrl: 'https://wbstg.nov.com/tat/Components/ComponentsDetails.aspx?id=',
    usageUrl: 'https://wbstg.nov.com/tat/Usages/UsagesDetails.aspx?id=',
    OldTatURl: 'https://wbstg.nov.com/tat/',
  };
  