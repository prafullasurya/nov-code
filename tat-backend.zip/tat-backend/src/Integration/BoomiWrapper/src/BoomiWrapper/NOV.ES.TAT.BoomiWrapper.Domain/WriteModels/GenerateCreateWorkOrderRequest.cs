﻿namespace NOV.ES.TAT.BoomiWrapper.Domain.WriteModels
{
    public class GenerateCreateWorkOrderRequest : BoomiRequestBaseModel
    {
        public string ActiveYN { get; set; }
        public string AddressNumber { get; set; }
        public string AddressNumberShipTo { get; set; }
        public decimal BusinessUnit { get; set; }
        public string CMode { get; set; }
        public string CMode2 { get; set; }
        public string CharFutureUse1 { get; set; }
        public string Company { get; set; }
        public string DateExpired { get; set; }
        public string DateRequested { get; set; }
        public string DateStart { get; set; }
        public decimal DateUpdated { get; set; }
        public int Description { get; set; }
        public string Description02 { get; set; }
        public string DocumentOrderNo { get; set; }
        public string EdiSuccessfullyProcess { get; set; }
        public string JobNumber { get; set; }
        public decimal ItemNumber { get; set; }
        public string ParentWONumber { get; set; }
        public string OrderType { get; set; }
        public string ProgramID { get; set; }
        public string Reference { get; set; }
        public string Reference2 { get; set; }
        public string SerialNumber { get; set; }
        public string StatusCodeWO { get; set; }
        public decimal SubledgerGL { get; set; }
        public int CostCenterMMCU { get; set; }
        public string TimeLastUpdated { get; set; }
        public string UserID { get; set; }
        public string WorkStationID { get; set; }
    }
}
