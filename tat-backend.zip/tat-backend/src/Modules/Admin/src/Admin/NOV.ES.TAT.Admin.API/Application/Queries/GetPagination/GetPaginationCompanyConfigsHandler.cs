﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetPaginationCompanyConfigsHandler
           : IQueryHandler<GetPaginationCompanyConfigsQuery, PagedResult<CompanyConfigDto>>
    {
        private readonly IMapper mapper;
        private readonly ICompanyConfigService companyConfigService;
        private readonly IHttpContextAccessor httpContextAccessor;

        public GetPaginationCompanyConfigsHandler(
            IMapper mapper
            ,ICompanyConfigService companyConfigService
            , IHttpContextAccessor httpContextAccessor)
        {
            this.mapper = mapper;
            this.companyConfigService = companyConfigService;
            this.httpContextAccessor = httpContextAccessor;
        }

        public Task<PagedResult<CompanyConfigDto>> Handle(GetPaginationCompanyConfigsQuery request,
          CancellationToken cancellationToken)
        {
            var companyConfigs = companyConfigService.GetCompanyConfigs(request.PagingParameters);
            var result = mapper.Map<PagedResult<CompanyConfig>, PagedResult<CompanyConfigDto>>(companyConfigs);

            if (result.Paging != null)
            {
                httpContextAccessor.HttpContext.Response.Headers.Add("X-Paging-PageCount", result.TotalNumberOfPages.ToString());
                httpContextAccessor.HttpContext.Response.Headers.Add("X-Paging-TotalRecordCount", result.TotalNumberOfItems.ToString());
                httpContextAccessor.HttpContext.Response.Headers.Add("X-Paging-PageIndex", result.Paging.PageIndex.ToString());
                httpContextAccessor.HttpContext.Response.Headers.Add("X-Paging-PageSize", result.Paging.PageSize.ToString());
            }
            return Task.FromResult(result);
        }
    }
}