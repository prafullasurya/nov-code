﻿using Newtonsoft.Json;

namespace NOV.ES.TAT.BoomiWrapper.Domain.WriteModels
{
    public class GenerateCreateSalesOrderRequest : BoomiRequestBaseModel
    {
        [JsonProperty("Header")]
        public Header Header { get; set; }
        [JsonProperty("Detail")]
        public List<Detail> Detail { get; set; }
    }
    public class Detail
    {
        [JsonProperty("dateRelease")]
        public DateTime DateRelease { get; set; }

        [JsonProperty("dateRequested")]
        public DateTime DateRequested { get; set; }

        [JsonProperty("descriptionSecondary")]
        public string DescriptionSecondary { get; set; }

        [JsonProperty("documentTypeAlt")]
        public string DocumentTypeAlt { get; set; }

        [JsonProperty("documentLineNumber")]
        public string DocumentLineNumber { get; set; }

        [JsonProperty("notaFiscalNumber")]
        public string NotaFiscalNumber { get; set; }

        [JsonProperty("notaFiscalSeries")]
        public string NotaFiscalSeries { get; set; }

        [JsonProperty("agreementId")]
        public string AgreementId { get; set; }

        [JsonProperty("businessUnit")]
        public string BusinessUnit { get; set; }

        [JsonProperty("szTransferOrderToBranch")]
        public string SzTransferOrderToBranch { get; set; }

        [JsonProperty("customerPO")]
        public string CustomerPO { get; set; }

        [JsonProperty("dateCancel")]
        public string DateCancel { get; set; }

        [JsonProperty("datePromiseddelivery")]
        public string DatePromiseddelivery { get; set; }

        [JsonProperty("datePromised")]
        public string DatePromised { get; set; }

        [JsonProperty("lineTypeCode")]
        public string LineTypeCode { get; set; }

        [JsonProperty("quantityOrdered")]
        public string QuantityOrdered { get; set; }

        [JsonProperty("quantityShipped")]
        public string QuantityShipped { get; set; }

        [JsonProperty("reference2Vendor_VR02")]
        public string Reference2VendorVR02 { get; set; }

        [JsonProperty("shipToEntityId")]
        public string ShipToEntityId { get; set; }

        [JsonProperty("statusCodeLast")]
        public string StatusCodeLast { get; set; }

        [JsonProperty("statusCodeNext")]
        public string StatusCodeNext { get; set; }

        [JsonProperty("unitOfMeasureCodeTransaction")]
        public string UnitOfMeasureCodeTransaction { get; set; }

        [JsonProperty("userReservedAmount")]
        public string UserReservedAmount { get; set; }

        [JsonProperty("userReservedCode")]
        public string UserReservedCode { get; set; }

        [JsonProperty("userReservedDate")]
        public string UserReservedDate { get; set; }

        [JsonProperty("MammaSalesOrderId")]
        public string MammaSalesOrderId { get; set; }

        [JsonProperty("userReservedReference")]
        public string UserReservedReference { get; set; }

        [JsonProperty("actionType")]
        public string ActionType { get; set; }

        [JsonProperty("carrierEntityId")]
        public string CarrierEntityId { get; set; }

        [JsonProperty("freightHandlingCode")]
        public string FreightHandlingCode { get; set; }

        [JsonProperty("modeOfTransportCode")]
        public string ModeOfTransportCode { get; set; }

        [JsonProperty("paymentInstrumentCode")]
        public string PaymentInstrumentCode { get; set; }

        [JsonProperty("printMessageCode")]
        public string PrintMessageCode { get; set; }

        [JsonProperty("taxExplanationCode")]
        public string TaxExplanationCode { get; set; }

        [JsonProperty("taxRateAreaCode")]
        public string TaxRateAreaCode { get; set; }

        [JsonProperty("taxableCode")]
        public string TaxableCode { get; set; }

        [JsonProperty("adjustmentScheduleCode")]
        public string AdjustmentScheduleCode { get; set; }

        [JsonProperty("overridePrice")]
        public string OverridePrice { get; set; }

        [JsonProperty("unitPrice")]
        public string UnitPrice { get; set; }

        [JsonProperty("foreignUnitPrice")]
        public string ForeignUnitPrice { get; set; }

        [JsonProperty("salesOrderOriginalDocumentCompany")]
        public string SalesOrderOriginalDocumentCompany { get; set; }

        [JsonProperty("salesOrderOriginalDocumentNumber")]
        public string SalesOrderOriginalDocumentNumber { get; set; }

        [JsonProperty("salesOrderOriginalDocumentTypeCode")]
        public string SalesOrderOriginalDocumentTypeCode { get; set; }

        [JsonProperty("description1")]
        public string Description1 { get; set; }

        [JsonProperty("description2")]
        public string Description2 { get; set; }

        [JsonProperty("location")]
        public string Location { get; set; }

        [JsonProperty("lotNumber")]
        public string LotNumber { get; set; }

        [JsonProperty("unitOfMeasureCodeWeight")]
        public string UnitOfMeasureCodeWeight { get; set; }

        [JsonProperty("unitOfMeasureCodeVolume")]
        public string UnitOfMeasureCodeVolume { get; set; }

        [JsonProperty("lineItemProductId")]
        public string LineItemProductId { get; set; }

        [JsonProperty("cCostRollupReference")]
        public string CCostRollupReference { get; set; }

        [JsonProperty("genericChar2")]
        public string GenericChar2 { get; set; }

        [JsonProperty("overrideCost")]
        public string OverrideCost { get; set; }

        [JsonProperty("foreignUnitCost")]
        public string ForeignUnitCost { get; set; }

        [JsonProperty("genericMathNumeric1_MATH01")]
        public string GenericMathNumeric1MATH01 { get; set; }

        [JsonProperty("unitCost")]
        public string UnitCost { get; set; }

        [JsonProperty("DetailAttachment")]
        public string DetailAttachment { get; set; }

        [JsonProperty("genericString2_DL02")]
        public string GenericString2DL02 { get; set; }

        [JsonProperty("productSource")]
        public string ProductSource { get; set; }

        [JsonProperty("revenueBusinessUnit")]
        public string RevenueBusinessUnit { get; set; }

        [JsonProperty("currencyCode")]
        public string CurrencyCode { get; set; }

        [JsonProperty("MammaSalesOrderLineNumber")]
        public string MammaSalesOrderLineNumber { get; set; }

        [JsonProperty("relatedOrderKeyDocumentCompany")]
        public string RelatedOrderKeyDocumentCompany { get; set; }

        [JsonProperty("relatedOrderKeyDocumentNumber")]
        public string RelatedOrderKeyDocumentNumber { get; set; }

        [JsonProperty("relatedOrderKeyDocumentType")]
        public string RelatedOrderKeyDocumentType { get; set; }
    }

    public class Header
    {
        [JsonProperty("businessUnit")]
        public string BusinessUnit { get; set; }

        [JsonProperty("salesOrderdocumentCompany")]
        public string SalesOrderdocumentCompany { get; set; }

        [JsonProperty("currencyCodeTo")]
        public string CurrencyCodeTo { get; set; }

        [JsonProperty("customerPO")]
        public string CustomerPO { get; set; }

        [JsonProperty("dateCancel")]
        public string DateCancel { get; set; }

        [JsonProperty("dateOrdered")]
        public string DateOrdered { get; set; }

        [JsonProperty("dateRequested")]
        public string DateRequested { get; set; }

        [JsonProperty("deliverToEntityId")]
        public string DeliverToEntityId { get; set; }

        [JsonProperty("holdOrderCode")]
        public string HoldOrderCode { get; set; }

        [JsonProperty("orderedBy")]
        public string OrderedBy { get; set; }

        [JsonProperty("rateExchange")]
        public string RateExchange { get; set; }

        [JsonProperty("shipToEntityId")]
        public string ShipToEntityId { get; set; }

        [JsonProperty("soldToEntityId")]
        public string SoldToEntityId { get; set; }

        [JsonProperty("adjustmentBasis")]
        public string AdjustmentBasis { get; set; }

        [JsonProperty("headerComment")]
        public string HeaderComment { get; set; }

        [JsonProperty("alphaSpecData10")]
        public string AlphaSpecData10 { get; set; }

        [JsonProperty("countryDescription")]
        public string CountryDescription { get; set; }

        [JsonProperty("dateUpdated")]
        public string DateUpdated { get; set; }

        [JsonProperty("description11")]
        public string Description11 { get; set; }

        [JsonProperty("descriptionSecondary")]
        public string DescriptionSecondary { get; set; }

        [JsonProperty("eMSString")]
        public string EMSString { get; set; }

        [JsonProperty("everestEventPoint01")]
        public string EverestEventPoint01 { get; set; }

        [JsonProperty("fieldTextDesctionXRef")]
        public string FieldTextDesctionXRef { get; set; }

        [JsonProperty("wellSite")]
        public string WellSite { get; set; }

        [JsonProperty("futureUserCFR10")]
        public string FutureUserCFR10 { get; set; }

        [JsonProperty("futureUserCFR15")]
        public string FutureUserCFR15 { get; set; }

        [JsonProperty("futureUserCFR16")]
        public string FutureUserCFR16 { get; set; }

        [JsonProperty("fieldTicket")]
        public string FieldTicket { get; set; }

        [JsonProperty("rigName")]
        public string RigName { get; set; }

        [JsonProperty("nameAlpha")]
        public string NameAlpha { get; set; }

        [JsonProperty("priorityProcessing")]
        public string PriorityProcessing { get; set; }

        [JsonProperty("serviceTypeDescription")]
        public string ServiceTypeDescription { get; set; }

        [JsonProperty("contractNumber")]
        public string ContractNumber { get; set; }

        [JsonProperty("wellType")]
        public string WellType { get; set; }

        [JsonProperty("rigID")]
        public string RigID { get; set; }

        [JsonProperty("deliveryInstruction2")]
        public string DeliveryInstruction2 { get; set; }

        [JsonProperty("wellID")]
        public string WellID { get; set; }

        [JsonProperty("accountNumber")]
        public string AccountNumber { get; set; }

        [JsonProperty("afeNo")]
        public string AfeNo { get; set; }

        [JsonProperty("attentionToDept")]
        public string AttentionToDept { get; set; }

        [JsonProperty("contractNum")]
        public string ContractNum { get; set; }

        [JsonProperty("customerLocation")]
        public string CustomerLocation { get; set; }

        [JsonProperty("serviceStartDate")]
        public string ServiceStartDate { get; set; }

        [JsonProperty("poNumber")]
        public string PoNumber { get; set; }

        [JsonProperty("propertyCC")]
        public string PropertyCC { get; set; }

        [JsonProperty("requisitionerName")]
        public string RequisitionerName { get; set; }

        [JsonProperty("ticketNumber")]
        public string TicketNumber { get; set; }

        [JsonProperty("adjustmentScheduleCode")]
        public string AdjustmentScheduleCode { get; set; }

        [JsonProperty("carrierEntityId")]
        public string CarrierEntityId { get; set; }

        [JsonProperty("creditCardAccountNumber")]
        public string CreditCardAccountNumber { get; set; }

        [JsonProperty("customerPriceGroupCode")]
        public string CustomerPriceGroupCode { get; set; }

        [JsonProperty("dateExpiration")]
        public string DateExpiration { get; set; }

        [JsonProperty("deliveryInstruction1")]
        public string DeliveryInstruction1 { get; set; }

        [JsonProperty("freightHandlingCode")]
        public string FreightHandlingCode { get; set; }

        [JsonProperty("paymentInstrumentCode")]
        public string PaymentInstrumentCode { get; set; }

        [JsonProperty("paymentTermsCode")]
        public string PaymentTermsCode { get; set; }

        [JsonProperty("percentDiscountTrade")]
        public string PercentDiscountTrade { get; set; }

        [JsonProperty("printMessageCode")]
        public string PrintMessageCode { get; set; }

        [JsonProperty("taxExplanationCode")]
        public string TaxExplanationCode { get; set; }

        [JsonProperty("taxRateAreaCode")]
        public string TaxRateAreaCode { get; set; }

        [JsonProperty("cCallPickShipPackUBE")]
        public string CCallPickShipPackUBE { get; set; }

        [JsonProperty("programmeId")]
        public string ProgrammeId { get; set; }

        [JsonProperty("genericString1_DL01")]
        public string GenericString1DL01 { get; set; }

        [JsonProperty("genericString1_DL02")]
        public string GenericString1DL02 { get; set; }

        [JsonProperty("orderTakenBy")]
        public string OrderTakenBy { get; set; }

        [JsonProperty("salesOrderDocumentNumber")]
        public string SalesOrderDocumentNumber { get; set; }

        [JsonProperty("salesOrderdocumentOriginalTypeCode")]
        public string SalesOrderdocumentOriginalTypeCode { get; set; }

        [JsonProperty("routeCode")]
        public string RouteCode { get; set; }

        [JsonProperty("stopCode")]
        public string StopCode { get; set; }

        [JsonProperty("szWSSJobNumberReference")]
        public string SzWSSJobNumberReference { get; set; }

        [JsonProperty("zoneNumber")]
        public string ZoneNumber { get; set; }

        [JsonProperty("ShipToContactAlphaName")]
        public string ShipToContactAlphaName { get; set; }

        [JsonProperty("userReservedCode")]
        public string UserReservedCode { get; set; }

        [JsonProperty("userReservedDate")]
        public string UserReservedDate { get; set; }

        [JsonProperty("userReservedAmount")]
        public string UserReservedAmount { get; set; }

        [JsonProperty("userReservedReference")]
        public string UserReservedReference { get; set; }

        [JsonProperty("actionType")]
        public string ActionType { get; set; }

        [JsonProperty("processingVersion")]
        public string ProcessingVersion { get; set; }

        [JsonProperty("jdeSalesOrderDocumentNumber")]
        public string JdeSalesOrderDocumentNumber { get; set; }

        [JsonProperty("salesOrderdocumentTypeCode")]
        public string SalesOrderdocumentTypeCode { get; set; }

        [JsonProperty("SalesCommissionInfo")]
        public List<SalesCommissionInfo> SalesCommissionInfo { get; set; }

        [JsonProperty("TargetERP")]
        public string TargetERP { get; set; }

        public string erpUserId { get; set; }
    }

    public class SalesCommissionInfo
    {
        [JsonProperty("commissionLineNumber")]
        public string CommissionLineNumber { get; set; }

        [JsonProperty("commissionTypeCode")]
        public string CommissionTypeCode { get; set; }

        [JsonProperty("salesReportGroup")]
        public string SalesReportGroup { get; set; }
    }
}
