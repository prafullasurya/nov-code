﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetCompanyErpInfoByCompanyCodeHandler : IQueryHandler<GetCompanyErpInfoByCompanyCodeQuery, CompanyErpInfoDto>
    {
        private readonly IMapper mapper;
        private readonly ICompanyErpInfoService companyErpInfoService;

        public GetCompanyErpInfoByCompanyCodeHandler(
            IMapper mapper,
            ICompanyErpInfoService companyErpInfoService)
        {          
            this.mapper = mapper;
            this.companyErpInfoService = companyErpInfoService;
        }

        public Task<CompanyErpInfoDto> Handle(GetCompanyErpInfoByCompanyCodeQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var companyErpInfo = companyErpInfoService.GetCompanyErpInfoByCompanyCode(request.CompanyCode);
            var result = mapper.Map<CompanyErpInfo, CompanyErpInfoDto>(companyErpInfo);
            return Task.FromResult(result);
        }
        private static bool IsValidRequest(GetCompanyErpInfoByCompanyCodeQuery request)
        {
            return (request != null);
        }
    }
}
