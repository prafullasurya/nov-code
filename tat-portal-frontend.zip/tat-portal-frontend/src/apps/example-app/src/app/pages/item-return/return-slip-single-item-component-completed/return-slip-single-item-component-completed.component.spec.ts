import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReturnSlipSingleItemCompletedComponent } from './return-slip-single-item-component-completed.component';

describe('ReturnSlipSingleItemCompletedComponent', () => {
  let component: ReturnSlipSingleItemCompletedComponent;
  let fixture: ComponentFixture<ReturnSlipSingleItemCompletedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReturnSlipSingleItemCompletedComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReturnSlipSingleItemCompletedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
