﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.API.Helper;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetPaginationBusinessUnitInfoHandler
           : IQueryHandler<GetPaginationBusinessUnitInfoQuery, PagedResult<BusinessUnitInfoDto>>
    {
        private readonly IMapper mapper;
        private readonly IBusinessUnitInfoService businessUnitInfoService;
        private readonly IHttpContextAccessor httpContextAccessor;

        public GetPaginationBusinessUnitInfoHandler(
             IMapper mapper
            , IBusinessUnitInfoService businessUnitInfoService
            , IHttpContextAccessor httpContextAccessor)
        {
            this.mapper = mapper;
            this.businessUnitInfoService = businessUnitInfoService;
            this.httpContextAccessor = httpContextAccessor;
        }

        public Task<PagedResult<BusinessUnitInfoDto>> Handle(GetPaginationBusinessUnitInfoQuery request,
          CancellationToken cancellationToken)
        {
            var businessUnitInfo = businessUnitInfoService.GetBusinessUnitInfo(request.PagingParameters);
            var result = mapper.Map<PagedResult<BusinessUnitInfo>, PagedResult<BusinessUnitInfoDto>>(businessUnitInfo);
            PagingHelper.AddPagingMetadata<BusinessUnitInfoDto>(result, httpContextAccessor);
            return Task.FromResult(result);
        }
    }
}