﻿namespace NOV.ES.TAT.BoomiWrapper.DomainService.ResponseModel
{
    public class ItemBranchResponse
    {
        public string Success { get; set; }
        public List<ItemError> Errors { get; set; }
        public List<ItemBranchResponseData> Data { get; set; }
    }
}
