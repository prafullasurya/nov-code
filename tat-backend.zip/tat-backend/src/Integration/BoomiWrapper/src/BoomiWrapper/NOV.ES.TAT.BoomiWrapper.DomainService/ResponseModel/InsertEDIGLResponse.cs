﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NOV.ES.TAT.BoomiWrapper.DomainService.RequestModel;

namespace NOV.ES.TAT.BoomiWrapper.DomainService.ResponseModel
{
	public class InsertEDIGLResponse
	{
		public string Success { get; set; }
		public List<ErpError> Errors { get; set; }
	}
}
