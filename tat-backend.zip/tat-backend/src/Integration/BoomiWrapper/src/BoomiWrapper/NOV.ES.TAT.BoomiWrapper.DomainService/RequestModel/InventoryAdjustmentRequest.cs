﻿namespace NOV.ES.TAT.BoomiWrapper.DomainService.RequestModel
{
    public class InventoryAdjustmentRequest: BaseRequestModel
    {
        public string TransactionType { get; set; }
        public DateTime CreatedDate { get; set; }
        public string Version { get; set; }
        public decimal TransferSlipOrderType { get; set; }
        public string TransferSlipNumber { get; set; }
        public string TargetInterface { get; set; }
        public List<InventoryAdjustmentDetails> InventoryAdjustmentDetails { get;set; }

    }
}
