﻿using NOV.ES.TAT.BoomiWrapper.Domain.WriteModels;
namespace NOV.ES.TAT.BoomiWrapper.Domain.ReadModel
{
    public class GetJdeInventoryRequest : BoomiRequestBaseModel
    {
        public string PartNumber { get; set; }
        public int ReferenceNumber { get; set; }
    }
}
