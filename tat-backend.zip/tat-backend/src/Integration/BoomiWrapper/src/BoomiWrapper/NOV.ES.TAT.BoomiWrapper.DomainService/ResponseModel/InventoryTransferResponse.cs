﻿using NOV.ES.TAT.BoomiWrapper.Domain.ReadModel;

namespace NOV.ES.TAT.BoomiWrapper.DomainService.ResponseModel
{
    public class InventoryTransferResponse
    {
        public string Success { get; set; }
        public string JDEDocNumber { get; set; }
        public string JDEDocType { get; set; }
        public string FromBranchPlant { get; set; }
        public string FromKeyCompany { get; set; }
        public string ToBranchPlant { get; set; }
        public List<ErpError> Errors { get; set; }
        public Dictionary<string, ErrorMessage> DictErrors { get; set; }
    }
}
