﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.API.Helper;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetPaginationLanguagesHandler
           : IQueryHandler<GetPaginationLanguagesQuery, PagedResult<LanguageDto>>
    {
        private readonly IMapper mapper;
        private readonly ILanguageService languageService;
        private readonly IHttpContextAccessor httpContextAccessor;

        public GetPaginationLanguagesHandler(
            IMapper mapper
            ,ILanguageService languageService
            , IHttpContextAccessor httpContextAccessor)
        {            
            this.mapper = mapper;
            this.languageService = languageService;
            this.httpContextAccessor = httpContextAccessor;
        }

        public Task<PagedResult<LanguageDto>> Handle(GetPaginationLanguagesQuery request,
          CancellationToken cancellationToken)
        {
            var languages = languageService.GetLanguages(request.PagingParameters);
            var result = mapper.Map<PagedResult<Language>, PagedResult<LanguageDto>>(languages);
            PagingHelper.AddPagingMetadata<LanguageDto>(result, httpContextAccessor);
            return Task.FromResult(result);
        }
    }
}