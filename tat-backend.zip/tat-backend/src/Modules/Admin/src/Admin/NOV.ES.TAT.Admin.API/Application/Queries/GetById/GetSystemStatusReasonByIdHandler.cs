﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetSystemStatusReasonByIdHandler : IQueryHandler<GetSystemStatusReasonByIdQuery, SystemStatusReasonDto>
    {
        private readonly IMapper mapper;
        private readonly ISystemStatusReasonService systemStatusReasonService;

        public GetSystemStatusReasonByIdHandler(
            IMapper mapper,
            ISystemStatusReasonService systemStatusReasonService)
        {
            this.mapper = mapper;
            this.systemStatusReasonService = systemStatusReasonService;
        }

        public Task<SystemStatusReasonDto> Handle(GetSystemStatusReasonByIdQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var systemStatusReason = systemStatusReasonService.GetSystemStatusReasonById(request.SystemStatusReasonId);
            return Task.FromResult(mapper.Map<SystemStatusReason, SystemStatusReasonDto>(systemStatusReason));
        }

        private static bool IsValidRequest(GetSystemStatusReasonByIdQuery request)
        {
            return (request != null && request.SystemStatusReasonId != 0);
        }
    }
}
