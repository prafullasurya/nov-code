﻿namespace NOV.ES.TAT.BoomiWrapper.Domain.WriteModels
{
    public class GenerateRemitoRequest : BoomiRequestBaseModel
    {
        public string Company { get; set; }
        public string BusinessUnit { get; set; }
        public string DocumentType { get; set; }
        public string DocumentNumber { get; set; }
        public string AddressNumber { get; set; }
        public string CustomerName { get; set; }
        public string ShipmentAddress { get; set; }
        public string CustomerPOAFE { get; set; }
        public string WellRigName { get; set; }
        public string FrieghtType { get; set; }
        public string Letter { get; set; }
        public string DocumentCode { get; set; }
        public string DocumentDesc { get; set; }
        public DateTime ShippedDate { get; set; }
        public string ShipToAddress { get; set; }
        public List<RemitoDetails> Details { get; set; }
        public string TargetInterface { get; set; }
    }
}
