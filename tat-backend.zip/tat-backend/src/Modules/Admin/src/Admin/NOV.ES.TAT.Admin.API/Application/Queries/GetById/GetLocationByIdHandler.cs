﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetLocationByIdHandler : IQueryHandler<GetLocationByIdQuery, LocationDto>
    {
        private readonly IMapper mapper;
        private readonly ILocationService locationService;

        public GetLocationByIdHandler(
            IMapper mapper,
            ILocationService locationService)
        {
            this.mapper = mapper;
            this.locationService = locationService;
        }

        public Task<LocationDto> Handle(GetLocationByIdQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var location = locationService.GetLocationById(request.LocationId);
            return Task.FromResult(mapper.Map<Location, LocationDto>(location));
        }

        private static bool IsValidRequest(GetLocationByIdQuery request)
        {
            return (request != null && request.LocationId != 0);
        }
    }
}
