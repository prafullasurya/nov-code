import { ComponentFixture, TestBed } from '@angular/core/testing';

import { phase3DialogPopupComponent } from './phase3-dialog-popup.component';

describe('phase3DialogPopupComponent', () => {
  let component: phase3DialogPopupComponent;
  let fixture: ComponentFixture<phase3DialogPopupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ phase3DialogPopupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(phase3DialogPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
function beforeEach(arg0: () => void) {
  throw new Error('Function not implemented.');
}

