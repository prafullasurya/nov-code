﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.Framework.Core.Pagination;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.API.Helper;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetLocationByBUHandler : IQueryHandler<GetLocationByBUQuery, PagedResult<LocationDto>>
    {
        private readonly IMapper mapper;
        private readonly ILocationService locationService;
        private readonly IHttpContextAccessor httpContextAccessor;

        public GetLocationByBUHandler(ILogger<GetLocationByBUHandler> logger,
            IMapper mapper,
            ILocationService locationService,
            IHttpContextAccessor httpContextAccessor
            )
        {            
            this.mapper = mapper;
            this.locationService = locationService;
            this.httpContextAccessor = httpContextAccessor;
        }

        public Task<PagedResult<LocationDto>> Handle(GetLocationByBUQuery request, CancellationToken cancellationToken)
        {
            var items = locationService.GetLocationBySendingBU(request.BUCode,request.searchText,request.PagingParameters);
            var result = mapper.Map<PagedResult<Location>, PagedResult<LocationDto>>(items);
            PagingHelper.AddPagingMetadata<LocationDto>(result, httpContextAccessor);
            return Task.FromResult(result);
        }
    }
}
