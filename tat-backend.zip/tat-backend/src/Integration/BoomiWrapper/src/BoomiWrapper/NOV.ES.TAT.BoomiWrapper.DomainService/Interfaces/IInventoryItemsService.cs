﻿using System.Net;
using NOV.ES.Framework.Core.Sagas;
using NOV.ES.TAT.BoomiWrapper.Domain.Event;
using NOV.ES.TAT.BoomiWrapper.Domain.ReadModel;

namespace NOV.ES.TAT.BoomiWrapper.DomainService
{
    public interface IInventoryItemsService
    {
        Guid ProcessErpItems(SagaEvent @event, ProcessInventoryItemsInErp processInventoryItemsInErp, ErpOperations erpOperation);
        (FieldTransferSlip, HttpStatusCode,string) ProcessErpItemsForFieldTransfer(FieldTransferSlip fieldTransferSlip, Guid corelationId = new Guid());
    }
}
