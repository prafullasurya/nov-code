import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerReturnInfoCompletedComponent } from './customer-return-info-completed.component';

describe('CustomerReturnSlipComponent', () => {
  let component: CustomerReturnInfoCompletedComponent;
  let fixture: ComponentFixture<CustomerReturnInfoCompletedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerReturnInfoCompletedComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerReturnInfoCompletedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
