﻿using AutoMapper;
using NOV.ES.Framework.Core.CQRS.Queries;
using NOV.ES.TAT.Admin.API.DTOs;
using NOV.ES.TAT.Admin.Domain;
using NOV.ES.TAT.Admin.DomainService;

namespace NOV.ES.TAT.Admin.API.Application.Queries
{
    public class GetErpAddressCodeByErpAbCodeHandler : IQueryHandler<GetErpAddressCodeByErpAbCodeQuery, IEnumerable<ErpAddressCodeDto>>
    {
        private readonly IMapper mapper;
        private readonly IErpAddressCodeService ErpAddressCodeService;

        public GetErpAddressCodeByErpAbCodeHandler(
            IMapper mapper,
            IErpAddressCodeService ErpAddressCodeService)
        {
            this.mapper = mapper;
            this.ErpAddressCodeService = ErpAddressCodeService;
        }

        public Task<IEnumerable<ErpAddressCodeDto>> Handle(GetErpAddressCodeByErpAbCodeQuery request, CancellationToken cancellationToken)
        {
            if (!IsValidRequest(request))
                throw new ArgumentException(Constants.EMPTY_MESSAGE);

            var ErpAddressCode = ErpAddressCodeService.GetErpAddressCodeByErpAbCode(request.ErpAbCode);
            var result = mapper.Map< IEnumerable<ErpAddressCode>, IEnumerable<ErpAddressCodeDto>>(ErpAddressCode);
            return Task.FromResult(result);
        }
        private static bool IsValidRequest(GetErpAddressCodeByErpAbCodeQuery request)
        {
            return (request != null && request.ErpAbCode != "");
        }
    }
}