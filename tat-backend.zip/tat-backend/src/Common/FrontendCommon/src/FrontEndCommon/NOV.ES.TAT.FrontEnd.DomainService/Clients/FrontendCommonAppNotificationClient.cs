﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using NOV.ES.TAT.FrontEnd.Domain;
using NOV.ES.TAT.FrontEnd.DomainService.Clients.Models;
using System.Text;

namespace NOV.ES.TAT.FrontEnd.DomainService.Clients
{
    public class FrontendCommonAppNotificationClient
        : IFrontendCommonAppNotificationClient
    {
        private readonly ILogger logger;
        public HttpClient httpClient { get; }
        public IHttpContextAccessor httpContextAccessor { get; }
        public IConfiguration configuration { get; }

        public FrontendCommonAppNotificationClient(ILogger<FrontendCommonAppNotificationClient> logger,
            HttpClient httpClient
            , IHttpContextAccessor httpContextAccessor
            , IConfiguration configuration
            ) 
        { 
            this.logger = logger;
            this.httpClient = httpClient;
            this.httpContextAccessor = httpContextAccessor;
            this.configuration = configuration;
        }

        public async Task BroadcastSystemShutingdownMessageAsync(MaintenanceModel maintenanceModel)
        {
            try
            {
                var notificationMessage = new NotificationToAll(maintenanceModel.Id, MessageType.SystemShuttingDown,
                    maintenanceModel.MessageId, string.Empty, maintenanceModel.DownTimeReason,
                    maintenanceModel.ScheduledOn, maintenanceModel.ExpectedResumeBy);

                var notificationJson = JsonConvert.SerializeObject(notificationMessage);

                var stringContent = new StringContent(notificationJson, UnicodeEncoding.UTF8, "application/json");

                logger.LogInformation($"About to send system down notification. {notificationJson}");

                var response = await httpClient.PostAsync($"{configuration["AppNotificationBaseUrl"]}/appnotificationsvc/AppNotification/notificationtoall", stringContent);
            }
            catch(Exception ex )
            {
                logger.LogError($"Error ocurred while sending system down notification. {ex.ToString()}");
            }
        }
    }
}
